---
name: User Story
about: Just use this template for user facing behavior
title: ''
labels: ''
assignees: ''

---

## User Story

## Acceptance criteria

## Tasks
