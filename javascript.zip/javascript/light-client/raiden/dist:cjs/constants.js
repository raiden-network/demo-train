"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var utils_1 = require("ethers/utils");
exports.SignatureZero = utils_1.padZeros([], 65);
exports.MATRIX_KNOWN_SERVERS_URL = {
    default: 'https://raw.githubusercontent.com/raiden-network/raiden-transport/master/known_servers.test.yaml',
};
var ShutdownReason;
(function (ShutdownReason) {
    ShutdownReason["STOP"] = "raidenStopped";
    ShutdownReason["ACCOUNT_CHANGED"] = "providerAccountChanged";
    ShutdownReason["NETWORK_CHANGED"] = "providerNetworkChanged";
})(ShutdownReason = exports.ShutdownReason || (exports.ShutdownReason = {}));
exports.REVEAL_TIMEOUT = 50;
//# sourceMappingURL=constants.js.map