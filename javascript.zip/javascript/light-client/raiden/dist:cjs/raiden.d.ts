import { Signer } from 'ethers';
import { AsyncSendable, JsonRpcProvider } from 'ethers/providers';
import { Network, BigNumber, BigNumberish } from 'ethers/utils';
import { Observable } from 'rxjs';
import { ContractsInfo, RaidenChannels, TokenInfo } from './types';
import { Address, Storage, Hash } from './utils/types';
import { RaidenState } from './store';
import { RaidenEvent } from './actions';
export declare class Raiden {
    private readonly provider;
    readonly network: Network;
    private readonly signer;
    private readonly store;
    private contracts;
    private readonly tokenInfo;
    private readonly action$;
    /**
     * state$ is exposed only so user can listen to state changes and persist them somewhere else,
     * in case they didn't use the Storage overload for the storageOrState argument of `create`.
     * Format/content of the emitted objects are subject to changes and not part of the public API
     */
    readonly state$: Observable<RaidenState>;
    readonly channels$: Observable<RaidenChannels>;
    /**
     * A subset ot RaidenActions exposed as public events.
     * The interface of the objects emitted by this Observable are expected not to change internally,
     * but more/new events may be added over time.
     */
    readonly events$: Observable<RaidenEvent>;
    /**
     * Expose ether's Provider.resolveName for ENS support
     */
    readonly resolveName: (name: string) => Promise<Address>;
    constructor(provider: JsonRpcProvider, network: Network, signer: Signer, contractsInfo: ContractsInfo, state: RaidenState);
    /**
     * Async helper factory to make a Raiden instance from more common parameters.
     *
     * @param connection
     * - a JsonRpcProvider instance
     * - a Metamask's web3.currentProvider object or
     * - a hostname or remote json-rpc connection string
     * @param account
     * - a string address of an account loaded in provider or
     * - a string private key or
     * - a number index of an account loaded in provider (e.g. 0 for Metamask's loaded account)
     * @param storageOrState
     *   Storage/localStorage-like synchronous object where to load and store current state or
     *   initial RaidenState-like object instead. In this case, user must listen state$ changes
     *   and update them on whichever persistency option is used
     * @param contracts
     *   Contracts deployment info
     * @returns Promise to Raiden SDK client instance
     * An async factory is needed so we can do the needed async requests to construct the required
     * parameters ahead of construction time, and avoid partial initialization then
     **/
    static create(connection: JsonRpcProvider | AsyncSendable | string, account: string | number, storageOrState?: Storage | RaidenState | unknown, contracts?: ContractsInfo): Promise<Raiden>;
    /**
     * Triggers all epics to be unsubscribed
     */
    stop(): void;
    private readonly state;
    readonly address: Address;
    getBlockNumber(): Promise<number>;
    /**
     * Get ETH balance for given address or self
     *
     * @param address  Optional target address. If omitted, gets own balance
     * @returns  BigNumber of ETH balance
     */
    getBalance(address?: string): Promise<BigNumber>;
    /**
     * Get token balance and token decimals for given address or self
     *
     * @param token  Token address to fetch balance. Must be one of the monitored tokens.
     * @param address  Optional target address. If omitted, gets own balance
     * @returns  BigNumber containing address's token balance
     */
    getTokenBalance(token: string, address?: string): Promise<BigNumber>;
    /**
     * Get token information: totalSupply, decimals, name and symbol
     * Rejects only if 'token' contract doesn't define totalSupply and decimals methods.
     * name and symbol may be undefined, as they aren't actually part of ERC20 standard, although
     * very common and defined on most token contracts.
     *
     * @param token address to fetch info from
     * @returns TokenInfo
     */
    getTokenInfo(token: string): Promise<TokenInfo>;
    /**
     * Returns a list of all token addresses registered as token networks in registry
     *
     * @returns Promise to list of token addresses
     */
    getTokenList(): Promise<Address[]>;
    /**
     * Create a TokenNetwork contract linked to this.signer for given tokenNetwork address
     * Caches the result and returns the same contract instance again for the same address on this
     *
     * @param address  TokenNetwork contract address (not token address!)
     * @returns  TokenNetwork Contract instance
     */
    private getTokenNetworkContract;
    /**
     * Create a Token contract linked to this.signer for given token address
     * Caches the result and returns the same contract instance again for the same address on this
     *
     * @param address  Token contract address
     * @returns  Token Contract instance
     */
    private getTokenContract;
    /**
     * Open a channel on the tokenNetwork for given token address with partner
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @param settleTimeout  openChannel parameter, defaults to 500
     * @returns  txHash of channelOpen call, iff it succeeded
     */
    openChannel(token: string, partner: string, settleTimeout?: number): Promise<Hash>;
    /**
     * Deposit tokens on channel between us and partner on tokenNetwork for token
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @param deposit  Number of tokens to deposit on channel
     * @returns  txHash of setTotalDeposit call, iff it succeeded
     */
    depositChannel(token: string, partner: string, deposit: BigNumberish): Promise<Hash>;
    /**
     * Close channel between us and partner on tokenNetwork for token
     * This method will fail if called on a channel not in 'opened' or 'closing' state.
     * When calling this method on an 'opened' channel, its state becomes 'closing', and from there
     * on, no payments can be performed on the channel. If for any reason the closeChannel
     * transaction fails, channel's state stays as 'closing', and this method can be called again
     * to retry sending 'closeChannel' transaction. After it's successful, channel becomes 'closed',
     * and can be settled after 'settleTimeout' blocks (when it then becomes 'settleable').
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @returns  txHash of closeChannel call, iff it succeeded
     */
    closeChannel(token: string, partner: string): Promise<Hash>;
    /**
     * Settle channel between us and partner on tokenNetwork for token
     * This method will fail if called on a channel not in 'settleable' or 'settling' state.
     * Channel becomes 'settleable' settleTimeout blocks after closed (detected automatically
     * while Raiden Light Client is running or later on restart). When calling it, channel state
     * becomes 'settling'. If for any reason transaction fails, it'll stay on this state, and this
     * method can be called again to re-send a settleChannel transaction.
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @returns  txHash of settleChannel call, iff it succeeded
     */
    settleChannel(token: string, partner: string): Promise<Hash>;
    /**
     * Returns object describing address's users availability on transport
     * After calling this method, any further presence update to valid transport peers of this
     * address will trigger a corresponding MatrixPresenceUpdateAction on events$
     *
     * @param address checksummed address to be monitored
     * @returns Promise to object describing availability and last event timestamp
     */
    getAvailability(address: string): Promise<{
        userId: string;
        available: boolean;
        ts: number;
    }>;
    /**
     * Send a Locked Transfer!
     * Coverage ignored until we handle the full transfer lifecycle
     * TODO: remove uncover when implemented
     *
     * @param token  Token address on currently configured token network registry
     * @param target  Target address (must be getAvailability before)
     * @param amount  Amount to try to transfer
     * @param opts.paymentId  Optionally specify a paymentId to use for this transfer
     * @param opts.secret  Optionally specify a secret to use on this transfer
     *    (in which case, it'll be registered and revealed to target)
     * @param opts.secrethash  Optionally specify a secrethash to use. If secret is provided,
     *    secrethash must be the keccak256 hash of the secret. If no secret is provided, the target
     *    must be informed of it by other means/externally.
     * @returns A promise to the total transferred amount on this channel after transfer succeeds
     */
    transfer(token: string, target: string, amount: BigNumberish, opts?: {
        paymentId?: BigNumberish;
        secret?: string;
        secrethash?: string;
    }): Promise<BigNumber>;
}
export default Raiden;
