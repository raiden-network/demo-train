import { ActionType, Action } from 'typesafe-actions';
export declare const RaidenActions: {
    transfer: import("typesafe-actions").PayloadMetaAC<"transfer", {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        target: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        amount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
        fee?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>> | undefined;
        paymentId?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<8>> | undefined;
        secret?: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>> | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSigned: import("typesafe-actions").PayloadMetaAC<"transferSigned", {
        message: import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferProcessed: import("typesafe-actions").PayloadMetaAC<"transferProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSecret: import("typesafe-actions").PayloadMetaAC<"transferSecret", {
        secret: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>>;
        registerBlock?: number | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSecretRequest: import("typesafe-actions").PayloadMetaAC<"transferSecretRequest", {
        message: import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlock: import("typesafe-actions").PayloadMetaAC<"transferUnlock", {
        message: import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlocked: import("typesafe-actions").PayloadMetaAC<"transferUnlocked", {
        message: import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlockProcessed: import("typesafe-actions").PayloadMetaAC<"transferUnlockProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferred: import("typesafe-actions").PayloadMetaAC<"transferred", {
        balanceProof: {
            chainId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            tokenNetworkAddress: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
            channelId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            nonce: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<8>>;
            transferredAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            lockedAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            locksroot: import("./utils/types").Hash;
            messageHash: import("./utils/types").Hash;
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            sender: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferFailed: (payload: Error, meta: {
        secrethash: import("./utils/types").Hash;
    }) => {
        type: "transferFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            secrethash: import("./utils/types").Hash;
        };
    };
    messageSend: import("typesafe-actions").PayloadMetaAC<"messageSend", {
        message: string | (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        });
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    messageReceived: (payload: {
        text: string;
        message?: (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | undefined;
        ts?: number | undefined;
        userId?: string | undefined;
        roomId?: string | undefined;
    }, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "messageReceived";
    } & {
        payload: {
            text: string;
            message: (import("./messages").Delivered & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Processed & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretRequest & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretReveal & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockedTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").RefundTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Unlock & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockExpired & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | undefined;
            ts: number;
            userId: string | undefined;
            roomId: string | undefined;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixSetup: import("typesafe-actions").PayloadAC<"matrixSetup", {
        server: string;
        setup: import("./transport/state").RaidenMatrixSetup;
    }>;
    matrixRequestMonitorPresence: import("typesafe-actions").PayloadMetaAC<"matrixRequestMonitorPresence", undefined, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    matrixPresenceUpdate: (payload: {
        userId: string;
        available: boolean;
        ts?: number | undefined;
    }, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "matrixPresenceUpdate";
    } & {
        payload: {
            userId: string;
            available: boolean;
            ts: number;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixRequestMonitorPresenceFailed: (payload: Error, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "matrixRequestMonitorPresenceFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixRoom: import("typesafe-actions").PayloadMetaAC<"matrixRoom", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    matrixRoomLeave: import("typesafe-actions").PayloadMetaAC<"matrixRoomLeave", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    newBlock: import("typesafe-actions").PayloadAC<"newBlock", {
        blockNumber: number;
    }>;
    tokenMonitored: (payload: {
        token: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        first?: boolean | undefined;
    }) => {
        type: "tokenMonitored";
    } & {
        payload: {
            token: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            first: boolean;
        };
    };
    channelOpen: import("typesafe-actions").PayloadMetaAC<"channelOpen", {
        settleTimeout: number;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelOpened: import("typesafe-actions").PayloadMetaAC<"channelOpened", {
        id: number;
        settleTimeout: number;
        openBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelOpenFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelOpenFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelMonitored: import("typesafe-actions").PayloadMetaAC<"channelMonitored", {
        id: number;
        fromBlock?: number | undefined;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDeposit: import("typesafe-actions").PayloadMetaAC<"channelDeposit", {
        deposit: import("ethers/utils").BigNumber;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDeposited: import("typesafe-actions").PayloadMetaAC<"channelDeposited", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        totalDeposit: import("ethers/utils").BigNumber;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDepositFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelDepositFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelClose: import("typesafe-actions").PayloadMetaAC<"channelClose", undefined, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelClosed: import("typesafe-actions").PayloadMetaAC<"channelClosed", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        closeBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelCloseFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelCloseFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelSettleable: import("typesafe-actions").PayloadMetaAC<"channelSettleable", {
        settleableBlock: number;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettle: import("typesafe-actions").PayloadMetaAC<"channelSettle", undefined, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettled: import("typesafe-actions").PayloadMetaAC<"channelSettled", {
        id: number;
        settleBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettleFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelSettleFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    raidenInit: import("typesafe-actions").EmptyAC<"raidenInit">;
    raidenShutdown: import("typesafe-actions").PayloadAC<"raidenShutdown", {
        reason: Error | import("./constants").ShutdownReason;
    }>;
};
export declare type RaidenAction = Action;
export declare const RaidenEvents: Pick<{
    transfer: import("typesafe-actions").PayloadMetaAC<"transfer", {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        target: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        amount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
        fee?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>> | undefined;
        paymentId?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<8>> | undefined;
        secret?: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>> | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSigned: import("typesafe-actions").PayloadMetaAC<"transferSigned", {
        message: import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferProcessed: import("typesafe-actions").PayloadMetaAC<"transferProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSecret: import("typesafe-actions").PayloadMetaAC<"transferSecret", {
        secret: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>>;
        registerBlock?: number | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferSecretRequest: import("typesafe-actions").PayloadMetaAC<"transferSecretRequest", {
        message: import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlock: import("typesafe-actions").PayloadMetaAC<"transferUnlock", {
        message: import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlocked: import("typesafe-actions").PayloadMetaAC<"transferUnlocked", {
        message: import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferUnlockProcessed: import("typesafe-actions").PayloadMetaAC<"transferUnlockProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferred: import("typesafe-actions").PayloadMetaAC<"transferred", {
        balanceProof: {
            chainId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            tokenNetworkAddress: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
            channelId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            nonce: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<8>>;
            transferredAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            lockedAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            locksroot: import("./utils/types").Hash;
            messageHash: import("./utils/types").Hash;
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            sender: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>;
    transferFailed: (payload: Error, meta: {
        secrethash: import("./utils/types").Hash;
    }) => {
        type: "transferFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            secrethash: import("./utils/types").Hash;
        };
    };
    messageSend: import("typesafe-actions").PayloadMetaAC<"messageSend", {
        message: string | (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        });
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    messageReceived: (payload: {
        text: string;
        message?: (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | undefined;
        ts?: number | undefined;
        userId?: string | undefined;
        roomId?: string | undefined;
    }, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "messageReceived";
    } & {
        payload: {
            text: string;
            message: (import("./messages").Delivered & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Processed & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretRequest & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretReveal & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockedTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").RefundTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Unlock & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockExpired & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | undefined;
            ts: number;
            userId: string | undefined;
            roomId: string | undefined;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixSetup: import("typesafe-actions").PayloadAC<"matrixSetup", {
        server: string;
        setup: import("./transport/state").RaidenMatrixSetup;
    }>;
    matrixRequestMonitorPresence: import("typesafe-actions").PayloadMetaAC<"matrixRequestMonitorPresence", undefined, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    matrixPresenceUpdate: (payload: {
        userId: string;
        available: boolean;
        ts?: number | undefined;
    }, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "matrixPresenceUpdate";
    } & {
        payload: {
            userId: string;
            available: boolean;
            ts: number;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixRequestMonitorPresenceFailed: (payload: Error, meta: {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "matrixRequestMonitorPresenceFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    matrixRoom: import("typesafe-actions").PayloadMetaAC<"matrixRoom", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    matrixRoomLeave: import("typesafe-actions").PayloadMetaAC<"matrixRoomLeave", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    newBlock: import("typesafe-actions").PayloadAC<"newBlock", {
        blockNumber: number;
    }>;
    tokenMonitored: (payload: {
        token: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        first?: boolean | undefined;
    }) => {
        type: "tokenMonitored";
    } & {
        payload: {
            token: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            first: boolean;
        };
    };
    channelOpen: import("typesafe-actions").PayloadMetaAC<"channelOpen", {
        settleTimeout: number;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelOpened: import("typesafe-actions").PayloadMetaAC<"channelOpened", {
        id: number;
        settleTimeout: number;
        openBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelOpenFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelOpenFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelMonitored: import("typesafe-actions").PayloadMetaAC<"channelMonitored", {
        id: number;
        fromBlock?: number | undefined;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDeposit: import("typesafe-actions").PayloadMetaAC<"channelDeposit", {
        deposit: import("ethers/utils").BigNumber;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDeposited: import("typesafe-actions").PayloadMetaAC<"channelDeposited", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        totalDeposit: import("ethers/utils").BigNumber;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelDepositFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelDepositFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelClose: import("typesafe-actions").PayloadMetaAC<"channelClose", undefined, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelClosed: import("typesafe-actions").PayloadMetaAC<"channelClosed", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        closeBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelCloseFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelCloseFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    channelSettleable: import("typesafe-actions").PayloadMetaAC<"channelSettleable", {
        settleableBlock: number;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettle: import("typesafe-actions").PayloadMetaAC<"channelSettle", undefined, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettled: import("typesafe-actions").PayloadMetaAC<"channelSettled", {
        id: number;
        settleBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>;
    channelSettleFailed: (payload: Error, meta: {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }) => {
        type: "channelSettleFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    };
    raidenInit: import("typesafe-actions").EmptyAC<"raidenInit">;
    raidenShutdown: import("typesafe-actions").PayloadAC<"raidenShutdown", {
        reason: Error | import("./constants").ShutdownReason;
    }>;
}, "raidenShutdown" | "newBlock" | "matrixPresenceUpdate">;
export declare type RaidenEvent = ActionType<typeof RaidenEvents>;
