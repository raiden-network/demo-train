"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var typesafe_actions_1 = require("typesafe-actions");
var lodash_1 = require("lodash");
var actions_1 = require("./store/actions");
var StoreEpics = __importStar(require("./store/epics"));
var ChannelsEpics = __importStar(require("./channels/epics"));
var TransportEpics = __importStar(require("./transport/epics"));
var TransfersEpics = __importStar(require("./transfers/epics"));
exports.RaidenEpics = __assign({}, StoreEpics, ChannelsEpics, TransportEpics, TransfersEpics);
exports.raidenRootEpic = function (action$, state$, deps) {
    var shutdownNotification = action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.raidenShutdown))), limitedAction$ = action$.pipe(operators_1.takeWhile(lodash_1.negate(typesafe_actions_1.isActionOf(actions_1.raidenShutdown)), true)), limitedState$ = state$.pipe(operators_1.takeUntil(shutdownNotification));
    // like combineEpics, but completes action$, state$ & output$ when a raidenShutdown goes through
    return rxjs_1.from(Object.values(exports.RaidenEpics)).pipe(operators_1.mergeMap(function (epic) { return epic(limitedAction$, limitedState$, deps); }), operators_1.catchError(function (err) { return rxjs_1.of(actions_1.raidenShutdown({ reason: err })); }), operators_1.takeUntil(shutdownNotification));
};
//# sourceMappingURL=epics.js.map