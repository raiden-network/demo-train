import { Observable } from 'rxjs';
import { RaidenEpicDeps } from './types';
import { RaidenState } from './store/state';
export declare const RaidenEpics: {
    transferGenerateAndSignEnvelopeMessageEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, deps: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"messageSend", {
        message: string | (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        });
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }> | import("typesafe-actions").PayloadMetaAction<"transferSecret", {
        secret: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>>;
        registerBlock?: number | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }> | import("typesafe-actions").PayloadMetaAction<"transferSigned", {
        message: import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }> | ({
        type: "transferFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            secrethash: import("./utils/types").Hash;
        };
    }) | import("typesafe-actions").PayloadMetaAction<"transferUnlocked", {
        message: import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    transferProcessedReceivedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    transferSecretRequestedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferSecretRequest", {
        message: import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    transferRevealSecretEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { signer }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"messageSend", {
        message: string | (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        });
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    transferSecretRevealedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferSecret", {
        secret: import("io-ts").Branded<string, import("./utils/types").HexStringB<number>>;
        registerBlock?: number | undefined;
    }, {
        secrethash: import("./utils/types").Hash;
    }> | import("typesafe-actions").PayloadMetaAction<"transferUnlock", {
        message: import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    transferUnlockProcessedReceivedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferUnlockProcessed", {
        message: import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    transferSuccessEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferred", {
        balanceProof: {
            chainId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            tokenNetworkAddress: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
            channelId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            nonce: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<8>>;
            transferredAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            lockedAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("./utils/types").UIntB<32>>;
            locksroot: import("./utils/types").Hash;
            messageHash: import("./utils/types").Hash;
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            sender: import("io-ts").Branded<import("io-ts").Branded<string, import("./utils/types").HexStringB<20>>, import("./utils/types").HexStringB<20> & import("./utils/types").AddressB>;
        };
    }, {
        secrethash: import("./utils/types").Hash;
    }>>;
    initMatrixEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, network, signer, matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadAction<"matrixSetup", {
        server: string;
        setup: import("./transport/state").RaidenMatrixSetup;
    }>>;
    matrixStartEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    matrixShutdownEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    matrixMonitorPresenceEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<({
        type: "matrixPresenceUpdate";
    } & {
        payload: {
            userId: string;
            available: boolean;
            ts: number;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }) | ({
        type: "matrixRequestMonitorPresenceFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    })>;
    matrixPresenceUpdateEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<{
        type: "matrixPresenceUpdate";
    } & {
        payload: {
            userId: string;
            available: boolean;
            ts: number;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    matrixCreateRoomEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRoom", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    matrixInviteEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    matrixHandleInvitesEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRoom", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    matrixLeaveExcessRoomsEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRoomLeave", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    matrixLeaveUnknownRoomsEpic: ({}: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$, network }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    matrixCleanLeftRoomsEpic: ({}: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRoomLeave", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    matrixMessageSendEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    matrixMessageReceivedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { matrix$ }: RaidenEpicDeps) => Observable<{
        type: "messageReceived";
    } & {
        payload: {
            text: string;
            message: (import("./messages").Delivered & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Processed & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretRequest & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").SecretReveal & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockedTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").RefundTransfer & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").Unlock & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | (import("./messages").LockExpired & {
                signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
            }) | undefined;
            ts: number;
            userId: string | undefined;
            roomId: string | undefined;
        };
        meta: {
            address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    matrixMessageReceivedUpdateRoomEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRoom", {
        roomId: string;
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    matrixMonitorChannelPresenceEpic: (action$: Observable<import("typesafe-actions").Action<string>>) => Observable<import("typesafe-actions").PayloadMetaAction<"matrixRequestMonitorPresence", undefined, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    deliveredEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { signer }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"messageSend", {
        message: string | (import("./messages").Delivered & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Processed & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretRequest & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").SecretReveal & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").Unlock & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        }) | (import("./messages").LockExpired & {
            signature: import("io-ts").Branded<string, import("./utils/types").HexStringB<65>>;
        });
    }, {
        address: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    initNewBlockEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { provider }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadAction<"newBlock", {
        blockNumber: number;
    }>>;
    initMonitorRegistryEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { registryContract, contractsInfo }: RaidenEpicDeps) => Observable<{
        type: "tokenMonitored";
    } & {
        payload: {
            token: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            first: boolean;
        };
    }>;
    initMonitorChannelsEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelMonitored", {
        id: number;
        fromBlock?: number | undefined;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    initMonitorProviderEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { address, network, provider }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadAction<"raidenShutdown", {
        reason: Error | import("./constants").ShutdownReason;
    }>>;
    tokenMonitoredEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenNetworkContract, contractsInfo }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"channelOpened", {
        id: number;
        settleTimeout: number;
        openBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    channelMonitoredEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"channelDeposited", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        totalDeposit: import("ethers/utils").BigNumber;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }> | import("typesafe-actions").PayloadMetaAction<"channelClosed", {
        id: number;
        participant: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        closeBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }> | import("typesafe-actions").PayloadMetaAction<"channelSettled", {
        id: number;
        settleBlock: number;
        txHash: import("./utils/types").Hash;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    channelOpenEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
        type: "channelOpenFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    channelOpenedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelMonitored", {
        id: number;
        fromBlock?: number | undefined;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    channelDepositEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenContract, getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
        type: "channelDepositFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    channelCloseEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
        type: "channelCloseFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    channelSettleEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
        type: "channelSettleFailed";
    } & {
        payload: Error;
        error: boolean;
        meta: {
            tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
            partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        };
    }>;
    channelSettleableEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelSettleable", {
        settleableBlock: number;
    }, {
        tokenNetwork: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("./utils/types").HexStringB<20>> & import("io-ts").Brand<import("./utils/types").AddressB>;
    }>>;
    stateOutputEpic: ({}: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { stateOutput$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
    actionOutputEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { actionOutput$ }: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
};
export declare const raidenRootEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, deps: RaidenEpicDeps) => Observable<import("typesafe-actions").Action<string>>;
