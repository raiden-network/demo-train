"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
/* istanbul ignore file */
/* eslint-disable @typescript-eslint/camelcase */
/**
 * These io-ts codecs validate and decode JSON Raiden messages
 * They include BigNumber strings validation, enum validation (if needed), Address checksum
 * validation, etc, and converting everything to its respective object, where needed.
 */
var t = __importStar(require("io-ts"));
var lodash_1 = require("lodash");
// import { ThrowReporter } from 'io-ts/lib/ThrowReporter';
var types_1 = require("../utils/types");
var types_2 = require("../channels/types");
// types
var MessageType;
(function (MessageType) {
    MessageType["DELIVERED"] = "Delivered";
    MessageType["PROCESSED"] = "Processed";
    MessageType["SECRET_REQUEST"] = "SecretRequest";
    MessageType["SECRET_REVEAL"] = "RevealSecret";
    MessageType["LOCKED_TRANSFER"] = "LockedTransfer";
    MessageType["REFUND_TRANSFER"] = "RefundTransfer";
    MessageType["UNLOCK"] = "Secret";
    MessageType["LOCK_EXPIRED"] = "LockExpired";
})(MessageType = exports.MessageType || (exports.MessageType = {}));
exports.MessageTypeC = new types_1.EnumType(MessageType, 'MessageType');
// Mixin for all tagged messages
exports.Message = t.type({ type: exports.MessageTypeC });
// Mixin of a message that contains an identifier and should be ack'ed with a respective Delivered
var RetrieableMessage = t.intersection([
    t.type({
        message_identifier: types_1.UInt(8),
    }),
    exports.Message,
]);
// Acknowledges to the sender that a RetrieableMessage was received
exports.Delivered = t.intersection([
    t.type({
        type: t.literal(MessageType.DELIVERED),
        delivered_message_identifier: types_1.UInt(8),
    }),
    exports.Message,
]);
// Confirms some message that required state validation was successfuly processed
exports.Processed = t.intersection([
    t.type({
        type: t.literal(MessageType.PROCESSED),
    }),
    RetrieableMessage,
]);
// Requests the initiator to reveal the secret for a LockedTransfer targeted to us
exports.SecretRequest = t.intersection([
    t.type({
        type: t.literal(MessageType.SECRET_REQUEST),
        payment_identifier: types_1.UInt(8),
        secrethash: types_1.Hash,
        amount: types_1.UInt(32),
        expiration: types_1.UInt(32),
    }),
    RetrieableMessage,
]);
// Reveal to the target or the previous hop a secret we just learned off-chain
exports.SecretReveal = t.intersection([
    t.type({
        type: t.literal(MessageType.SECRET_REVEAL),
        secret: types_1.Secret,
    }),
    RetrieableMessage,
]);
// Mixin for messages containing a balance proof
exports.EnvelopeMessage = t.intersection([
    t.type({
        chain_id: types_1.UInt(32),
        token_network_address: types_1.Address,
        channel_identifier: types_1.UInt(32),
        nonce: types_1.UInt(8),
        transferred_amount: types_1.UInt(32),
        locked_amount: types_1.UInt(32),
        locksroot: types_1.Hash,
    }),
    RetrieableMessage,
]);
// base for locked and refund transfer, they differentiate only on the type tag
var LockedTransferBase = t.intersection([
    t.type({
        payment_identifier: types_1.UInt(8),
        token: types_1.Address,
        recipient: types_1.Address,
        lock: types_2.Lock,
        target: types_1.Address,
        initiator: types_1.Address,
        fee: types_1.UInt(32),
    }),
    exports.EnvelopeMessage,
]);
// a mediated transfer containing a locked amount
exports.LockedTransfer = t.intersection([
    t.type({
        type: t.literal(MessageType.LOCKED_TRANSFER),
    }),
    LockedTransferBase,
]);
// if a mediated transfer didn't succeed, mediator can refund the amount with the same secrethash
// so the previous hop can retry it with another neighbor
exports.RefundTransfer = t.intersection([
    t.type({
        type: t.literal(MessageType.REFUND_TRANSFER),
    }),
    LockedTransferBase,
]);
// when the secret is revealed, unlock sends a new balance proof without the lock and increasing
// the total transfered to finish the offchain transfer
exports.Unlock = t.intersection([
    t.type({
        type: t.literal(MessageType.UNLOCK),
        payment_identifier: types_1.UInt(8),
        secret: types_1.Secret,
    }),
    exports.EnvelopeMessage,
]);
// after mediated transfer fails and the lock expire, clean it from the locks tree
exports.LockExpired = t.intersection([
    t.type({
        type: t.literal(MessageType.LOCK_EXPIRED),
        recipient: types_1.Address,
        secrethash: types_1.Hash,
    }),
    exports.EnvelopeMessage,
]);
// type to require a message to be signed!
// generic type codec for messages that must be signed
// use it like: Codec = Signed(Message)
// The t.TypeOf<typeof codec> will be Signed<Message>, defined later
exports.Signed = lodash_1.memoize(function (codec) { return t.intersection([codec, t.type({ signature: types_1.Signature })]); });
exports.SignedMessageCodecs = (_a = {},
    _a[MessageType.DELIVERED] = exports.Signed(exports.Delivered),
    _a[MessageType.PROCESSED] = exports.Signed(exports.Processed),
    _a[MessageType.SECRET_REQUEST] = exports.Signed(exports.SecretRequest),
    _a[MessageType.SECRET_REVEAL] = exports.Signed(exports.SecretReveal),
    _a[MessageType.LOCKED_TRANSFER] = exports.Signed(exports.LockedTransfer),
    _a[MessageType.REFUND_TRANSFER] = exports.Signed(exports.RefundTransfer),
    _a[MessageType.UNLOCK] = exports.Signed(exports.Unlock),
    _a[MessageType.LOCK_EXPIRED] = exports.Signed(exports.LockExpired),
    _a);
//# sourceMappingURL=types.js.map