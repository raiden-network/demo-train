/// <reference types="lodash" />
/**
 * These io-ts codecs validate and decode JSON Raiden messages
 * They include BigNumber strings validation, enum validation (if needed), Address checksum
 * validation, etc, and converting everything to its respective object, where needed.
 */
import * as t from 'io-ts';
import { EnumType, Signature } from '../utils/types';
export declare enum MessageType {
    DELIVERED = "Delivered",
    PROCESSED = "Processed",
    SECRET_REQUEST = "SecretRequest",
    SECRET_REVEAL = "RevealSecret",
    LOCKED_TRANSFER = "LockedTransfer",
    REFUND_TRANSFER = "RefundTransfer",
    UNLOCK = "Secret",
    LOCK_EXPIRED = "LockExpired"
}
export declare const MessageTypeC: EnumType<MessageType>;
export declare const Message: t.TypeC<{
    type: EnumType<MessageType>;
}>;
export declare const Delivered: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.DELIVERED>;
    delivered_message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>;
export interface Delivered extends t.TypeOf<typeof Delivered> {
}
export declare const Processed: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.PROCESSED>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>;
export interface Processed extends t.TypeOf<typeof Processed> {
}
export declare const SecretRequest: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.SECRET_REQUEST>;
    payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>;
export interface SecretRequest extends t.TypeOf<typeof SecretRequest> {
}
export declare const SecretReveal: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.SECRET_REVEAL>;
    secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>;
export interface SecretReveal extends t.TypeOf<typeof SecretReveal> {
}
export declare const EnvelopeMessage: t.IntersectionC<[t.TypeC<{
    chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>;
export declare const LockedTransfer: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.LOCKED_TRANSFER>;
}>, t.IntersectionC<[t.TypeC<{
    payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    lock: t.TypeC<{
        type: t.LiteralC<"Lock">;
        amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>;
    target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>]>]>;
export interface LockedTransfer extends t.TypeOf<typeof LockedTransfer> {
}
export declare const RefundTransfer: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.REFUND_TRANSFER>;
}>, t.IntersectionC<[t.TypeC<{
    payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    lock: t.TypeC<{
        type: t.LiteralC<"Lock">;
        amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>;
    target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>]>]>;
export interface RefundTransfer extends t.TypeOf<typeof RefundTransfer> {
}
export declare const Unlock: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.UNLOCK>;
    payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
}>, t.IntersectionC<[t.TypeC<{
    chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>]>;
export interface Unlock extends t.TypeOf<typeof Unlock> {
}
export declare const LockExpired: t.IntersectionC<[t.TypeC<{
    type: t.LiteralC<MessageType.LOCK_EXPIRED>;
    recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>, t.IntersectionC<[t.TypeC<{
    message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
}>, t.TypeC<{
    type: EnumType<MessageType>;
}>]>]>]>;
export interface LockExpired extends t.TypeOf<typeof LockExpired> {
}
export declare type Message = Delivered | Processed | SecretRequest | SecretReveal | LockedTransfer | RefundTransfer | Unlock | LockExpired;
export declare type EnvelopeMessage = LockedTransfer | RefundTransfer | Unlock | LockExpired;
export declare const Signed: (<C extends t.Mixed>(codec: C) => t.IntersectionC<[C, t.TypeC<{
    signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
}>]>) & import("lodash").MemoizedFunction;
export declare type Signed<M extends Message> = M & {
    signature: Signature;
};
export declare const SignedMessageCodecs: {
    readonly [T in MessageType]: t.Mixed;
};
