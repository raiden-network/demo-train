"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
/* One-shot send payload.message to meta.address user in transport */
exports.messageSend = typesafe_actions_1.createStandardAction('messageSend')();
/**
 * payload.message was received on payload.ts (timestamp) from meta.address
 * payload.userId and payload.roomId are optional and specific to matrix transport, as sender info
 */
exports.messageReceived = typesafe_actions_1.createStandardAction('messageReceived').map(function (_a, meta) {
    var text = _a.text, message = _a.message, ts = _a.ts, userId = _a.userId, roomId = _a.roomId;
    return ({ payload: { text: text, message: message, ts: ts || Date.now(), userId: userId, roomId: roomId }, meta: meta });
});
//# sourceMappingURL=actions.js.map