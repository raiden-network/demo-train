import { Signer } from 'ethers';
import { Address, Hash, HexString, Signature } from '../utils/types';
import { SignedBalanceProof } from '../channels/types';
import { EnvelopeMessage, Message, Signed } from './types';
/**
 * Create the messageHash for a given EnvelopeMessage
 *
 * @param message EnvelopeMessage to pack
 * @returns Hash of the message pack
 */
export declare function createMessageHash(message: EnvelopeMessage): Hash;
/**
 * Pack a message in a hex-string format, **without** signature
 * This packed hex-byte-array can then be used for signing.
 * On Raiden python client, this is the output of `_data_to_sign` method of the messages, as the
 * actual packed encoding was once used for binary transport protocols, but nowadays is used only
 * for generating data to be signed, which is the purpose of our implementation.
 *
 * @param message Message to be packed
 * @returns HexBytes hex-encoded string data representing message in binary format
 */
export declare function packMessage(message: Message): HexString<12> | HexString<180> | HexString<116> | HexString<44>;
/**
 * Typeguard to check if a message contains a valid signature
 *
 * @param message  May or may not be a signed message
 * @returns  Boolean if message is signed
 */
export declare function isSigned<M extends Message & {
    signature?: Signature;
}>(message: M): message is Signed<M>;
/**
 * Requires a signed message and returns its signer address
 *
 * @param message  Signed message to retrieve signer address
 * @returns  Address which signed message
 */
export declare function getMessageSigner(message: Signed<Message>): Address;
/**
 * Get the SignedBalanceProof associated with an EnvelopeMessage
 *
 * @param message  Signed EnvelopeMessage
 * @returns SignedBalanceProof object for message
 */
export declare function getBalanceProofFromEnvelopeMessage(message: Signed<EnvelopeMessage>): SignedBalanceProof;
/**
 * Encode a Message as a JSON string
 * Uses lossless-json to encode BigNumbers as JSON 'number' type, as Raiden
 *
 * @param message Message object to be serialized
 * @returns JSON string
 */
export declare function encodeJsonMessage<M extends Message>(message: Signed<M>): string;
/**
 * Try to decode text as a Message, using lossless-json to decode BigNumbers
 * Throws if can't decode, or message is invalid regarding any of the encoded constraints
 *
 * @param text JSON string to try to decode
 * @returns Message object
 */
export declare function decodeJsonMessage(text: string): Signed<Message>;
/**
 * Pack message and request signer to sign it, and returns signed message
 *
 * @param signer  Signer instance
 * @param message Unsigned message to pack and sign
 * @returns  Promise to signed message
 */
export declare function signMessage<M extends Message>(signer: Signer, message: M): Promise<Signed<M>>;
