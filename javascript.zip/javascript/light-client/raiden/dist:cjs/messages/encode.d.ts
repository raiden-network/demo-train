import { Message } from './types';
/**
 * Pack a message in a hex-string format, **without** signature
 * This packed hex-byte-array can then be used for signing.
 * On Raiden python client, this is the output of `_data_to_sign` method of the messages, as the
 * actual packed encoding was once used for binary transport protocols, but nowadays is used only
 * for generating data to be signed, which is the purpose of our implementation.
 *
 * @param message Message to be packed
 * @returns HexBytes hex-encoded string data representing message in binary format
 */
export declare function packMessage(message: Message): import("io-ts").Branded<string, import("../utils/types").HexStringB<180>> | import("io-ts").Branded<string, import("../utils/types").HexStringB<12>> | import("io-ts").Branded<string, import("../utils/types").HexStringB<116>> | import("io-ts").Branded<string, import("../utils/types").HexStringB<44>>;
