"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
// import * as t from 'io-ts';
var ThrowReporter_1 = require("io-ts/lib/ThrowReporter");
var utils_1 = require("ethers/utils");
var bytes_1 = require("ethers/utils/bytes");
var constants_1 = require("ethers/constants");
var types_1 = require("../utils/types");
var data_1 = require("../utils/data");
var types_2 = require("./types");
var CMDIDs = (_a = {},
    _a[types_2.MessageType.DELIVERED] = 12,
    _a[types_2.MessageType.PROCESSED] = 0,
    _a[types_2.MessageType.SECRET_REQUEST] = 3,
    _a[types_2.MessageType.SECRET_REVEAL] = 11,
    _a[types_2.MessageType.LOCKED_TRANSFER] = 7,
    _a[types_2.MessageType.REFUND_TRANSFER] = 8,
    _a[types_2.MessageType.UNLOCK] = 4,
    _a[types_2.MessageType.LOCK_EXPIRED] = 13,
    _a);
/**
 * Create the messageHash for a given EnvelopeMessage
 *
 * @param message EnvelopeMessage to pack
 * @returns Hash of the message pack
 */
function createMessageHash(message) {
    switch (message.type) {
        case types_2.MessageType.LOCKED_TRANSFER:
        case types_2.MessageType.REFUND_TRANSFER:
            // hash of packed representation of the whole message
            return utils_1.keccak256(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.nonce, 8),
                data_1.encode(message.chain_id, 32),
                data_1.encode(message.message_identifier, 8),
                data_1.encode(message.payment_identifier, 8),
                data_1.encode(message.lock.expiration, 32),
                data_1.encode(message.token_network_address, 20),
                data_1.encode(message.token, 20),
                data_1.encode(message.channel_identifier, 32),
                data_1.encode(message.recipient, 20),
                data_1.encode(message.target, 20),
                data_1.encode(message.initiator, 20),
                data_1.encode(message.locksroot, 32),
                data_1.encode(message.lock.secrethash, 32),
                data_1.encode(message.transferred_amount, 32),
                data_1.encode(message.locked_amount, 32),
                data_1.encode(message.lock.amount, 32),
                data_1.encode(message.fee, 32),
            ]));
        case types_2.MessageType.UNLOCK:
            return utils_1.keccak256(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.chain_id, 32),
                data_1.encode(message.message_identifier, 8),
                data_1.encode(message.payment_identifier, 8),
                data_1.encode(message.token_network_address, 20),
                data_1.encode(message.secret, 32),
                data_1.encode(message.nonce, 8),
                data_1.encode(message.channel_identifier, 32),
                data_1.encode(message.transferred_amount, 32),
                data_1.encode(message.locked_amount, 32),
                data_1.encode(message.locksroot, 32),
            ]));
        case types_2.MessageType.LOCK_EXPIRED:
            return utils_1.keccak256(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.nonce, 8),
                data_1.encode(message.chain_id, 32),
                data_1.encode(message.message_identifier, 8),
                data_1.encode(message.token_network_address, 20),
                data_1.encode(message.channel_identifier, 32),
                data_1.encode(message.recipient, 20),
                data_1.encode(message.locksroot, 32),
                data_1.encode(message.secrethash, 32),
                data_1.encode(message.transferred_amount, 32),
                data_1.encode(message.locked_amount, 32),
            ]));
    }
}
exports.createMessageHash = createMessageHash;
/**
 * Pack a message in a hex-string format, **without** signature
 * This packed hex-byte-array can then be used for signing.
 * On Raiden python client, this is the output of `_data_to_sign` method of the messages, as the
 * actual packed encoding was once used for binary transport protocols, but nowadays is used only
 * for generating data to be signed, which is the purpose of our implementation.
 *
 * @param message Message to be packed
 * @returns HexBytes hex-encoded string data representing message in binary format
 */
function packMessage(message) {
    switch (message.type) {
        case types_2.MessageType.DELIVERED:
            return bytes_1.hexlify(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.delivered_message_identifier, 8),
            ]));
        case types_2.MessageType.PROCESSED:
            return bytes_1.hexlify(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.message_identifier, 8),
            ]));
        case types_2.MessageType.LOCKED_TRANSFER:
        case types_2.MessageType.REFUND_TRANSFER:
        case types_2.MessageType.UNLOCK:
        case types_2.MessageType.LOCK_EXPIRED: {
            var messageHash = createMessageHash(message), balanceHash = (message.transferred_amount.isZero() &&
                message.locked_amount.isZero() &&
                message.locksroot === constants_1.HashZero
                ? constants_1.HashZero
                : utils_1.keccak256(bytes_1.concat([
                    data_1.encode(message.transferred_amount, 32),
                    data_1.encode(message.locked_amount, 32),
                    data_1.encode(message.locksroot, 32),
                ])));
            return bytes_1.hexlify(bytes_1.concat([
                data_1.encode(message.token_network_address, 20),
                data_1.encode(message.chain_id, 32),
                data_1.encode(1, 32),
                data_1.encode(message.channel_identifier, 32),
                data_1.encode(balanceHash, 32),
                data_1.encode(message.nonce, 32),
                data_1.encode(messageHash, 32),
            ]));
        }
        case types_2.MessageType.SECRET_REQUEST:
            return bytes_1.hexlify(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.message_identifier, 8),
                data_1.encode(message.payment_identifier, 8),
                data_1.encode(message.secrethash, 32),
                data_1.encode(message.amount, 32),
                data_1.encode(message.expiration, 32),
            ]));
        case types_2.MessageType.SECRET_REVEAL:
            return bytes_1.hexlify(bytes_1.concat([
                data_1.encode(CMDIDs[message.type], 1),
                data_1.encode(0, 3),
                data_1.encode(message.message_identifier, 8),
                data_1.encode(message.secret, 32),
            ]));
    }
}
exports.packMessage = packMessage;
/**
 * Typeguard to check if a message contains a valid signature
 *
 * @param message  May or may not be a signed message
 * @returns  Boolean if message is signed
 */
function isSigned(message) {
    return types_1.Signature.is(message.signature);
}
exports.isSigned = isSigned;
/**
 * Requires a signed message and returns its signer address
 *
 * @param message  Signed message to retrieve signer address
 * @returns  Address which signed message
 */
function getMessageSigner(message) {
    return utils_1.verifyMessage(bytes_1.arrayify(packMessage(message)), message.signature);
}
exports.getMessageSigner = getMessageSigner;
/**
 * Get the SignedBalanceProof associated with an EnvelopeMessage
 *
 * @param message  Signed EnvelopeMessage
 * @returns SignedBalanceProof object for message
 */
function getBalanceProofFromEnvelopeMessage(message) {
    return {
        chainId: message.chain_id,
        tokenNetworkAddress: message.token_network_address,
        channelId: message.channel_identifier,
        nonce: message.nonce,
        transferredAmount: message.transferred_amount,
        lockedAmount: message.locked_amount,
        locksroot: message.locksroot,
        messageHash: createMessageHash(message),
        signature: message.signature,
        sender: getMessageSigner(message),
    };
}
exports.getBalanceProofFromEnvelopeMessage = getBalanceProofFromEnvelopeMessage;
/**
 * Encode a Message as a JSON string
 * Uses lossless-json to encode BigNumbers as JSON 'number' type, as Raiden
 *
 * @param message Message object to be serialized
 * @returns JSON string
 */
function encodeJsonMessage(message) {
    var codec = types_2.SignedMessageCodecs[message.type];
    return data_1.losslessStringify(codec.encode(message));
}
exports.encodeJsonMessage = encodeJsonMessage;
/**
 * Try to decode text as a Message, using lossless-json to decode BigNumbers
 * Throws if can't decode, or message is invalid regarding any of the encoded constraints
 *
 * @param text JSON string to try to decode
 * @returns Message object
 */
function decodeJsonMessage(text) {
    var parsed = data_1.losslessParse(text);
    if (!types_2.Message.is(parsed))
        throw new Error("Could not find Message \"type\" in " + text);
    var decoded = types_2.SignedMessageCodecs[parsed.type].decode(parsed);
    if (decoded.isLeft())
        throw ThrowReporter_1.ThrowReporter.report(decoded); // throws if decode failed
    return decoded.value;
}
exports.decodeJsonMessage = decodeJsonMessage;
/**
 * Pack message and request signer to sign it, and returns signed message
 *
 * @param signer  Signer instance
 * @param message Unsigned message to pack and sign
 * @returns  Promise to signed message
 */
function signMessage(signer, message) {
    return __awaiter(this, void 0, void 0, function () {
        var signature;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (isSigned(message))
                        return [2 /*return*/, message];
                    return [4 /*yield*/, signer.signMessage(bytes_1.arrayify(packMessage(message)))];
                case 1:
                    signature = (_a.sent());
                    return [2 /*return*/, __assign({}, message, { signature: signature })];
            }
        });
    });
}
exports.signMessage = signMessage;
//# sourceMappingURL=utils.js.map