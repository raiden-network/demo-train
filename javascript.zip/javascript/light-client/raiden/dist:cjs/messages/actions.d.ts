export declare const messageSend: import("typesafe-actions").PayloadMetaAC<"messageSend", {
    message: string | (import("./types").Delivered & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").RefundTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").LockExpired & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    });
}, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>;
/**
 * payload.message was received on payload.ts (timestamp) from meta.address
 * payload.userId and payload.roomId are optional and specific to matrix transport, as sender info
 */
export declare const messageReceived: (payload: {
    text: string;
    message?: (import("./types").Delivered & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").RefundTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("./types").LockExpired & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | undefined;
    ts?: number | undefined;
    userId?: string | undefined;
    roomId?: string | undefined;
}, meta: {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}) => {
    type: "messageReceived";
} & {
    payload: {
        text: string;
        message: (import("./types").Delivered & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").Processed & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").SecretRequest & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").SecretReveal & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").LockedTransfer & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").RefundTransfer & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").Unlock & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | (import("./types").LockExpired & {
            signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        }) | undefined;
        ts: number;
        userId: string | undefined;
        roomId: string | undefined;
    };
    meta: {
        address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
};
