"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
// import * as t from 'io-ts';
var utils_1 = require("ethers/utils");
var bytes_1 = require("ethers/utils/bytes");
var constants_1 = require("ethers/constants");
var types_1 = require("../utils/types");
var types_2 = require("./types");
var CMDIDs = (_a = {},
    _a[types_2.MessageType.DELIVERED] = 12,
    _a[types_2.MessageType.PROCESSED] = 0,
    _a[types_2.MessageType.SECRET_REQUEST] = 3,
    _a[types_2.MessageType.REVEAL_SECRET] = 11,
    _a[types_2.MessageType.LOCKED_TRANSFER] = 7,
    _a[types_2.MessageType.REFUND_TRANSFER] = 8,
    _a[types_2.MessageType.UNLOCK] = 4,
    _a[types_2.MessageType.LOCK_EXPIRED] = 13,
    _a);
/**
 * Encode data to a bytes array of exactly length size
 * Throw if data can't be made to fit in length.
 * @param data May be of multiple types:
 *      - number|BigNumber: Encoded in the big-endian byte-order and left-zero-padded to length
 *      - string: Must be hex-encoded string of length bytes
 *      - number[] Must be of exactly of length size (left/right-pad it before if needed)
 * @param length The expected length of the byte array
 * @returns Uint8Array byte-array of length, suitable to be concatenated or hexlified
 */
function encode(data, length) {
    var bytes;
    if (typeof data === 'number')
        data = utils_1.bigNumberify(data);
    if (types_1.BigNumberC.is(data)) {
        if (data.lt(0))
            throw new Error('Number is negative');
        bytes = bytes_1.arrayify(data);
        if (bytes.length > length)
            throw new Error('Number too large');
        bytes = bytes_1.padZeros(bytes, length);
    }
    else if (typeof data === 'string' || bytes_1.isArrayish(data)) {
        bytes = bytes_1.arrayify(data);
        if (bytes.length !== length)
            throw new Error('Uint8Array or hex string must be of exact length');
    }
    else {
        throw new Error('data is not a HexString or Uint8Array');
    }
    return bytes;
}
function createBalanceHash(message) {
    return (message.transferred_amount.isZero() &&
        message.locked_amount.isZero() &&
        message.locksroot === constants_1.HashZero
        ? constants_1.HashZero
        : utils_1.keccak256(bytes_1.concat([
            encode(message.transferred_amount, 32),
            encode(message.locked_amount, 32),
            encode(message.locksroot, 32),
        ])));
}
function packBalanceProof(message, balanceHash, messageHash) {
    return bytes_1.hexlify(bytes_1.concat([
        encode(message.token_network_address, 20),
        encode(message.chain_id, 32),
        encode(1, 32),
        encode(message.channel_identifier, 32),
        encode(balanceHash, 32),
        encode(message.nonce, 32),
        encode(messageHash, 32),
    ]));
}
/**
 * Pack a message in a hex-string format, **without** signature
 * This packed hex-byte-array can then be used for signing.
 * On Raiden python client, this is the output of `_data_to_sign` method of the messages, as the
 * actual packed encoding was once used for binary transport protocols, but nowadays is used only
 * for generating data to be signed, which is the purpose of our implementation.
 *
 * @param message Message to be packed
 * @returns HexBytes hex-encoded string data representing message in binary format
 */
function packMessage(message) {
    var messageHash, balanceHash;
    switch (message.type) {
        case types_2.MessageType.DELIVERED:
            return bytes_1.hexlify(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.delivered_message_identifier, 8),
            ]));
        case types_2.MessageType.PROCESSED:
            return bytes_1.hexlify(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.message_identifier, 8),
            ]));
        case types_2.MessageType.LOCKED_TRANSFER:
        case types_2.MessageType.REFUND_TRANSFER:
            // hash of packed representation of the whole message
            messageHash = utils_1.keccak256(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.nonce, 8),
                encode(message.chain_id, 32),
                encode(message.message_identifier, 8),
                encode(message.payment_identifier, 8),
                encode(message.lock.expiration, 32),
                encode(message.token_network_address, 20),
                encode(message.token, 20),
                encode(message.channel_identifier, 32),
                encode(message.recipient, 20),
                encode(message.target, 20),
                encode(message.initiator, 20),
                encode(message.locksroot, 32),
                encode(message.lock.secrethash, 32),
                encode(message.transferred_amount, 32),
                encode(message.locked_amount, 32),
                encode(message.lock.amount, 32),
                encode(message.fee, 32),
            ]));
            balanceHash = createBalanceHash(message);
            return packBalanceProof(message, balanceHash, messageHash);
        case types_2.MessageType.UNLOCK:
            messageHash = utils_1.keccak256(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.chain_id, 32),
                encode(message.message_identifier, 8),
                encode(message.payment_identifier, 8),
                encode(message.token_network_address, 20),
                encode(message.secret, 32),
                encode(message.nonce, 8),
                encode(message.channel_identifier, 32),
                encode(message.transferred_amount, 32),
                encode(message.locked_amount, 32),
                encode(message.locksroot, 32),
            ]));
            balanceHash = createBalanceHash(message);
            return packBalanceProof(message, balanceHash, messageHash);
        case types_2.MessageType.LOCK_EXPIRED:
            messageHash = utils_1.keccak256(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.nonce, 8),
                encode(message.chain_id, 32),
                encode(message.message_identifier, 8),
                encode(message.token_network_address, 20),
                encode(message.channel_identifier, 32),
                encode(message.recipient, 20),
                encode(message.locksroot, 32),
                encode(message.secrethash, 32),
                encode(message.transferred_amount, 32),
                encode(message.locked_amount, 32),
            ]));
            balanceHash = createBalanceHash(message);
            return packBalanceProof(message, balanceHash, messageHash);
        case types_2.MessageType.SECRET_REQUEST:
            return bytes_1.hexlify(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.message_identifier, 8),
                encode(message.payment_identifier, 8),
                encode(message.secrethash, 32),
                encode(message.amount, 32),
                encode(message.expiration, 32),
            ]));
        case types_2.MessageType.REVEAL_SECRET:
            return bytes_1.hexlify(bytes_1.concat([
                encode(CMDIDs[message.type], 1),
                encode(0, 3),
                encode(message.message_identifier, 8),
                encode(message.secret, 32),
            ]));
    }
}
exports.packMessage = packMessage;
//# sourceMappingURL=encode.js.map