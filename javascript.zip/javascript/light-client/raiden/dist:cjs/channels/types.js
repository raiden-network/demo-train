"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var t = __importStar(require("io-ts"));
var types_1 = require("../utils/types");
// Represents a HashTime-Locked amount in a channel
exports.Lock = t.type({
    type: t.literal('Lock'),
    amount: types_1.UInt(32),
    expiration: types_1.UInt(32),
    secrethash: types_1.Hash,
}, 'Lock');
/**
 * Balance Proof constructed from an EnvelopeMessage
 * Either produced by us or received from the partner, the BPs are generated from the messages
 * because BP signature requires the hash of the message, for authentication of data not included
 * nor relevant for the smartcontract/BP itself, but so for the peers (e.g. payment_id)
 */
exports.SignedBalanceProof = t.type({
    // channel data
    chainId: types_1.UInt(32),
    tokenNetworkAddress: types_1.Address,
    channelId: types_1.UInt(32),
    // balance proof data
    nonce: types_1.UInt(8),
    transferredAmount: types_1.UInt(32),
    lockedAmount: types_1.UInt(32),
    locksroot: types_1.Hash,
    messageHash: types_1.Hash,
    signature: types_1.Signature,
    sender: types_1.Address,
});
//# sourceMappingURL=types.js.map