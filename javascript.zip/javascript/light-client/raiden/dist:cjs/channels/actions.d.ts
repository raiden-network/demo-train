import { BigNumber } from 'ethers/utils';
import { Address, Hash } from '../utils/types';
declare type ChannelId = {
    tokenNetwork: Address;
    partner: Address;
};
export declare const newBlock: import("typesafe-actions").PayloadAC<"newBlock", {
    blockNumber: number;
}>;
export declare const tokenMonitored: (payload: {
    token: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    first?: boolean | undefined;
}) => {
    type: "tokenMonitored";
} & {
    payload: {
        token: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        first: boolean;
    };
};
/**
 * Channel actions receive ChannelId as 'meta' action property
 * This way, 'meta' can be used equally for request, success and error actions
 */
export declare const channelOpen: import("typesafe-actions").PayloadMetaAC<"channelOpen", {
    settleTimeout: number;
}, ChannelId>;
export declare const channelOpened: import("typesafe-actions").PayloadMetaAC<"channelOpened", {
    id: number;
    settleTimeout: number;
    openBlock: number;
    txHash: Hash;
}, ChannelId>;
export declare const channelOpenFailed: (payload: Error, meta: ChannelId) => {
    type: "channelOpenFailed";
} & {
    payload: Error;
    error: boolean;
    meta: ChannelId;
};
export declare const channelMonitored: import("typesafe-actions").PayloadMetaAC<"channelMonitored", {
    id: number;
    fromBlock?: number | undefined;
}, ChannelId>;
export declare const channelDeposit: import("typesafe-actions").PayloadMetaAC<"channelDeposit", {
    deposit: BigNumber;
}, ChannelId>;
export declare const channelDeposited: import("typesafe-actions").PayloadMetaAC<"channelDeposited", {
    id: number;
    participant: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    totalDeposit: BigNumber;
    txHash: Hash;
}, ChannelId>;
export declare const channelDepositFailed: (payload: Error, meta: ChannelId) => {
    type: "channelDepositFailed";
} & {
    payload: Error;
    error: boolean;
    meta: ChannelId;
};
export declare const channelClose: import("typesafe-actions").PayloadMetaAC<"channelClose", undefined, ChannelId>;
export declare const channelClosed: import("typesafe-actions").PayloadMetaAC<"channelClosed", {
    id: number;
    participant: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    closeBlock: number;
    txHash: Hash;
}, ChannelId>;
export declare const channelCloseFailed: (payload: Error, meta: ChannelId) => {
    type: "channelCloseFailed";
} & {
    payload: Error;
    error: boolean;
    meta: ChannelId;
};
export declare const channelSettleable: import("typesafe-actions").PayloadMetaAC<"channelSettleable", {
    settleableBlock: number;
}, ChannelId>;
export declare const channelSettle: import("typesafe-actions").PayloadMetaAC<"channelSettle", undefined, ChannelId>;
export declare const channelSettled: import("typesafe-actions").PayloadMetaAC<"channelSettled", {
    id: number;
    settleBlock: number;
    txHash: Hash;
}, ChannelId>;
export declare const channelSettleFailed: (payload: Error, meta: ChannelId) => {
    type: "channelSettleFailed";
} & {
    payload: Error;
    error: boolean;
    meta: ChannelId;
};
export {};
