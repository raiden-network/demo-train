import * as t from 'io-ts';
import { EnumType } from '../utils/types';
export declare enum ChannelState {
    opening = "opening",
    open = "open",
    closing = "closing",
    closed = "closed",
    settleable = "settleable",
    settling = "settling",
    settled = "settled"
}
export declare const ChannelStateC: EnumType<ChannelState>;
/**
 * Contains info of each side of a channel
 */
export declare const ChannelEnd: t.IntersectionC<[t.TypeC<{
    deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
}>, t.PartialC<{
    locks: t.ArrayC<t.TypeC<{
        type: t.LiteralC<"Lock">;
        amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>>;
    balanceProof: t.TypeC<{
        chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    }>;
    history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
    }>, t.IntersectionC<[t.TypeC<{
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        lock: t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>;
        target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: EnumType<import("../messages/types").MessageType>;
    }>]>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>]>>;
}>]>;
export interface ChannelEnd extends t.TypeOf<typeof ChannelEnd> {
}
export declare const Channel: t.IntersectionC<[t.TypeC<{
    own: t.IntersectionC<[t.TypeC<{
        deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.PartialC<{
        locks: t.ArrayC<t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>>;
        balanceProof: t.TypeC<{
            chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        }>;
        history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
        }>, t.IntersectionC<[t.TypeC<{
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            lock: t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>;
            target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>]>>;
    }>]>;
    partner: t.IntersectionC<[t.TypeC<{
        deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.PartialC<{
        locks: t.ArrayC<t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>>;
        balanceProof: t.TypeC<{
            chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        }>;
        history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
        }>, t.IntersectionC<[t.TypeC<{
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            lock: t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>;
            target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>]>>;
    }>]>;
}>, t.UnionC<[t.TypeC<{
    state: t.LiteralC<ChannelState.opening>;
}>, t.TypeC<{
    state: t.UnionC<[t.LiteralC<ChannelState.open>, t.LiteralC<ChannelState.closing>]>;
    id: t.NumberC;
    settleTimeout: t.NumberC;
    openBlock: t.NumberC;
}>, t.TypeC<{
    state: t.UnionC<[t.LiteralC<ChannelState.closed>, t.LiteralC<ChannelState.settleable>, t.LiteralC<ChannelState.settling>]>;
    id: t.NumberC;
    settleTimeout: t.NumberC;
    openBlock: t.NumberC;
    closeBlock: t.NumberC;
}>]>]>;
export declare type Channel = t.TypeOf<typeof Channel>;
/**
 * Channels is a mapping from tokenNetwork -> partner -> Channel
 * As in: { [tokenNetwork: Address]: { [partner: Address]: Channel } }
 * It's used as codec and type for 'channels' key in RaidenState
 * We use t.string instead of the Address branded codecs because specialized types can't be used
 * as index mapping keys.
 */
export declare const Channels: t.RecordC<t.StringC, t.RecordC<t.StringC, t.IntersectionC<[t.TypeC<{
    own: t.IntersectionC<[t.TypeC<{
        deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.PartialC<{
        locks: t.ArrayC<t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>>;
        balanceProof: t.TypeC<{
            chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        }>;
        history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
        }>, t.IntersectionC<[t.TypeC<{
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            lock: t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>;
            target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>]>>;
    }>]>;
    partner: t.IntersectionC<[t.TypeC<{
        deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.PartialC<{
        locks: t.ArrayC<t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>>;
        balanceProof: t.TypeC<{
            chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        }>;
        history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
        }>, t.IntersectionC<[t.TypeC<{
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            lock: t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>;
            target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: EnumType<import("../messages/types").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>]>>;
    }>]>;
}>, t.UnionC<[t.TypeC<{
    state: t.LiteralC<ChannelState.opening>;
}>, t.TypeC<{
    state: t.UnionC<[t.LiteralC<ChannelState.open>, t.LiteralC<ChannelState.closing>]>;
    id: t.NumberC;
    settleTimeout: t.NumberC;
    openBlock: t.NumberC;
}>, t.TypeC<{
    state: t.UnionC<[t.LiteralC<ChannelState.closed>, t.LiteralC<ChannelState.settleable>, t.LiteralC<ChannelState.settling>]>;
    id: t.NumberC;
    settleTimeout: t.NumberC;
    openBlock: t.NumberC;
    closeBlock: t.NumberC;
}>]>]>>>;
export declare type Channels = t.TypeOf<typeof Channels>;
