"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var t = __importStar(require("io-ts"));
var types_1 = require("../utils/types");
var types_2 = require("../messages/types");
var types_3 = require("./types");
var ChannelState;
(function (ChannelState) {
    ChannelState["opening"] = "opening";
    ChannelState["open"] = "open";
    ChannelState["closing"] = "closing";
    ChannelState["closed"] = "closed";
    ChannelState["settleable"] = "settleable";
    ChannelState["settling"] = "settling";
    ChannelState["settled"] = "settled";
})(ChannelState = exports.ChannelState || (exports.ChannelState = {}));
exports.ChannelStateC = new types_1.EnumType(ChannelState, 'ChannelState');
/**
 * Contains info of each side of a channel
 */
exports.ChannelEnd = t.intersection([
    t.type({
        deposit: types_1.UInt(32),
    }),
    t.partial({
        locks: t.array(types_3.Lock),
        balanceProof: types_3.SignedBalanceProof,
        history: t.record(t.string /* timestamp */, t.union([
            types_2.Signed(types_2.LockedTransfer),
            types_2.Signed(types_2.Unlock),
            types_2.Signed(types_2.LockExpired),
        ]) /* sent by this end */),
    }),
]);
exports.Channel = t.intersection([
    t.type({
        own: exports.ChannelEnd,
        partner: exports.ChannelEnd,
    }),
    t.union([
        /* union of types with literals intersection allows narrowing other props presence. e.g.:
         * if (channel.state === ChannelState.open) {
         *   id = channel.id; // <- id can't be undefined
         *   closeBlock = channel.closeBlock; // error: closeBlock only exist on states closed|settling
         * }
         */
        t.type({ state: t.literal(ChannelState.opening) }),
        t.type({
            state: t.union([t.literal(ChannelState.open), t.literal(ChannelState.closing)]),
            id: t.number,
            settleTimeout: t.number,
            openBlock: t.number,
        }),
        t.type({
            state: t.union([
                t.literal(ChannelState.closed),
                t.literal(ChannelState.settleable),
                t.literal(ChannelState.settling),
            ]),
            id: t.number,
            settleTimeout: t.number,
            openBlock: t.number,
            closeBlock: t.number,
        }),
    ]),
]);
/**
 * Channels is a mapping from tokenNetwork -> partner -> Channel
 * As in: { [tokenNetwork: Address]: { [partner: Address]: Channel } }
 * It's used as codec and type for 'channels' key in RaidenState
 * We use t.string instead of the Address branded codecs because specialized types can't be used
 * as index mapping keys.
 */
exports.Channels = t.record(t.string /* tokenNetwork: Address */, t.record(t.string /* partner: Address */, exports.Channel));
//# sourceMappingURL=state.js.map