"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var typesafe_actions_1 = require("typesafe-actions");
var lodash_1 = require("lodash");
var constants_1 = require("ethers/constants");
var channels_1 = require("../channels");
var actions_1 = require("./actions");
var actions_2 = require("../store/actions");
var constants_2 = require("../constants");
var ethers_1 = require("../utils/ethers");
/**
 * Register for new block events and emit newBlock actions for new blocks
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param provider  RaidenEpicDeps members
 * @returns  Observable of newBlock actions
 */
exports.initNewBlockEpic = function (action$, _a, _b) {
    var provider = _b.provider;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.raidenInit)), operators_1.mergeMap(function () { return ethers_1.fromEthersEvent(provider, 'block'); }), operators_1.map(function (blockNumber) { return actions_1.newBlock({ blockNumber: blockNumber }); }));
};
/**
 * Monitor registry for new token networks and monitor them
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param registryContract,contractsInfo  RaidenEpicDeps members
 * @returns  Observable of tokenMonitored actions
 */
exports.initMonitorRegistryEpic = function (action$, state$, _a) {
    var registryContract = _a.registryContract, contractsInfo = _a.contractsInfo;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.raidenInit)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var state = _a[1];
        return rxjs_1.merge(
        // monitor old (in case of empty tokens) and new registered tokens
        // and starts monitoring every registered token
        ethers_1.getEventsStream(registryContract, [registryContract.filters.TokenNetworkCreated(null, null)], lodash_1.isEmpty(state.tokens) ? rxjs_1.of(contractsInfo.TokenNetworkRegistry.block_number) : undefined, lodash_1.isEmpty(state.tokens) ? rxjs_1.of(state.blockNumber) : undefined).pipe(operators_1.withLatestFrom(state$.pipe(operators_1.startWith(state))), operators_1.map(function (_a) {
            var _b = _a[0], token = _b[0], tokenNetwork = _b[1], state = _a[1];
            return actions_1.tokenMonitored({
                token: token,
                tokenNetwork: tokenNetwork,
                first: !(token in state.tokens),
            });
        })), 
        // monitor previously monitored tokens
        rxjs_1.from(Object.entries(state.tokens)).pipe(operators_1.map(function (_a) {
            var token = _a[0], tokenNetwork = _a[1];
            return actions_1.tokenMonitored({ token: token, tokenNetwork: tokenNetwork });
        })));
    }));
};
/**
 * Monitor channels previously already on state
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelMonitored actions
 */
exports.initMonitorChannelsEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.raidenInit)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var _i, _b, _c, tokenNetwork, obj, _d, _e, _f, partner, channel;
        var state = _a[1];
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _i = 0, _b = Object.entries(state.channels);
                    _g.label = 1;
                case 1:
                    if (!(_i < _b.length)) return [3 /*break*/, 6];
                    _c = _b[_i], tokenNetwork = _c[0], obj = _c[1];
                    _d = 0, _e = Object.entries(obj);
                    _g.label = 2;
                case 2:
                    if (!(_d < _e.length)) return [3 /*break*/, 5];
                    _f = _e[_d], partner = _f[0], channel = _f[1];
                    if (channel.state === channels_1.ChannelState.opening)
                        return [3 /*break*/, 4];
                    return [4 /*yield*/, actions_1.channelMonitored({ id: channel.id }, { tokenNetwork: tokenNetwork, partner: partner })];
                case 3:
                    _g.sent();
                    _g.label = 4;
                case 4:
                    _d++;
                    return [3 /*break*/, 2];
                case 5:
                    _i++;
                    return [3 /*break*/, 1];
                case 6: return [2 /*return*/];
            }
        });
    }));
};
/**
 * Monitor provider to ensure account continues to be available and network stays the same
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param address,network,provider  RaidenEpicDeps members
 * @returns  Observable of raidenShutdown actions
 */
exports.initMonitorProviderEpic = function (action$, _a, _b) {
    var address = _b.address, network = _b.network, provider = _b.provider;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.raidenInit)), operators_1.mergeMap(function () { return provider.listAccounts(); }), 
    // at init time, check if our address is in provider's accounts list
    // if not, it means Signer is a local Wallet or another non-provider-side account
    // if yes, poll accounts every 1s and monitors if address is still there
    // also, every 1s poll current provider network and monitors if it's the same
    // if any check fails, emits RaidenShutdownAction, nothing otherwise
    // Poll reason from: https://github.com/MetaMask/faq/blob/master/DEVELOPERS.md
    // first/init-time check
    operators_1.map(function (accounts) { return accounts.includes(address); }), operators_1.mergeMap(function (isProviderAccount) {
        return rxjs_1.interval(provider.pollingInterval).pipe(operators_1.mergeMap(function () {
            return rxjs_1.merge(
            // if isProviderAccount, also polls and monitors accounts list
            isProviderAccount
                ? rxjs_1.from(provider.listAccounts()).pipe(operators_1.mergeMap(function (accounts) {
                    return !accounts.includes(address)
                        ? rxjs_1.of(actions_2.raidenShutdown({ reason: constants_2.ShutdownReason.ACCOUNT_CHANGED }))
                        : rxjs_1.EMPTY;
                }))
                : rxjs_1.EMPTY, 
            // unconditionally monitors network changes
            rxjs_1.from(ethers_1.getNetwork(provider)).pipe(operators_1.mergeMap(function (curNetwork) {
                return curNetwork.chainId !== network.chainId
                    ? rxjs_1.of(actions_2.raidenShutdown({ reason: constants_2.ShutdownReason.NETWORK_CHANGED }))
                    : rxjs_1.EMPTY;
            })));
        }));
    }));
};
/**
 * Starts monitoring a token network for events
 * When this action goes through (because a former or new token registry event was deteceted),
 * subscribe to events and emit respective actions to the stream. Currently:
 * - ChannelOpened events with us or by us
 *
 * @param action$  Observable of tokenMonitored actions
 * @param state$  Observable of RaidenStates
 * @param matrix$  RaidenEpicDeps members
 * @returns  Observable of channelOpened actions
 */
exports.tokenMonitoredEpic = function (action$, state$, _a) {
    var address = _a.address, getTokenNetworkContract = _a.getTokenNetworkContract, contractsInfo = _a.contractsInfo;
    return state$.pipe(operators_1.map(function (state) { return state.blockNumber; }), operators_1.multicast(new rxjs_1.ReplaySubject(1), function (blockNumber$) {
        return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.tokenMonitored)), operators_1.groupBy(function (action) { return action.payload.tokenNetwork; }), operators_1.mergeMap(function (grouped$) {
            return grouped$.pipe(operators_1.exhaustMap(function (action) {
                var tokenNetworkContract = getTokenNetworkContract(action.payload.tokenNetwork);
                var filters = [
                    tokenNetworkContract.filters.ChannelOpened(null, address, null, null),
                    tokenNetworkContract.filters.ChannelOpened(null, null, address, null),
                ];
                console.log('getEventsStream', action, blockNumber$);
                return ethers_1.getEventsStream(tokenNetworkContract, filters, 
                // if first time monitoring this token network,
                // fetch TokenNetwork's pastEvents since registry deployment as fromBlock$
                action.payload.first
                    ? rxjs_1.of(contractsInfo.TokenNetworkRegistry.block_number)
                    : undefined, action.payload.first ? blockNumber$ : undefined).pipe(operators_1.filter(function (_a) {
                    var p1 = _a[1], p2 = _a[2];
                    return p1 === address || p2 === address;
                }), operators_1.map(function (_a) {
                    var id = _a[0], p1 = _a[1], p2 = _a[2], settleTimeout = _a[3], event = _a[4];
                    return actions_1.channelOpened({
                        id: id.toNumber(),
                        settleTimeout: settleTimeout.toNumber(),
                        openBlock: event.blockNumber,
                        txHash: event.transactionHash,
                    }, {
                        tokenNetwork: tokenNetworkContract.address,
                        partner: address === p1 ? p2 : p1,
                    });
                }));
            }));
        }));
    }));
};
/**
 * Monitors a channel for channel Events
 * Can be called either at initialization time (for previously known channels on previously
 * monitored TokenNetwork) or by a new detected ChannelOpenedAction. On the later case,
 * also fetches events since Channel.openBlock.
 * Currently monitored events:
 * - ChannelNewDeposit, fires a channelDeposited action
 * - ChannelClosedEvent, fires a channelClosed action
 * - ChannelSettledEvent, fires a channelSettled action and completes that channel observable
 *
 * @param action$  Observable of channelMonitored actions
 * @param state$  Observable of RaidenStates
 * @param matrix$  RaidenEpicDeps members
 * @returns  Observable of channelDeposited,channelClosed,channelSettled actions
 */
exports.channelMonitoredEpic = function (action$, state$, _a) {
    var getTokenNetworkContract = _a.getTokenNetworkContract;
    return state$.pipe(operators_1.map(function (state) { return state.blockNumber; }), operators_1.multicast(new rxjs_1.ReplaySubject(1), function (blockNumber$) {
        return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelMonitored)), operators_1.groupBy(function (action) { return action.payload.id + "#" + action.meta.partner + "@" + action.meta.tokenNetwork; }), operators_1.mergeMap(function (grouped$) {
            return grouped$.pipe(operators_1.exhaustMap(function (action) {
                var tokenNetworkContract = getTokenNetworkContract(action.meta.tokenNetwork);
                // TODO: instead of one filter for each event, optimize to one filter per channel
                // it requires ethers to support OR filters for topics:
                // https://github.com/ethers-io/ethers.js/issues/437
                // can we hook to provider.on directly and decoding the events ourselves?
                var depositFilter = tokenNetworkContract.filters.ChannelNewDeposit(action.payload.id, null, null), closedFilter = tokenNetworkContract.filters.ChannelClosed(action.payload.id, null, null), settledFilter = tokenNetworkContract.filters.ChannelSettled(action.payload.id, null, null);
                return rxjs_1.merge(ethers_1.getEventsStream(tokenNetworkContract, [depositFilter], 
                // if channelMonitored triggered by ChannelOpenedAction,
                // fetch Channel's pastEvents since channelOpened blockNumber as fromBlock$
                action.payload.fromBlock ? rxjs_1.of(action.payload.fromBlock) : undefined, action.payload.fromBlock ? blockNumber$ : undefined).pipe(operators_1.map(function (_a) {
                    var id = _a[0], participant = _a[1], totalDeposit = _a[2], event = _a[3];
                    return actions_1.channelDeposited({
                        id: id.toNumber(),
                        participant: participant,
                        totalDeposit: totalDeposit,
                        txHash: event.transactionHash,
                    }, action.meta);
                })), ethers_1.getEventsStream(tokenNetworkContract, [closedFilter], action.payload.fromBlock ? rxjs_1.of(action.payload.fromBlock) : undefined, action.payload.fromBlock ? blockNumber$ : undefined).pipe(operators_1.map(function (_a) {
                    var id = _a[0], participant = _a[1], event = _a[3];
                    return actions_1.channelClosed({
                        id: id.toNumber(),
                        participant: participant,
                        closeBlock: event.blockNumber,
                        txHash: event.transactionHash,
                    }, action.meta);
                })), ethers_1.getEventsStream(tokenNetworkContract, [settledFilter], action.payload.fromBlock ? rxjs_1.of(action.payload.fromBlock) : undefined, action.payload.fromBlock ? blockNumber$ : undefined).pipe(operators_1.map(function (_a) {
                    var id = _a[0], event = _a[3];
                    return actions_1.channelSettled({
                        id: id.toNumber(),
                        settleBlock: event.blockNumber,
                        txHash: event.transactionHash,
                    }, action.meta);
                }))).pipe(
                // takeWhile tends to broad input to generic Action. We need to narrow it by hand
                operators_1.takeWhile(lodash_1.negate(typesafe_actions_1.isActionOf(actions_1.channelSettled)), true));
            }));
        }));
    }));
};
/**
 * A channelOpen action requested by user
 * Needs to be called on a previously monitored tokenNetwork. Calls TokenNetwork.openChannel
 * with given parameters. If tx goes through successfuly, stop as ChannelOpened success action
 * will instead be detected and fired by tokenMonitoredEpic. If anything detectable goes wrong,
 * fires a ChannnelOpenActionFailed instead
 *
 * @param action$  Observable of channelOpen actions
 * @param state$  Observable of RaidenStates
 * @param getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelOpenFailed actions
 */
exports.channelOpenEpic = function (action$, state$, _a) {
    var getTokenNetworkContract = _a.getTokenNetworkContract;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelOpen)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var action = _a[0], state = _a[1];
        var tokenNetwork = getTokenNetworkContract(action.meta.tokenNetwork);
        var channelState = lodash_1.get(state.channels, [
            action.meta.tokenNetwork,
            action.meta.partner,
            'state',
        ]);
        // proceed only if channel is in 'opening' state, set by this action
        if (channelState !== channels_1.ChannelState.opening)
            return rxjs_1.of(actions_1.channelOpenFailed(new Error("Invalid channel state: " + channelState), action.meta));
        // send openChannel transaction !!!
        return rxjs_1.from(tokenNetwork.functions.openChannel(state.address, action.meta.partner, action.payload.settleTimeout)).pipe(operators_1.mergeMap(function (tx) { return __awaiter(_this, void 0, void 0, function () { var _a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, tx.wait()];
                case 1: return [2 /*return*/, (_a.receipt = _b.sent(), _a.tx = tx, _a)];
            }
        }); }); }), operators_1.map(function (_a) {
            var receipt = _a.receipt, tx = _a.tx;
            if (!receipt.status)
                throw new Error("openChannel transaction \"" + tx.hash + "\" failed");
            return tx.hash;
        }), 
        // if succeeded, return a empty/completed observable
        // actual ChannelOpenedAction will be detected and handled by tokenMonitoredEpic
        // if any error happened on tx call/pipeline, mergeMap below won't be hit, and catchError
        // will then emit the channelOpenFailed action instead
        operators_1.mergeMapTo(rxjs_1.EMPTY), operators_1.catchError(function (error) { return rxjs_1.of(actions_1.channelOpenFailed(error, action.meta)); }));
    }));
};
/**
 * When we see a new ChannelOpenedAction event, starts monitoring channel
 *
 * @param action$  Observable of channelOpened actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelMonitored actions
 */
exports.channelOpenedEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelOpened)), operators_1.withLatestFrom(state$), 
    // proceed only if channel is in 'open' state and a deposit is required
    operators_1.filter(function (_a) {
        var action = _a[0], state = _a[1];
        var channel = lodash_1.get(state.channels, [
            action.meta.tokenNetwork,
            action.meta.partner,
        ]);
        return !!channel && channel.state === channels_1.ChannelState.open;
    }), operators_1.map(function (_a) {
        var action = _a[0];
        return actions_1.channelMonitored({
            id: action.payload.id,
            fromBlock: action.payload.openBlock,
        }, action.meta);
    }));
};
/**
 * A ChannelDeposit action requested by user
 * Needs to be called on a previously monitored channel. Calls Token.approve for TokenNetwork
 * and then set respective setTotalDeposit. If all tx go through successfuly, stop as
 * ChannelDeposited success action will instead be detected and reacted by
 * channelMonitoredEpic. If anything detectable goes wrong, fires a ChannelDepositActionFailed
 * instead
 *
 * @param action$  Observable of channelDeposit actions
 * @param state$  Observable of RaidenStates
 * @param address,getTokenContract,getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelDepositFailed actions
 */
exports.channelDepositEpic = function (action$, state$, _a) {
    var address = _a.address, getTokenContract = _a.getTokenContract, getTokenNetworkContract = _a.getTokenNetworkContract;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelDeposit)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var action = _a[0], state = _a[1];
        var token = lodash_1.findKey(state.tokens, function (tn) { return tn === action.meta.tokenNetwork; });
        if (!token) {
            var error = new Error("token for tokenNetwork \"" + action.meta.tokenNetwork + "\" not found");
            return rxjs_1.of(actions_1.channelDepositFailed(error, action.meta));
        }
        var tokenContract = getTokenContract(token);
        var tokenNetworkContract = getTokenNetworkContract(action.meta.tokenNetwork);
        var channel = lodash_1.get(state.channels, [
            action.meta.tokenNetwork,
            action.meta.partner,
        ]);
        if (!channel || channel.state !== channels_1.ChannelState.open || channel.id === undefined) {
            var error = new Error("channel for \"" + action.meta.tokenNetwork + "\" and \"" + action.meta.partner + "\" not found or not in 'open' state");
            return rxjs_1.of(actions_1.channelDepositFailed(error, action.meta));
        }
        var channelId = channel.id;
        // send approve transaction
        return rxjs_1.from(tokenContract.functions.approve(action.meta.tokenNetwork, action.payload.deposit))
            .pipe(operators_1.tap(function (tx) { return console.log("sent approve tx \"" + tx.hash + "\" to \"" + token + "\""); }), operators_1.mergeMap(function (tx) { return __awaiter(_this, void 0, void 0, function () { var _a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, tx.wait()];
                case 1: return [2 /*return*/, (_a.receipt = _b.sent(), _a.tx = tx, _a)];
            }
        }); }); }), operators_1.map(function (_a) {
            var receipt = _a.receipt, tx = _a.tx;
            if (!receipt.status)
                throw new Error("token \"" + token + "\" approve transaction \"" + tx.hash + "\" failed");
            return tx.hash;
        }), operators_1.tap(function (txHash) { return console.log("approve tx \"" + txHash + "\" successfuly mined!"); }))
            .pipe(operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
            var state = _a[1];
            // send setTotalDeposit transaction
            return tokenNetworkContract.functions.setTotalDeposit(channelId, address, state.channels[action.meta.tokenNetwork][action.meta.partner].own.deposit.add(action.payload.deposit), action.meta.partner, { gasLimit: 100e3 });
        }), operators_1.tap(function (tx) {
            return console.log("sent setTotalDeposit tx \"" + tx.hash + "\" to \"" + action.meta.tokenNetwork + "\"");
        }), operators_1.mergeMap(function (tx) { return __awaiter(_this, void 0, void 0, function () { var _a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, tx.wait()];
                case 1: return [2 /*return*/, (_a.receipt = _b.sent(), _a.tx = tx, _a)];
            }
        }); }); }), operators_1.map(function (_a) {
            var receipt = _a.receipt, tx = _a.tx;
            if (!receipt.status)
                throw new Error("tokenNetwork \"" + action.meta.tokenNetwork + "\" setTotalDeposit transaction \"" + tx.hash + "\" failed");
            return tx.hash;
        }), operators_1.tap(function (txHash) { return console.log("setTotalDeposit tx \"" + txHash + "\" successfuly mined!"); }), 
        // if succeeded, return a empty/completed observable
        // actual ChannelDepositedAction will be detected and handled by channelMonitoredEpic
        // if any error happened on tx call/pipeline, mergeMap below won't be hit, and catchError
        // will then emit the channelDepositFailed action instead
        operators_1.mergeMapTo(rxjs_1.EMPTY), operators_1.catchError(function (error) { return rxjs_1.of(actions_1.channelDepositFailed(error, action.meta)); }));
    }));
};
/**
 * A ChannelClose action requested by user
 * Needs to be called on an opened or closing (for retries) channel.
 * If tx goes through successfuly, stop as ChannelClosed success action will instead be
 * detected and reacted by channelMonitoredEpic. If anything detectable goes wrong, fires a
 * ChannelCloseActionFailed instead
 *
 * @param action$  Observable of channelClose actions
 * @param state$  Observable of RaidenStates
 * @param getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelCloseFailed actions
 */
exports.channelCloseEpic = function (action$, state$, _a) {
    var getTokenNetworkContract = _a.getTokenNetworkContract;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelClose)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var action = _a[0], state = _a[1];
        var tokenNetworkContract = getTokenNetworkContract(action.meta.tokenNetwork);
        var channel = lodash_1.get(state.channels, [
            action.meta.tokenNetwork,
            action.meta.partner,
        ]);
        if (!channel ||
            !(channel.state === channels_1.ChannelState.open || channel.state === channels_1.ChannelState.closing) ||
            !channel.id) {
            var error = new Error("channel for \"" + action.meta.tokenNetwork + "\" and \"" + action.meta.partner + "\" not found or not in 'open' or 'closing' state");
            return rxjs_1.of(actions_1.channelCloseFailed(error, action.meta));
        }
        var channelId = channel.id;
        // send closeChannel transaction
        return rxjs_1.from(tokenNetworkContract.functions.closeChannel(channelId, action.meta.partner, constants_1.HashZero, 0, constants_1.HashZero, constants_2.SignatureZero)).pipe(operators_1.tap(function (tx) {
            return console.log("sent closeChannel tx \"" + tx.hash + "\" to \"" + action.meta.tokenNetwork + "\"");
        }), operators_1.mergeMap(function (tx) { return __awaiter(_this, void 0, void 0, function () { var _a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, tx.wait()];
                case 1: return [2 /*return*/, (_a.receipt = _b.sent(), _a.tx = tx, _a)];
            }
        }); }); }), operators_1.map(function (_a) {
            var receipt = _a.receipt, tx = _a.tx;
            if (!receipt.status)
                throw new Error("tokenNetwork \"" + action.meta.tokenNetwork + "\" closeChannel transaction \"" + tx.hash + "\" failed");
            console.log("closeChannel tx \"" + tx.hash + "\" successfuly mined!");
            return tx.hash;
        }), 
        // if succeeded, return a empty/completed observable
        // actual ChannelClosedAction will be detected and handled by channelMonitoredEpic
        // if any error happened on tx call/pipeline, mergeMap below won't be hit, and catchError
        // will then emit the channelCloseFailed action instead
        operators_1.mergeMapTo(rxjs_1.EMPTY), operators_1.catchError(function (error) { return rxjs_1.of(actions_1.channelCloseFailed(error, action.meta)); }));
    }));
};
/**
 * A ChannelSettle action requested by user
 * Needs to be called on an settleable or settling (for retries) channel.
 * If tx goes through successfuly, stop as ChannelSettled success action will instead be
 * detected and reacted by channelMonitoredEpic. If anything detectable goes wrong, fires a
 * ChannelSettleActionFailed instead
 *
 * @param action$  Observable of channelSettle actions
 * @param state$  Observable of RaidenStates
 * @param address,getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelSettleFailed actions
 */
exports.channelSettleEpic = function (action$, state$, _a) {
    var address = _a.address, getTokenNetworkContract = _a.getTokenNetworkContract;
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.channelSettle)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var action = _a[0], state = _a[1];
        var tokenNetworkContract = getTokenNetworkContract(action.meta.tokenNetwork);
        var channel = lodash_1.get(state.channels, [
            action.meta.tokenNetwork,
            action.meta.partner,
        ]);
        if (!channel ||
            !(channel.state === channels_1.ChannelState.settleable || channel.state === channels_1.ChannelState.settling) ||
            !channel.id) {
            var error = new Error("channel for \"" + action.meta.tokenNetwork + "\" and \"" + action.meta.partner + "\" not found or not in 'settleable' or 'settling' state");
            return rxjs_1.of(actions_1.channelSettleFailed(error, action.meta));
        }
        var channelId = channel.id;
        // send settleChannel transaction
        return rxjs_1.from(tokenNetworkContract.functions.settleChannel(channelId, address, constants_1.Zero, constants_1.Zero, constants_1.HashZero, action.meta.partner, constants_1.Zero, constants_1.Zero, constants_1.HashZero)).pipe(operators_1.tap(function (tx) {
            return console.log("sent settleChannel tx \"" + tx.hash + "\" to \"" + action.meta.tokenNetwork + "\"");
        }), operators_1.mergeMap(function (tx) { return __awaiter(_this, void 0, void 0, function () { var _a; return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = {};
                    return [4 /*yield*/, tx.wait()];
                case 1: return [2 /*return*/, (_a.receipt = _b.sent(), _a.tx = tx, _a)];
            }
        }); }); }), operators_1.map(function (_a) {
            var receipt = _a.receipt, tx = _a.tx;
            if (!receipt.status)
                throw new Error("tokenNetwork \"" + action.meta.tokenNetwork + "\" settleChannel transaction \"" + tx.hash + "\" failed");
            console.log("settleChannel tx \"" + tx.hash + "\" successfuly mined!");
            return tx.hash;
        }), 
        // if succeeded, return a empty/completed observable
        // actual ChannelSettledAction will be detected and handled by channelMonitoredEpic
        // if any error happened on tx call/pipeline, mergeMap below won't be hit, and catchError
        // will then emit the channelSettleFailed action instead
        operators_1.mergeMapTo(rxjs_1.EMPTY), operators_1.catchError(function (error) { return rxjs_1.of(actions_1.channelSettleFailed(error, action.meta)); }));
    }));
};
/**
 * Process newBlocks, emits ChannelSettleableAction if any closed channel is now settleable
 *
 * @param action$  Observable of newBlock actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelSettleable actions
 */
exports.channelSettleableEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.newBlock)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var _b, _c, _i, tokenNetwork, _d, _e, _f, partner, channel;
        var blockNumber = _a[0].payload.blockNumber, state = _a[1];
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _b = [];
                    for (_c in state.channels)
                        _b.push(_c);
                    _i = 0;
                    _g.label = 1;
                case 1:
                    if (!(_i < _b.length)) return [3 /*break*/, 6];
                    tokenNetwork = _b[_i];
                    _d = [];
                    for (_e in state.channels[tokenNetwork])
                        _d.push(_e);
                    _f = 0;
                    _g.label = 2;
                case 2:
                    if (!(_f < _d.length)) return [3 /*break*/, 5];
                    partner = _d[_f];
                    channel = state.channels[tokenNetwork][partner];
                    if (!(channel.state === channels_1.ChannelState.closed &&
                        channel.settleTimeout && // closed channels always have settleTimeout & closeBlock set
                        channel.closeBlock &&
                        blockNumber > channel.closeBlock + channel.settleTimeout)) return [3 /*break*/, 4];
                    return [4 /*yield*/, actions_1.channelSettleable({ settleableBlock: blockNumber }, { tokenNetwork: tokenNetwork, partner: partner })];
                case 3:
                    _g.sent();
                    _g.label = 4;
                case 4:
                    _f++;
                    return [3 /*break*/, 2];
                case 5:
                    _i++;
                    return [3 /*break*/, 1];
                case 6: return [2 /*return*/];
            }
        });
    }));
};
//# sourceMappingURL=epics.js.map