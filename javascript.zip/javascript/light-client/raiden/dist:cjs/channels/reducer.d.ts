import { RaidenState } from '../store/state';
/**
 * Nested/combined reducer for channels
 * blockNumber, tokens & channels reducers get its own slice of the state, corresponding to the
 * name of the reducer. channels root reducer instead must be handled the complete state instead,
 * so it compose the output with each key/nested/combined state.
 */
export declare const channelsReducer: import("redux").Reducer<Readonly<RaidenState>, import("redux").AnyAction>;
