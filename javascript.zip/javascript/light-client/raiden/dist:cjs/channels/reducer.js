"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
var fp_1 = require("lodash/fp");
var constants_1 = require("ethers/constants");
var redux_1 = require("../utils/redux");
var actions_1 = require("./actions");
var state_1 = require("./state");
var state_2 = require("../store/state");
// state.blockNumber specific reducer, handles only newBlock action
function blockNumber(state, action) {
    if (state === void 0) { state = state_2.initialState.blockNumber; }
    if (typesafe_actions_1.isActionOf(actions_1.newBlock, action))
        return action.payload.blockNumber;
    else
        return state;
}
// state.tokens specific reducer, handles only tokenMonitored action
function tokens(state, action) {
    if (state === void 0) { state = state_2.initialState.tokens; }
    if (typesafe_actions_1.isActionOf(actions_1.tokenMonitored, action))
        return fp_1.set([action.payload.token], action.payload.tokenNetwork, state);
    else
        return state;
}
// handles all channel actions and requests
function channels(state, action) {
    if (state === void 0) { state = state_2.initialState.channels; }
    if (typesafe_actions_1.isActionOf(actions_1.channelOpen, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        if (fp_1.get(path, state))
            return state; // there's already a channel with partner
        var channel = {
            state: state_1.ChannelState.opening,
            own: { deposit: constants_1.Zero },
            partner: { deposit: constants_1.Zero },
        };
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelOpened, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner], channel = {
            state: state_1.ChannelState.open,
            own: { deposit: constants_1.Zero },
            partner: { deposit: constants_1.Zero },
            id: action.payload.id,
            settleTimeout: action.payload.settleTimeout,
            openBlock: action.payload.openBlock,
        };
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelOpenFailed, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        if (fp_1.get(path.concat(['state']), state) !== state_1.ChannelState.opening)
            return state;
        return fp_1.unset(path, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelDeposited, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel || channel.state !== state_1.ChannelState.open || channel.id !== action.payload.id)
            return state;
        if (action.payload.participant === action.meta.partner)
            channel = fp_1.set(['partner', 'deposit'], action.payload.totalDeposit, channel);
        else
            channel = fp_1.set(['own', 'deposit'], action.payload.totalDeposit, channel);
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelClose, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel || channel.state !== state_1.ChannelState.open)
            return state;
        channel = __assign({}, channel, { state: state_1.ChannelState.closing });
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelClosed, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel ||
            !(channel.state === state_1.ChannelState.open || channel.state === state_1.ChannelState.closing) ||
            channel.id !== action.payload.id)
            return state;
        channel = __assign({}, channel, { state: state_1.ChannelState.closed, closeBlock: action.payload.closeBlock });
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelSettleable, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel || channel.state !== state_1.ChannelState.closed)
            return state;
        channel = __assign({}, channel, { state: state_1.ChannelState.settleable });
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelSettle, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel || channel.state !== state_1.ChannelState.settleable)
            return state;
        channel = __assign({}, channel, { state: state_1.ChannelState.settling });
        return fp_1.set(path, channel, state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.channelSettled, action)) {
        var path = [action.meta.tokenNetwork, action.meta.partner];
        var channel = fp_1.get(path, state);
        if (!channel ||
            ![state_1.ChannelState.closed, state_1.ChannelState.settleable, state_1.ChannelState.settling].includes(channel.state))
            return state;
        return fp_1.unset(path, state);
    }
    else
        return state;
}
/**
 * Nested/combined reducer for channels
 * blockNumber, tokens & channels reducers get its own slice of the state, corresponding to the
 * name of the reducer. channels root reducer instead must be handled the complete state instead,
 * so it compose the output with each key/nested/combined state.
 */
exports.channelsReducer = redux_1.partialCombineReducers({ blockNumber: blockNumber, tokens: tokens, channels: channels }, state_2.initialState);
//# sourceMappingURL=reducer.js.map