import { Observable } from 'rxjs';
import { BigNumber } from 'ethers/utils';
import { RaidenEpicDeps } from '../types';
import { RaidenState } from '../store/state';
import { ShutdownReason } from '../constants';
import { Hash } from '../utils/types';
/**
 * Register for new block events and emit newBlock actions for new blocks
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param provider  RaidenEpicDeps members
 * @returns  Observable of newBlock actions
 */
export declare const initNewBlockEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { provider }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadAction<"newBlock", {
    blockNumber: number;
}>>;
/**
 * Monitor registry for new token networks and monitor them
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param registryContract,contractsInfo  RaidenEpicDeps members
 * @returns  Observable of tokenMonitored actions
 */
export declare const initMonitorRegistryEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { registryContract, contractsInfo }: RaidenEpicDeps) => Observable<{
    type: "tokenMonitored";
} & {
    payload: {
        token: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        first: boolean;
    };
}>;
/**
 * Monitor channels previously already on state
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelMonitored actions
 */
export declare const initMonitorChannelsEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelMonitored", {
    id: number;
    fromBlock?: number | undefined;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
/**
 * Monitor provider to ensure account continues to be available and network stays the same
 *
 * @param action$  Observable of raidenInit actions
 * @param state$  Observable of RaidenStates
 * @param address,network,provider  RaidenEpicDeps members
 * @returns  Observable of raidenShutdown actions
 */
export declare const initMonitorProviderEpic: (action$: Observable<import("typesafe-actions").Action<string>>, {}: Observable<RaidenState>, { address, network, provider }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadAction<"raidenShutdown", {
    reason: Error | ShutdownReason;
}>>;
/**
 * Starts monitoring a token network for events
 * When this action goes through (because a former or new token registry event was deteceted),
 * subscribe to events and emit respective actions to the stream. Currently:
 * - ChannelOpened events with us or by us
 *
 * @param action$  Observable of tokenMonitored actions
 * @param state$  Observable of RaidenStates
 * @param matrix$  RaidenEpicDeps members
 * @returns  Observable of channelOpened actions
 */
export declare const tokenMonitoredEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenNetworkContract, contractsInfo }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"channelOpened", {
    id: number;
    settleTimeout: number;
    openBlock: number;
    txHash: Hash;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
/**
 * Monitors a channel for channel Events
 * Can be called either at initialization time (for previously known channels on previously
 * monitored TokenNetwork) or by a new detected ChannelOpenedAction. On the later case,
 * also fetches events since Channel.openBlock.
 * Currently monitored events:
 * - ChannelNewDeposit, fires a channelDeposited action
 * - ChannelClosedEvent, fires a channelClosed action
 * - ChannelSettledEvent, fires a channelSettled action and completes that channel observable
 *
 * @param action$  Observable of channelMonitored actions
 * @param state$  Observable of RaidenStates
 * @param matrix$  RaidenEpicDeps members
 * @returns  Observable of channelDeposited,channelClosed,channelSettled actions
 */
export declare const channelMonitoredEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"channelDeposited", {
    id: number;
    participant: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    totalDeposit: BigNumber;
    txHash: Hash;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}> | import("typesafe-actions").PayloadMetaAction<"channelClosed", {
    id: number;
    participant: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    closeBlock: number;
    txHash: Hash;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}> | import("typesafe-actions").PayloadMetaAction<"channelSettled", {
    id: number;
    settleBlock: number;
    txHash: Hash;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
/**
 * A channelOpen action requested by user
 * Needs to be called on a previously monitored tokenNetwork. Calls TokenNetwork.openChannel
 * with given parameters. If tx goes through successfuly, stop as ChannelOpened success action
 * will instead be detected and fired by tokenMonitoredEpic. If anything detectable goes wrong,
 * fires a ChannnelOpenActionFailed instead
 *
 * @param action$  Observable of channelOpen actions
 * @param state$  Observable of RaidenStates
 * @param getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelOpenFailed actions
 */
export declare const channelOpenEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
    type: "channelOpenFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
}>;
/**
 * When we see a new ChannelOpenedAction event, starts monitoring channel
 *
 * @param action$  Observable of channelOpened actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelMonitored actions
 */
export declare const channelOpenedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelMonitored", {
    id: number;
    fromBlock?: number | undefined;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
/**
 * A ChannelDeposit action requested by user
 * Needs to be called on a previously monitored channel. Calls Token.approve for TokenNetwork
 * and then set respective setTotalDeposit. If all tx go through successfuly, stop as
 * ChannelDeposited success action will instead be detected and reacted by
 * channelMonitoredEpic. If anything detectable goes wrong, fires a ChannelDepositActionFailed
 * instead
 *
 * @param action$  Observable of channelDeposit actions
 * @param state$  Observable of RaidenStates
 * @param address,getTokenContract,getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelDepositFailed actions
 */
export declare const channelDepositEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenContract, getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
    type: "channelDepositFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
}>;
/**
 * A ChannelClose action requested by user
 * Needs to be called on an opened or closing (for retries) channel.
 * If tx goes through successfuly, stop as ChannelClosed success action will instead be
 * detected and reacted by channelMonitoredEpic. If anything detectable goes wrong, fires a
 * ChannelCloseActionFailed instead
 *
 * @param action$  Observable of channelClose actions
 * @param state$  Observable of RaidenStates
 * @param getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelCloseFailed actions
 */
export declare const channelCloseEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
    type: "channelCloseFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
}>;
/**
 * A ChannelSettle action requested by user
 * Needs to be called on an settleable or settling (for retries) channel.
 * If tx goes through successfuly, stop as ChannelSettled success action will instead be
 * detected and reacted by channelMonitoredEpic. If anything detectable goes wrong, fires a
 * ChannelSettleActionFailed instead
 *
 * @param action$  Observable of channelSettle actions
 * @param state$  Observable of RaidenStates
 * @param address,getTokenNetworkContract  RaidenEpicDeps members
 * @returns  Observable of channelSettleFailed actions
 */
export declare const channelSettleEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { address, getTokenNetworkContract }: RaidenEpicDeps) => Observable<{
    type: "channelSettleFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
        partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
}>;
/**
 * Process newBlocks, emits ChannelSettleableAction if any closed channel is now settleable
 *
 * @param action$  Observable of newBlock actions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of channelSettleable actions
 */
export declare const channelSettleableEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"channelSettleable", {
    settleableBlock: number;
}, {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    partner: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
