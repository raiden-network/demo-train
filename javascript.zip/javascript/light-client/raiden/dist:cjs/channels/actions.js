"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
/* A new head in the blockchain is detected by provider */
exports.newBlock = typesafe_actions_1.createStandardAction('newBlock')();
/* A new token network is detected in the TokenNetworkRegistry instance */
exports.tokenMonitored = typesafe_actions_1.createStandardAction('tokenMonitored').map(function (_a) {
    var token = _a.token, tokenNetwork = _a.tokenNetwork, _b = _a.first, first = _b === void 0 ? false : _b;
    return ({
        payload: { token: token, tokenNetwork: tokenNetwork, first: first },
    });
});
/**
 * Channel actions receive ChannelId as 'meta' action property
 * This way, 'meta' can be used equally for request, success and error actions
 */
/* Request a channel to be opened with meta={ tokenNetwork, partner } and payload.settleTimeout */
exports.channelOpen = typesafe_actions_1.createStandardAction('channelOpen')();
/* A channel is detected on-chain. Also works as 'success' for channelOpen action */
exports.channelOpened = typesafe_actions_1.createStandardAction('channelOpened')();
/* A channelOpen request action (with meta: ChannelId) failed with payload=Error */
exports.channelOpenFailed = typesafe_actions_1.createStandardAction('channelOpenFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
/* Channel with meta:ChannelId + payload.id should be monitored */
exports.channelMonitored = typesafe_actions_1.createStandardAction('channelMonitored')();
/* Request a payload.deposit to be made to channel meta:ChannelId */
exports.channelDeposit = typesafe_actions_1.createStandardAction('channelDeposit')();
/* A deposit is detected on-chain. Also works as 'success' for channelDeposit action */
exports.channelDeposited = typesafe_actions_1.createStandardAction('channelDeposited')();
/* A channelDeposit request action (with meta: ChannelId) failed with payload=Error */
exports.channelDepositFailed = typesafe_actions_1.createStandardAction('channelDepositFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
/* Request channel meta:ChannelId to be closed */
exports.channelClose = typesafe_actions_1.createStandardAction('channelClose')();
/* A close channel event is detected on-chain. Also works as 'success' for channelClose action */
exports.channelClosed = typesafe_actions_1.createStandardAction('channelClosed')();
/* A channelClose request action (with meta: ChannelId) failed with payload=Error */
exports.channelCloseFailed = typesafe_actions_1.createStandardAction('channelCloseFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
/* A channel meta:ChannelId becomes settleable, starting from payload.settleableBlock */
exports.channelSettleable = typesafe_actions_1.createStandardAction('channelSettleable')();
/* Request channel meta:ChannelId to be settled */
exports.channelSettle = typesafe_actions_1.createStandardAction('channelSettle')();
/* A settle channel event is detected on-chain. Also works as 'success' for channelSettle action */
exports.channelSettled = typesafe_actions_1.createStandardAction('channelSettled')();
/* A channelSettle request action (with meta: ChannelId) failed with payload=Error */
exports.channelSettleFailed = typesafe_actions_1.createStandardAction('channelSettleFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
//# sourceMappingURL=actions.js.map