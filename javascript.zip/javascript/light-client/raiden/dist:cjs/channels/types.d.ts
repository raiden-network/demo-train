import * as t from 'io-ts';
export declare const Lock: t.TypeC<{
    type: t.LiteralC<"Lock">;
    amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
}>;
export declare type Lock = t.TypeOf<typeof Lock>;
/**
 * Balance Proof constructed from an EnvelopeMessage
 * Either produced by us or received from the partner, the BPs are generated from the messages
 * because BP signature requires the hash of the message, for authentication of data not included
 * nor relevant for the smartcontract/BP itself, but so for the peers (e.g. payment_id)
 */
export declare const SignedBalanceProof: t.TypeC<{
    chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
}>;
export declare type SignedBalanceProof = t.TypeOf<typeof SignedBalanceProof>;
