"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Like redux's combineReducers, but allows passing only a partial reducer mapping
 * redux's combineReducers output state must be exactly the mapping passed as parameter,
 * which doesn't allow to only provide a partial set of reducers and passthrough the other state's
 * keys. This function allows that, also preserving state/object reference when reducers doesn't
 * change state value.
 *
 * @param reducers  A mapping of a subset of state's key to nested reducers functions
 * @param initialState  global initial state, required when initializing first object with partial
 *                      reducers
 * @returns Full reducer for state S and actions A
 */
function partialCombineReducers(reducers, initialState) {
    return function (state, action) {
        var _a;
        if (state === void 0) { state = initialState; }
        for (var key in reducers) {
            var reducer = reducers[key];
            if (!reducer)
                continue; // shouldn't happen, only here for type safety below
            var subState = state[key] || initialState[key];
            var newSubState = reducer(subState, action);
            if (newSubState !== subState) {
                state = __assign({}, state, (_a = {}, _a[key] = newSubState, _a));
            }
        }
        return state;
    };
}
exports.partialCombineReducers = partialCombineReducers;
//# sourceMappingURL=redux.js.map