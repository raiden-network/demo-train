/**
 * Simple Map-based LRU cache
 *
 * @param max Maximum size of cache
 */
export declare class LruCache<K, V> {
    values: Map<K, V>;
    max: number;
    constructor(max: number);
    get(key: K): V | undefined;
    put(key: K, value: V): void;
}
