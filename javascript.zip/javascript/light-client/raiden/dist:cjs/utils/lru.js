"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Simple Map-based LRU cache
 *
 * @param max Maximum size of cache
 */
var LruCache = /** @class */ (function () {
    function LruCache(max) {
        this.values = new Map();
        this.max = max;
    }
    LruCache.prototype.get = function (key) {
        var entry = this.values.get(key);
        if (entry) {
            // peek the entry, re-insert for LRU strategy
            this.values.delete(key);
            this.values.set(key, entry);
        }
        return entry;
    };
    LruCache.prototype.put = function (key, value) {
        if (this.values.size >= this.max) {
            // least-recently used cache eviction strategy
            var keyToDelete = this.values.keys().next().value;
            this.values.delete(keyToDelete);
        }
        this.values.set(key, value);
    };
    return LruCache;
}());
exports.LruCache = LruCache;
//# sourceMappingURL=lru.js.map