"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var networks_1 = require("ethers/utils/networks");
var lodash_1 = require("lodash");
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
/**
 * Like rxjs' fromEvent, but event can be an EventFilter
 *
 * @param target  Object to hook event listener, maybe a Provider or Contract
 * @param event  EventFilter or string representing the event to listen to
 * @param resultSelector  A map of events arguments to output parameters
 *      Default is to pass only first parameter
 * @returns Observable of target.on(event) events
 */
function fromEthersEvent(target, event, resultSelector) {
    return rxjs_1.fromEventPattern(function (handler) { return target.on(event, handler); }, function (handler) { return target.removeListener(event, handler); }, resultSelector);
}
exports.fromEthersEvent = fromEthersEvent;
/**
 * getEventsStream returns a stream of T-type tuples (arrays) from Contract's
 * events from filters. These events are polled since provider's [re]setEventsBlock to newest
 * polled block. If both 'fromBlock$' and 'lastSeenBlock$' are specified, also fetch past events
 * since fromBlock up to lastSeenBlock$ === provider.resetEventsBlock - 1
 * T must be a tuple-like type receiving all filters arguments plus the respective Event in the end
 *
 * @param contract  Contract source instance for filters, connected to a provider
 * @param filters  array of OR filters from tokenNetwork
 * @param fromBlock$  Observable of a past blockNumber since when to fetch past events
 * @param lastSeenBlock$  Observable of latest seen block, to be used as toBlock of pastEvents.
 *      lastSeenBlock + 1 is supposed to be first one fetched by contract.on newEvents$
 *      Both fromBlock$ and lastSeenBlock$ need to be set to fetch pastEvents$
 * @returns Observable of contract's events
 */
function getEventsStream(contract, filters, fromBlock$, lastSeenBlock$) {
    var _this = this;
    var provider = contract.provider;
    // filters for channels opened by and with us
    var newEvents$ = rxjs_1.from(filters).pipe(operators_1.mergeMap(function (filter) { return fromEthersEvent(contract, filter, function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return args;
    }); }));
    var pastEvents$ = rxjs_1.EMPTY;
    if (fromBlock$ && lastSeenBlock$) {
        pastEvents$ = fromBlock$.pipe(operators_1.withLatestFrom(rxjs_1.defer(function () { return (provider.blockNumber ? rxjs_1.of(provider.blockNumber) : lastSeenBlock$); })), operators_1.first(), operators_1.switchMap(function (_a) {
            var fromBlock = _a[0], toBlock = _a[1];
            return __awaiter(_this, void 0, void 0, function () {
                var logs;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, Promise.all(filters.map(function (filter) { return provider.getLogs(__assign({}, filter, { fromBlock: fromBlock, toBlock: toBlock })); }))];
                        case 1:
                            logs = _b.sent();
                            // flatten array of each getLogs query response and sort them
                            // emit log array elements as separate logs into stream
                            return [2 /*return*/, rxjs_1.from(lodash_1.sortBy(lodash_1.flatten(logs), ['blockNumber']))];
                    }
                });
            });
        }), operators_1.mergeAll(), // async return above will be a Promise of an Observable, so unpack inner$
        operators_1.map(function (log) {
            // parse log into [...args, event: Event] array,
            // the same that contract.on events/callbacks
            var parsed = contract.interface.parseLog(log);
            if (!parsed)
                return;
            var args = Array.prototype.slice.call(parsed.values);
            // not all parameters quite needed right now, but let's comply with the interface
            var event = __assign({}, log, parsed, { args: args, removeListener: function () { }, getBlock: function () { return provider.getBlock(log.blockHash); }, getTransaction: function () { return provider.getTransaction(log.transactionHash); }, getTransactionReceipt: function () { return provider.getTransactionReceipt(log.transactionHash); }, decode: undefined });
            return args.concat([event]);
        }), operators_1.filter(function (event) { return !!event; }));
    }
    return rxjs_1.merge(pastEvents$, newEvents$);
}
exports.getEventsStream = getEventsStream;
/**
 * Like Provider.getNetwork, but fetches every time instead of using cached property
 *
 * @param provider Provider to fetch data from
 * @returns Promise of Network info
 */
function getNetwork(provider) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = networks_1.getNetwork;
                    _b = parseInt;
                    return [4 /*yield*/, provider.send('net_version', [])];
                case 1: return [2 /*return*/, _a.apply(void 0, [_b.apply(void 0, [_c.sent()])])];
            }
        });
    });
}
exports.getNetwork = getNetwork;
//# sourceMappingURL=ethers.js.map