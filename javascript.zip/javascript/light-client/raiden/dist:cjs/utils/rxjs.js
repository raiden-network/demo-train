"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var operators_1 = require("rxjs/operators");
/**
 * Util to split a combineLatest tuple Observable to a tuple of Observables of each member
 * Util when combining observables to e.g. multicast, and then willing to handle them separately
 * inside the multicast selector.
 *
 * @param tuple$  An Observable of tuples of up to 4 values
 * @returns  2-4-tuple of Observables reflecting each value of the tuple
 */
function splitCombined(tuple$) {
    return [
        tuple$.pipe(operators_1.map(function (t) { return t[0]; }), operators_1.distinctUntilChanged()),
        tuple$.pipe(operators_1.map(function (t) { return t[1]; }), operators_1.distinctUntilChanged()),
        tuple$.pipe(operators_1.map(function (t) { return t[2]; }), operators_1.distinctUntilChanged()),
        tuple$.pipe(operators_1.map(function (t) { return t[3]; }), operators_1.distinctUntilChanged()),
    ];
}
exports.splitCombined = splitCombined;
//# sourceMappingURL=rxjs.js.map