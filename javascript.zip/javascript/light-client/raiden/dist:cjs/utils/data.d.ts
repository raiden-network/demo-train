import { BigNumber } from 'ethers/utils';
import { Arrayish } from 'ethers/utils/bytes';
import { HexString } from './types';
/**
 * Encode data to hex string of exactly length size (in bytes)
 * Throw if data can't be made to fit in length.
 *
 * @param data May be of multiple types:
 *      - number|BigNumber: Encoded in the big-endian byte-order and left-zero-padded to length
 *      - string: Must be hex-encoded string of length bytes
 *      - number[] Must be of exactly of length size (left/right-pad it before if needed)
 * @param length The expected length of the hex string, in bytes
 * @returns HexString byte-array of length
 */
export declare function encode<S extends number = number>(data: number | string | Arrayish | BigNumber, length: S): HexString<S>;
/**
 * Opportunistic JSON.parse regarding numbers
 * If possible to decode a JSON number as JS number (i.e. value < 2^53) and return 'number',
 * otherwise returns LosslessNumber object, which can be decoded as BigNumber by BigNumberC
 * Throws if handled invalid JSON
 *
 * @param text JSON string to parse
 * @returns Decoded object
 */
export declare function losslessParse(text: string): any;
export { stringify as losslessStringify } from 'lossless-json';
