"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/no-explicit-any */
var t = __importStar(require("io-ts"));
var utils_1 = require("ethers/utils");
var constants_1 = require("ethers/constants");
var lossless_json_1 = require("lossless-json");
var lodash_1 = require("lodash");
var isStringifiable = function (u) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return u !== null && u !== undefined && typeof u['toString'] === 'function';
};
var isBigNumber = function (u) { return u && u['_ethersType'] === 'BigNumber'; };
/**
 * Codec of ethers.utils.BigNumber objects
 * Input can be anything bigNumberify-able: number, string, LosslessNumber or BigNumber
 * Output is LosslessNumber, so we can JSON-serialize with 'number' types bigger than JS VM limits
 * of ±2^53, as Raiden full-client/python stdlib json encode/decode longs as json number.
 */
exports.BigNumberC = new t.Type('BigNumber', isBigNumber, function (u, c) {
    if (isBigNumber(u))
        return t.success(u);
    try {
        if (isStringifiable(u))
            return t.success(utils_1.bigNumberify(u.toString()));
    }
    catch (err) {
        return t.failure(u, c, err.message);
    }
    return t.failure(u, c);
}, function (a) { return new lossless_json_1.LosslessNumber(a.toString()); });
/**
 * Creates a NEW codec for a specific [non-const] enum object
 */
var EnumType = /** @class */ (function (_super) {
    __extends(EnumType, _super);
    function EnumType(e, name) {
        var _this = _super.call(this, name || 'enum', function (u) { return Object.values(_this.enumObject).some(function (v) { return v === u; }); }, function (u, c) { return (_this.is(u) ? t.success(u) : t.failure(u, c)); }, t.identity) || this;
        _this._tag = 'EnumType';
        _this.enumObject = e;
        return _this;
    }
    return EnumType;
}(t.Type));
exports.EnumType = EnumType;
/**
 * Helper function to create codecs to validate an arbitrary or variable-sized hex bytestring
 * A branded codec to indicate validated hex-strings
 *
 * @param size  Required number of bytes. Pass undefined or zero to have a variable-sized type
 * @returns branded  codec for hex-encoded bytestrings
 */
exports.HexString = lodash_1.memoize(function (size) {
    return t.brand(t.string, function (n) {
        return typeof n === 'string' && (size ? utils_1.hexDataLength(n) === size : utils_1.isHexString(n));
    }, 'HexString');
});
/**
 * Helper function to create codecs to validate an arbitrary or variable-sized BigNumbers
 * A branded codec/type to indicate size-validated BigNumbers
 *
 * @param size  Required number of bytes. Pass undefined or zero to have a variable-sized type
 * @returns branded  codec for hex-encoded bytestrings
 */
exports.UInt = lodash_1.memoize(function (size) {
    var max = size ? constants_1.Two.pow(size * 8) : undefined;
    return t.brand(exports.BigNumberC, function (n) {
        return exports.BigNumberC.is(n) && n.gte(0) && (max === undefined || n.lt(max));
    }, 'UInt');
});
// specific types
// strig brand: ECDSA signature as an hex-string
exports.Signature = exports.HexString(65);
// string brand: 256-bit hash, usually keccak256 or sha256
exports.Hash = exports.HexString(32);
// string brand: a secret bytearray, non-sized
exports.Secret = exports.HexString();
// string brand: ECDSA private key, 32 bytes
exports.PrivateKey = exports.HexString(32);
// string brand: checksummed address, 20 bytes
exports.Address = t.brand(exports.HexString(20), function (u) {
    try {
        return typeof u === 'string' && utils_1.getAddress(u) === u;
    }
    catch (e) { }
    return false;
}, // type guard for branded values
'Address');
//# sourceMappingURL=types.js.map