import { MatrixClient } from 'matrix-js-sdk';
/**
 * From a yaml list string, return as Array
 * E.g. yamlListToArray(`
 * # comment
 *   - test1
 *   - test2
 *   - test3
 * `) === ['test1', 'test2', 'test3']
 *
 * @param yml  String containing only YAML list
 * @returns  List of strings inside yml-encoded text
 */
export declare function yamlListToArray(yml: string): string[];
/**
 * Given a server name (with or without schema and port), return HTTP GET round trip time
 *
 * @param server Server name with or without schema
 * @returns Promise to a { server, rtt } object, where `rtt` may be NaN
 */
export declare function matrixRTT(server: string): Promise<{
    server: string;
    rtt: number;
}>;
/**
 * Return server name without schema or path
 *
 * @param server any URL
 * @returns server URL with domain and port (if present), without schema, paths or query params
 */
export declare function getServerName(server: string): string | null;
/**
 * MatrixClient doesn't expose this API, but it does exist, so we create it here
 *
 * @param matrix an already setup and started MatrixClient
 * @param userId to fetch status/presence from
 * @returns Promise to object containing status data
 */
export declare function getUserPresence(matrix: MatrixClient, userId: string): Promise<{
    presence: string;
    last_active_ago?: number;
    status_msg?: string;
    currently_active?: boolean;
}>;
