"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var cross_fetch_1 = __importDefault(require("cross-fetch"));
var utils_1 = require("matrix-js-sdk/lib/utils");
/**
 * From a yaml list string, return as Array
 * E.g. yamlListToArray(`
 * # comment
 *   - test1
 *   - test2
 *   - test3
 * `) === ['test1', 'test2', 'test3']
 *
 * @param yml  String containing only YAML list
 * @returns  List of strings inside yml-encoded text
 */
function yamlListToArray(yml) {
    // match all strings starting with optional spaces followed by a dash + space
    // capturing only the content of the list item, trimming spaces
    var reg = /^\s*-\s*(.+?)\s*$/gm;
    var results = [];
    var match;
    while ((match = reg.exec(yml))) {
        results.push(match[1]);
    }
    return results;
}
exports.yamlListToArray = yamlListToArray;
/**
 * Given a server name (with or without schema and port), return HTTP GET round trip time
 *
 * @param server Server name with or without schema
 * @returns Promise to a { server, rtt } object, where `rtt` may be NaN
 */
function matrixRTT(server) {
    return __awaiter(this, void 0, void 0, function () {
        var url, start, resp, e_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    url = server;
                    if (!url.includes('://')) {
                        url = "https://" + url;
                    }
                    url += "/_matrix/client/versions";
                    start = Date.now();
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, cross_fetch_1.default(url)];
                case 2:
                    resp = _a.sent();
                    if (resp.status < 200 || resp.status >= 300)
                        throw NaN;
                    return [3 /*break*/, 4];
                case 3:
                    e_1 = _a.sent();
                    start = NaN; // return will also be NaN
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/, { server: server, rtt: Date.now() - start }];
            }
        });
    });
}
exports.matrixRTT = matrixRTT;
/**
 * Return server name without schema or path
 *
 * @param server any URL
 * @returns server URL with domain and port (if present), without schema, paths or query params
 */
function getServerName(server) {
    var match = /^(?:\w*:?\/\/)?([^/#?&]+)/.exec(server);
    return match && match[1];
}
exports.getServerName = getServerName;
/**
 * MatrixClient doesn't expose this API, but it does exist, so we create it here
 *
 * @param matrix an already setup and started MatrixClient
 * @param userId to fetch status/presence from
 * @returns Promise to object containing status data
 */
function getUserPresence(matrix, userId) {
    var path = utils_1.encodeUri('/presence/$userId/status', { $userId: userId });
    return matrix._http.authedRequest(undefined, 'GET', path);
}
exports.getUserPresence = getUserPresence;
//# sourceMappingURL=matrix.js.map