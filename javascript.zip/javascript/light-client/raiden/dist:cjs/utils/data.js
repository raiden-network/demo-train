"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/no-explicit-any */
var constants_1 = require("ethers/constants");
var utils_1 = require("ethers/utils");
var bytes_1 = require("ethers/utils/bytes");
var lossless_json_1 = require("lossless-json");
var types_1 = require("./types");
/**
 * Encode data to hex string of exactly length size (in bytes)
 * Throw if data can't be made to fit in length.
 *
 * @param data May be of multiple types:
 *      - number|BigNumber: Encoded in the big-endian byte-order and left-zero-padded to length
 *      - string: Must be hex-encoded string of length bytes
 *      - number[] Must be of exactly of length size (left/right-pad it before if needed)
 * @param length The expected length of the hex string, in bytes
 * @returns HexString byte-array of length
 */
function encode(data, length) {
    var hex;
    if (typeof data === 'number')
        data = utils_1.bigNumberify(data);
    if (types_1.BigNumberC.is(data)) {
        if (data.lt(0))
            throw new Error('Number is negative');
        if (data.gte(constants_1.Two.pow(length * 8)))
            throw new Error('Number too large');
        hex = bytes_1.hexZeroPad(bytes_1.hexlify(data), length);
    }
    else if (typeof data === 'string' || bytes_1.isArrayish(data)) {
        var str = bytes_1.hexlify(data);
        if (bytes_1.hexDataLength(str) !== length)
            throw new Error('Uint8Array or hex string must be of exact length');
        hex = str;
    }
    else {
        throw new Error('data is not a HexString or Uint8Array');
    }
    return hex;
}
exports.encode = encode;
var isLosslessNumber = function (u) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return u && u['isLosslessNumber'] === true;
};
/**
 * Opportunistic JSON.parse regarding numbers
 * If possible to decode a JSON number as JS number (i.e. value < 2^53) and return 'number',
 * otherwise returns LosslessNumber object, which can be decoded as BigNumber by BigNumberC
 * Throws if handled invalid JSON
 *
 * @param text JSON string to parse
 * @returns Decoded object
 */
function losslessParse(text) {
    return lossless_json_1.parse(text, function (_a, value) {
        if (isLosslessNumber(value)) {
            try {
                return value.valueOf(); // return number, if possible, or throw if > 2^53
            }
            catch (e) { } // else, pass to return LosslessNumber, which can be decoded by BigNumberC
        }
        return value;
    });
}
exports.losslessParse = losslessParse;
var lossless_json_2 = require("lossless-json");
exports.losslessStringify = lossless_json_2.stringify;
//# sourceMappingURL=data.js.map