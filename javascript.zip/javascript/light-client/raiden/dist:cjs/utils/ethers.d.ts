import { Contract, EventFilter } from 'ethers';
import { Provider, JsonRpcProvider } from 'ethers/providers';
import { Network } from 'ethers/utils';
import { Observable } from 'rxjs';
/**
 * Like rxjs' fromEvent, but event can be an EventFilter
 *
 * @param target  Object to hook event listener, maybe a Provider or Contract
 * @param event  EventFilter or string representing the event to listen to
 * @param resultSelector  A map of events arguments to output parameters
 *      Default is to pass only first parameter
 * @returns Observable of target.on(event) events
 */
export declare function fromEthersEvent<T>(target: Provider | Contract, event: EventFilter | string, resultSelector?: (...args: any[]) => T): Observable<T>;
/**
 * getEventsStream returns a stream of T-type tuples (arrays) from Contract's
 * events from filters. These events are polled since provider's [re]setEventsBlock to newest
 * polled block. If both 'fromBlock$' and 'lastSeenBlock$' are specified, also fetch past events
 * since fromBlock up to lastSeenBlock$ === provider.resetEventsBlock - 1
 * T must be a tuple-like type receiving all filters arguments plus the respective Event in the end
 *
 * @param contract  Contract source instance for filters, connected to a provider
 * @param filters  array of OR filters from tokenNetwork
 * @param fromBlock$  Observable of a past blockNumber since when to fetch past events
 * @param lastSeenBlock$  Observable of latest seen block, to be used as toBlock of pastEvents.
 *      lastSeenBlock + 1 is supposed to be first one fetched by contract.on newEvents$
 *      Both fromBlock$ and lastSeenBlock$ need to be set to fetch pastEvents$
 * @returns Observable of contract's events
 */
export declare function getEventsStream<T extends any[]>(contract: Contract, filters: EventFilter[], fromBlock$?: Observable<number>, lastSeenBlock$?: Observable<number>): Observable<T>;
/**
 * Like Provider.getNetwork, but fetches every time instead of using cached property
 *
 * @param provider Provider to fetch data from
 * @returns Promise of Network info
 */
export declare function getNetwork(provider: JsonRpcProvider): Promise<Network>;
