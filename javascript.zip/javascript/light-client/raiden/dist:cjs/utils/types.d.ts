/// <reference types="lodash" />
import * as t from 'io-ts';
import { BigNumber } from 'ethers/utils';
import { LosslessNumber } from 'lossless-json';
export interface Storage {
    getItem(key: string): string | null | Promise<string | null>;
    setItem(key: string, value: string): void | Promise<void>;
    removeItem(key: string): void | Promise<void>;
}
/**
 * Codec of ethers.utils.BigNumber objects
 * Input can be anything bigNumberify-able: number, string, LosslessNumber or BigNumber
 * Output is LosslessNumber, so we can JSON-serialize with 'number' types bigger than JS VM limits
 * of ±2^53, as Raiden full-client/python stdlib json encode/decode longs as json number.
 */
export declare const BigNumberC: t.Type<BigNumber, LosslessNumber, unknown>;
/**
 * Creates a NEW codec for a specific [non-const] enum object
 */
export declare class EnumType<A> extends t.Type<A> {
    readonly _tag: 'EnumType';
    enumObject: object;
    constructor(e: object, name?: string);
}
export interface SizedB<S extends number> {
    readonly size: S;
}
export interface HexStringB<S extends number> extends SizedB<S> {
    readonly HexString: unique symbol;
}
/**
 * Helper function to create codecs to validate an arbitrary or variable-sized hex bytestring
 * A branded codec to indicate validated hex-strings
 *
 * @param size  Required number of bytes. Pass undefined or zero to have a variable-sized type
 * @returns branded  codec for hex-encoded bytestrings
 */
export declare const HexString: (<S extends number = number>(size?: S | undefined) => t.BrandC<t.StringC, HexStringB<S>>) & import("lodash").MemoizedFunction;
export declare type HexString<S extends number = number> = string & t.Brand<HexStringB<S>>;
export interface UIntB<S extends number> extends SizedB<S> {
    readonly UInt: unique symbol;
}
/**
 * Helper function to create codecs to validate an arbitrary or variable-sized BigNumbers
 * A branded codec/type to indicate size-validated BigNumbers
 *
 * @param size  Required number of bytes. Pass undefined or zero to have a variable-sized type
 * @returns branded  codec for hex-encoded bytestrings
 */
export declare const UInt: (<S extends number = number>(size?: S | undefined) => t.BrandC<t.Type<BigNumber, LosslessNumber, unknown>, UIntB<S>>) & import("lodash").MemoizedFunction;
export declare type UInt<S extends number = number> = BigNumber & t.Brand<UIntB<S>>;
export declare const Signature: t.BrandC<t.StringC, HexStringB<65>>;
export declare type Signature = string & t.Brand<HexStringB<65>>;
export declare const Hash: t.BrandC<t.StringC, HexStringB<32>>;
export declare type Hash = string & t.Brand<HexStringB<32>>;
export declare const Secret: t.BrandC<t.StringC, HexStringB<number>>;
export declare type Secret = string & t.Brand<HexStringB<number>>;
export declare const PrivateKey: t.BrandC<t.StringC, HexStringB<32>>;
export declare type PrivateKey = string & t.Brand<HexStringB<32>>;
export interface AddressB {
    readonly Address: unique symbol;
}
export declare const Address: t.BrandC<t.BrandC<t.StringC, HexStringB<20>>, HexStringB<20> & AddressB>;
export declare type Address = string & t.Brand<HexStringB<20>> & t.Brand<AddressB>;
