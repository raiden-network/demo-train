"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
exports.raidenInit = typesafe_actions_1.createStandardAction('raidenInit')();
exports.raidenShutdown = typesafe_actions_1.createStandardAction('raidenShutdown')();
//# sourceMappingURL=actions.js.map