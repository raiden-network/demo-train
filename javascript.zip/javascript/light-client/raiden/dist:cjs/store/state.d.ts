import * as t from 'io-ts';
export declare const RaidenState: t.TypeC<{
    address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    blockNumber: t.NumberC;
    channels: t.RecordC<t.StringC, t.RecordC<t.StringC, t.IntersectionC<[t.TypeC<{
        own: t.IntersectionC<[t.TypeC<{
            deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.PartialC<{
            locks: t.ArrayC<t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>>;
            balanceProof: t.TypeC<{
                chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
                sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            }>;
            history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.LOCKED_TRANSFER>;
            }>, t.IntersectionC<[t.TypeC<{
                payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                lock: t.TypeC<{
                    type: t.LiteralC<"Lock">;
                    amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                    expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                    secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                }>;
                target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.UNLOCK>;
                payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.LOCK_EXPIRED>;
                recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>]>>;
        }>]>;
        partner: t.IntersectionC<[t.TypeC<{
            deposit: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.PartialC<{
            locks: t.ArrayC<t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>>;
            balanceProof: t.TypeC<{
                chainId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                tokenNetworkAddress: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channelId: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferredAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                lockedAmount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                messageHash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
                sender: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            }>;
            history: t.RecordC<t.StringC, t.UnionC<[t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.LOCKED_TRANSFER>;
            }>, t.IntersectionC<[t.TypeC<{
                payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                lock: t.TypeC<{
                    type: t.LiteralC<"Lock">;
                    amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                    expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                    secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
                }>;
                target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.UNLOCK>;
                payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>, t.IntersectionC<[t.IntersectionC<[t.TypeC<{
                type: t.LiteralC<import("../messages").MessageType.LOCK_EXPIRED>;
                recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
                channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
                transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>, t.IntersectionC<[t.TypeC<{
                message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            }>, t.TypeC<{
                type: import("../utils/types").EnumType<import("../messages").MessageType>;
            }>]>]>]>, t.TypeC<{
                signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
            }>]>]>>;
        }>]>;
    }>, t.UnionC<[t.TypeC<{
        state: t.LiteralC<import("../channels").ChannelState.opening>;
    }>, t.TypeC<{
        state: t.UnionC<[t.LiteralC<import("../channels").ChannelState.open>, t.LiteralC<import("../channels").ChannelState.closing>]>;
        id: t.NumberC;
        settleTimeout: t.NumberC;
        openBlock: t.NumberC;
    }>, t.TypeC<{
        state: t.UnionC<[t.LiteralC<import("../channels").ChannelState.closed>, t.LiteralC<import("../channels").ChannelState.settleable>, t.LiteralC<import("../channels").ChannelState.settling>]>;
        id: t.NumberC;
        settleTimeout: t.NumberC;
        openBlock: t.NumberC;
        closeBlock: t.NumberC;
    }>]>]>>>;
    tokens: t.RecordC<t.StringC, t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>>;
    transport: t.PartialC<{
        matrix: t.IntersectionC<[t.TypeC<{
            server: t.StringC;
        }>, t.PartialC<{
            setup: t.TypeC<{
                userId: t.StringC;
                accessToken: t.StringC;
                deviceId: t.StringC;
                displayName: t.StringC;
            }>;
            rooms: t.RecordC<t.StringC, t.ArrayC<t.StringC>>;
        }>]>;
    }>;
    secrets: t.RecordC<t.StringC, t.IntersectionC<[t.TypeC<{
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.PartialC<{
        registerBlock: t.NumberC;
    }>]>>;
    sent: t.RecordC<t.StringC, t.IntersectionC<[t.TypeC<{
        transfer: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages").MessageType.LOCKED_TRANSFER>;
        }>, t.IntersectionC<[t.TypeC<{
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            lock: t.TypeC<{
                type: t.LiteralC<"Lock">;
                amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
                secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
            }>;
            target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: import("../utils/types").EnumType<import("../messages").MessageType>;
        }>]>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>;
    }>, t.PartialC<{
        transferProcessed: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages").MessageType.PROCESSED>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: import("../utils/types").EnumType<import("../messages").MessageType>;
        }>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>;
        secretReveal: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages").MessageType.SECRET_REVEAL>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: import("../utils/types").EnumType<import("../messages").MessageType>;
        }>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>;
        unlock: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages").MessageType.UNLOCK>;
            payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: import("../utils/types").EnumType<import("../messages").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>;
        lockExpired: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
            type: t.LiteralC<import("../messages").MessageType.LOCK_EXPIRED>;
            recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
            channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
            transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>, t.IntersectionC<[t.TypeC<{
            message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        }>, t.TypeC<{
            type: import("../utils/types").EnumType<import("../messages").MessageType>;
        }>]>]>]>, t.TypeC<{
            signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
        }>]>;
    }>]>>;
}>;
export interface RaidenState extends t.TypeOf<typeof RaidenState> {
}
/**
 * Encode RaidenState to a JSON string
 * For Raiden client compliance, this JSON encodes BigNumbers as 'number' (using lossless-json lib)
 * which is valid json though not very common as common JS implementations lose precision when
 * decoding through JSON.parse. This is solved in SDK by both encoding and decoding BigNumbers
 * using lossless-json, without going through the intermediary JS-number form.
 *
 * @param state RaidenState object
 * @returns JSON encoded string
 */
export declare function encodeRaidenState(state: RaidenState): string;
/**
 * Try to decode any data as a RaidenState.
 * If handled a string, will parse it with lossless-json, to preserve BigNumbers encoded as JSON
 * 'number'.
 *
 * @param data string | any which may be decoded as RaidenState
 * @returns RaidenState parsed and validated
 */
export declare function decodeRaidenState(data: unknown): RaidenState;
export declare const initialState: Readonly<RaidenState>;
