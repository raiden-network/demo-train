"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
/**
 * This epic simply pipes all states to stateOutput$ subject injected as dependency
 * As the observable output is passed directly to a subject, the subject will mirror obervable's
 * behavior, including automatically completing or erroring the subscription according to the
 * observable.
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param stateOutput$  Subject of RaidenStates
 * @returns  Empty observable
 */
exports.stateOutputEpic = function (_a, state$, _b) {
    var stateOutput$ = _b.stateOutput$;
    return (state$.subscribe(stateOutput$), rxjs_1.EMPTY);
};
/**
 * This epic simply pipes all actions to actionOutput$ subject injected as dependency
 * The same as state, but with actions
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param actionOutput$  Subject of RaidenStates
 * @returns  Empty observable
 */
exports.actionOutputEpic = function (action$, _a, _b) {
    var actionOutput$ = _b.actionOutput$;
    return (action$.subscribe(actionOutput$), rxjs_1.EMPTY);
};
//# sourceMappingURL=epics.js.map