"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var t = __importStar(require("io-ts"));
var ThrowReporter_1 = require("io-ts/lib/ThrowReporter");
var constants_1 = require("ethers/constants");
var data_1 = require("../utils/data");
var types_1 = require("../utils/types");
var channels_1 = require("../channels");
var state_1 = require("../transport/state");
var state_2 = require("../transfers/state");
// types
exports.RaidenState = t.type({
    address: types_1.Address,
    blockNumber: t.number,
    channels: channels_1.Channels,
    tokens: t.record(t.string /* token: Address */, types_1.Address),
    transport: t.partial({
        matrix: t.intersection([
            t.type({
                server: t.string,
            }),
            t.partial({
                setup: state_1.RaidenMatrixSetup,
                rooms: t.record(t.string /* partner: Address */, t.array(t.string)),
            }),
        ]),
    }),
    secrets: t.record(t.string /* secrethash: Hash */, t.intersection([t.type({ secret: types_1.Secret }), t.partial({ registerBlock: t.number })])),
    sent: state_2.SentTransfers,
});
// helpers, utils & constants
/**
 * Encode RaidenState to a JSON string
 * For Raiden client compliance, this JSON encodes BigNumbers as 'number' (using lossless-json lib)
 * which is valid json though not very common as common JS implementations lose precision when
 * decoding through JSON.parse. This is solved in SDK by both encoding and decoding BigNumbers
 * using lossless-json, without going through the intermediary JS-number form.
 *
 * @param state RaidenState object
 * @returns JSON encoded string
 */
function encodeRaidenState(state) {
    return data_1.losslessStringify(exports.RaidenState.encode(state), undefined, 2);
}
exports.encodeRaidenState = encodeRaidenState;
/**
 * Try to decode any data as a RaidenState.
 * If handled a string, will parse it with lossless-json, to preserve BigNumbers encoded as JSON
 * 'number'.
 *
 * @param data string | any which may be decoded as RaidenState
 * @returns RaidenState parsed and validated
 */
function decodeRaidenState(data) {
    if (typeof data === 'string')
        data = data_1.losslessParse(data);
    var validationResult = exports.RaidenState.decode(data);
    ThrowReporter_1.ThrowReporter.report(validationResult); // throws if decode failed
    return validationResult.value;
}
exports.decodeRaidenState = decodeRaidenState;
exports.initialState = {
    address: constants_1.AddressZero,
    blockNumber: 0,
    channels: {},
    tokens: {},
    transport: {},
    secrets: {},
    sent: {},
};
//# sourceMappingURL=state.js.map