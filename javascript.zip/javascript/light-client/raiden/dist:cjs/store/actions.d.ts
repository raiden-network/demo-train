import { ShutdownReason } from '../constants';
export declare const raidenInit: import("typesafe-actions").EmptyAC<"raidenInit">;
export declare const raidenShutdown: import("typesafe-actions").PayloadAC<"raidenShutdown", {
    reason: Error | ShutdownReason;
}>;
