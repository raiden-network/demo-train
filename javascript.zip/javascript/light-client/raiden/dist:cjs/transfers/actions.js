"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
exports.transfer = typesafe_actions_1.createStandardAction('transfer')();
exports.transferSigned = typesafe_actions_1.createStandardAction('transferSigned')();
exports.transferProcessed = typesafe_actions_1.createStandardAction('transferProcessed')();
exports.transferSecret = typesafe_actions_1.createStandardAction('transferSecret')();
exports.transferSecretRequest = typesafe_actions_1.createStandardAction('transferSecretRequest')();
exports.transferUnlock = typesafe_actions_1.createStandardAction('transferUnlock')();
exports.transferUnlocked = typesafe_actions_1.createStandardAction('transferUnlocked')();
exports.transferUnlockProcessed = typesafe_actions_1.createStandardAction('transferUnlockProcessed')();
exports.transferred = typesafe_actions_1.createStandardAction('transferred')();
exports.transferFailed = typesafe_actions_1.createStandardAction('transferFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
//# sourceMappingURL=actions.js.map