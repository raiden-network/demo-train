"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/camelcase */
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var typesafe_actions_1 = require("typesafe-actions");
var utils_1 = require("ethers/utils");
var constants_1 = require("ethers/constants");
var lodash_1 = require("lodash");
var constants_2 = require("../constants");
var rxjs_2 = require("../utils/rxjs");
var lru_1 = require("../utils/lru");
var utils_2 = require("../transport/utils");
var actions_1 = require("../messages/actions");
var types_1 = require("../messages/types");
var utils_3 = require("../messages/utils");
var state_1 = require("../channels/state");
var actions_2 = require("./actions");
var utils_4 = require("./utils");
/**
 * Create an observable to compose and sign a LockedTransfer message/transferSigned action
 * As it's an async observable which depends on state and may return an action which changes it,
 * the returned observable must be subscribed in a serialized context that ensures non-concurrent
 * write access to the channel's balance proof (e.g. concatMap)
 *
 * @param presences$  Observable of address to last matrixPresenceUpdate mapping
 * @param state$  Observable of current state
 * @param action  transfer request action to be sent
 * @param network,address,signer  RaidenEpicDeps members
 * @returns  Observable of output actions (transferSigned, transferSecret & messageSend)
 */
function makeAndSignTransfer(presences$, state$, action, _a) {
    var network = _a.network, address = _a.address, signer = _a.signer;
    return presences$.pipe(operators_1.withLatestFrom(state$), operators_1.first(), operators_1.mergeMap(function (_a) {
        var presences = _a[0], state = _a[1];
        if (!(action.payload.target in presences))
            throw new Error('target not monitored');
        if (!presences[action.payload.target].payload.available)
            throw new Error('target not available/online');
        var secret = action.payload.secret;
        if (secret && utils_1.keccak256(secret) !== action.meta.secrethash) {
            throw new Error('secrethash does not match provided secret');
        }
        var signed$;
        if (action.meta.secrethash in state.sent) {
            // if already saw a transfer with secrethash, use cached instead of signing a new one
            signed$ = rxjs_1.of(state.sent[action.meta.secrethash].transfer);
        }
        else {
            var recipient = undefined;
            for (var _i = 0, _b = Object.entries(state.channels[action.payload.tokenNetwork]); _i < _b.length; _i++) {
                var _c = _b[_i], partner = _c[0], channel_1 = _c[1];
                // capacity is own deposit - (own trasferred + locked) + (partner transferred)
                var capacity = channel_1.own.deposit
                    .sub(channel_1.own.balanceProof
                    ? channel_1.own.balanceProof.transferredAmount.add(channel_1.own.balanceProof.lockedAmount)
                    : constants_1.Zero)
                    .add(
                // only relevant once we can receive from partner
                channel_1.partner.balanceProof ? channel_1.partner.balanceProof.transferredAmount : constants_1.Zero);
                if (channel_1.state !== state_1.ChannelState.open) {
                    console.warn("transfer: channel with \"" + partner + "\" in state \"" + channel_1.state + "\" instead of \"" + state_1.ChannelState.open + "\"");
                }
                else if (capacity.lt(action.payload.amount)) {
                    console.warn("transfer: channel with \"" + partner + "\" without enough capacity (" + capacity.toString() + ")");
                }
                else if (!(partner in presences) || !presences[partner].payload.available) {
                    console.warn("transfer: partner \"" + partner + "\" not available in transport");
                }
                else {
                    recipient = partner;
                    break;
                }
            }
            if (!recipient)
                throw new Error('Could not find an online partner for tokenNetwork with enough capacity');
            var channel = state.channels[action.payload.tokenNetwork][recipient];
            // check below never fail, because of for loop filter, just for type narrowing
            if (channel.state !== state_1.ChannelState.open)
                throw new Error('not open');
            var paymentId = action.payload.paymentId;
            if (!paymentId)
                paymentId = utils_4.makePaymentId();
            var lock = {
                type: 'Lock',
                amount: action.payload.amount,
                expiration: utils_1.bigNumberify(state.blockNumber + constants_2.REVEAL_TIMEOUT * 2),
                secrethash: action.meta.secrethash,
            }, locks = (channel.own.locks || []).concat([lock]), locksroot = utils_4.getLocksroot(locks), fee = action.payload.fee || constants_1.Zero, msgId = utils_4.makeMessageId(), token = lodash_1.findKey(state.tokens, function (tn) { return tn === action.payload.tokenNetwork; });
            var message = {
                type: types_1.MessageType.LOCKED_TRANSFER,
                message_identifier: msgId,
                chain_id: utils_1.bigNumberify(network.chainId),
                token_network_address: action.payload.tokenNetwork,
                channel_identifier: utils_1.bigNumberify(channel.id),
                nonce: (channel.own.balanceProof ? channel.own.balanceProof.nonce : constants_1.Zero).add(1),
                transferred_amount: (channel.own.balanceProof
                    ? channel.own.balanceProof.transferredAmount
                    : constants_1.Zero),
                locked_amount: (channel.own.balanceProof
                    ? channel.own.balanceProof.lockedAmount
                    : constants_1.Zero).add(action.payload.amount),
                locksroot: locksroot,
                payment_identifier: paymentId,
                token: token,
                recipient: recipient,
                lock: lock,
                target: action.payload.target,
                initiator: address,
                fee: fee,
            };
            signed$ = rxjs_1.from(utils_3.signMessage(signer, message));
        }
        return signed$.pipe(operators_1.mergeMap(function (signed) {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!secret) return [3 /*break*/, 2];
                        return [4 /*yield*/, actions_2.transferSecret({ secret: secret }, { secrethash: action.meta.secrethash })];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [4 /*yield*/, actions_2.transferSigned({ message: signed }, { secrethash: action.meta.secrethash })];
                    case 3:
                        _a.sent();
                        // TODO: retry messageSend
                        return [4 /*yield*/, actions_1.messageSend({ message: signed }, { address: signed.recipient })];
                    case 4:
                        // TODO: retry messageSend
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }));
    }), operators_1.catchError(function (err) { return rxjs_1.of(actions_2.transferFailed(err, action.meta)); }));
}
/**
 * Create an observable to compose and sign a Unlock message/transferUnlocked action
 * As it's an async observable which depends on state and may return an action which changes it,
 * the returned observable must be subscribed in a serialized context that ensures non-concurrent
 * write access to the channel's balance proof (e.g. concatMap)
 *
 * @param presences$  Observable of address to last matrixPresenceUpdate mapping
 * @param state$  Observable of current state
 * @param action  transfer request action to be sent
 * @param network,address,signer  RaidenEpicDeps members
 * @returns  Observable of output actions (transferSigned, transferSecret & messageSend)
 */
function makeAndSignUnlock(_a, state$, action, _b) {
    var signer = _b.signer;
    return state$.pipe(operators_1.first(), operators_1.mergeMap(function (state) {
        var secrethash = action.meta.secrethash;
        if (!(secrethash in state.sent))
            throw new Error('unknown transfer');
        var transfer = state.sent[secrethash].transfer;
        var signed$;
        if (state.sent[secrethash].unlock) {
            // unlock already signed, use cached
            signed$ = rxjs_1.of(state.sent[secrethash].unlock);
        }
        else if (!(transfer.token_network_address in state.channels) ||
            !(transfer.recipient in state.channels[transfer.token_network_address]))
            throw new Error('channel gone');
        else {
            var channel = state.channels[transfer.token_network_address][transfer.recipient], balanceProof = channel.own.balanceProof;
            if (channel.state !== state_1.ChannelState.open)
                throw new Error('channel not open');
            if (!balanceProof)
                throw new Error('assert: balanceProof gone');
            // don't forget to check after signature too, may have expired by then
            if (transfer.lock.expiration.lte(state.blockNumber))
                throw new Error('lock expired');
            var locks = (channel.own.locks || []).filter(function (l) { return l.secrethash !== secrethash; }), locksroot = utils_4.getLocksroot(locks), msgId = utils_4.makeMessageId();
            var message = {
                type: types_1.MessageType.UNLOCK,
                message_identifier: msgId,
                chain_id: transfer.chain_id,
                token_network_address: transfer.token_network_address,
                channel_identifier: transfer.channel_identifier,
                nonce: balanceProof.nonce.add(1),
                transferred_amount: balanceProof.transferredAmount.add(transfer.lock.amount),
                locked_amount: balanceProof.lockedAmount.sub(transfer.lock.amount),
                locksroot: locksroot,
                payment_identifier: transfer.payment_identifier,
                secret: state.secrets[action.meta.secrethash].secret,
            };
            signed$ = rxjs_1.from(utils_3.signMessage(signer, message));
        }
        return signed$.pipe(operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
            var signed = _a[0], state = _a[1];
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (transfer.lock.expiration.lte(state.blockNumber))
                            throw new Error('lock expired!');
                        return [4 /*yield*/, actions_2.transferUnlocked({ message: signed }, action.meta)];
                    case 1:
                        _b.sent();
                        // TODO: retry messageSend
                        return [4 /*yield*/, actions_1.messageSend({ message: signed }, { address: transfer.recipient })];
                    case 2:
                        // TODO: retry messageSend
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        }));
    }), operators_1.catchError(function (err) {
        console.error('Error when trying to unlock after SecretReveal', err);
        return rxjs_1.EMPTY;
    }));
}
/**
 * Serialize creation and signing of BalanceProof-changing messages or actions
 * Actions which change any data in any channel balance proof must only ever be created reading
 * state inside the serialization flow provided by the concatMap, and also be composed and produced
 * inside it (inner, subscribed observable)
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param deps  RaidenEpicDeps
 * @returns  Observable of output actions for this epic
 */
exports.transferGenerateAndSignEnvelopeMessageEpic = function (action$, state$, deps) {
    return rxjs_1.combineLatest(utils_2.getPresences$(action$), state$).pipe(operators_1.multicast(new rxjs_1.ReplaySubject(1), function (presencesStateReplay$) {
        var _a = rxjs_2.splitCombined(presencesStateReplay$), presences$ = _a[0], state$ = _a[1];
        return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_2.transfer, actions_2.transferUnlock])), operators_1.concatMap(function (action) {
            // TODO: add any other BP-changing observable below
            return typesafe_actions_1.isActionOf(actions_2.transfer, action)
                ? makeAndSignTransfer(presences$, state$, action, deps)
                : typesafe_actions_1.isActionOf(actions_2.transferUnlock, action)
                    ? makeAndSignUnlock(presences$, state$, action, deps)
                    : rxjs_1.EMPTY;
        }));
    }));
};
/**
 * Handles receiving a signed Processed for some sent LockedTransfer
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
exports.transferProcessedReceivedEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.messageReceived)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var message, secrethash, _i, _b, _c, key, sent;
        var action = _a[0], state = _a[1];
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    message = action.payload.message;
                    if (!message || !types_1.Signed(types_1.Processed).is(message))
                        return [2 /*return*/];
                    secrethash = undefined;
                    for (_i = 0, _b = Object.entries(state.sent); _i < _b.length; _i++) {
                        _c = _b[_i], key = _c[0], sent = _c[1];
                        if (sent.transfer.message_identifier.eq(message.message_identifier) &&
                            sent.transfer.recipient === action.meta.address) {
                            secrethash = key;
                            break;
                        }
                    }
                    if (!secrethash)
                        return [2 /*return*/];
                    return [4 /*yield*/, actions_2.transferProcessed({ message: message }, { secrethash: secrethash })];
                case 1:
                    _d.sent();
                    return [2 /*return*/];
            }
        });
    }));
};
/**
 * Handles receiving a signed SecretRequest for some sent LockedTransfer
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
exports.transferSecretRequestedEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.messageReceived)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var message, transfer;
        var action = _a[0], state = _a[1];
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    message = action.payload.message;
                    if (!message || !types_1.Signed(types_1.SecretRequest).is(message))
                        return [2 /*return*/];
                    if (!(message.secrethash in state.secrets) || !(message.secrethash in state.sent))
                        return [2 /*return*/];
                    transfer = state.sent[message.secrethash].transfer;
                    if (transfer.target !== action.meta.address ||
                        !transfer.payment_identifier.eq(message.payment_identifier) ||
                        !transfer.lock.amount.eq(message.amount) ||
                        !transfer.lock.expiration.eq(message.expiration))
                        return [2 /*return*/];
                    return [4 /*yield*/, actions_2.transferSecretRequest({ message: message }, { secrethash: message.secrethash })];
                case 1:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    }));
};
/**
 * Handles a transferSecretRequest action to send the respective secret
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param signer  RaidenEpicDeps signer
 * @returns  Observable of output actions for this epic
 */
exports.transferRevealSecretEpic = function (action$, state$, _a) {
    var signer = _a.signer;
    var cache = new lru_1.LruCache(32);
    return state$.pipe(operators_1.multicast(new rxjs_1.ReplaySubject(1), function (state$) {
        return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.transferSecretRequest)), operators_1.concatMap(function (action) {
            return state$.pipe(operators_1.first(), operators_1.mergeMap(function (state) {
                var target = state.sent[action.meta.secrethash].transfer.target;
                var cached = cache.get(action.meta.secrethash);
                if (cached)
                    return rxjs_1.of(actions_1.messageSend({ message: cached }, { address: target }));
                var message = {
                    type: types_1.MessageType.SECRET_REVEAL,
                    message_identifier: utils_4.makeMessageId(),
                    secret: state.secrets[action.meta.secrethash].secret,
                };
                return rxjs_1.from(utils_3.signMessage(signer, message)).pipe(operators_1.tap(function (signed) { return cache.put(action.meta.secrethash, signed); }), operators_1.map(function (signed) { return actions_1.messageSend({ message: signed }, { address: target }); }));
            }));
        }));
    }));
};
/**
 * Handles receiving a valid SecretReveal from recipient (neighbor/partner)
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
exports.transferSecretRevealedEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.messageReceived)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var message, secrethash;
        var action = _a[0], state = _a[1];
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    message = action.payload.message;
                    if (!message || !types_1.Signed(types_1.SecretReveal).is(message))
                        return [2 /*return*/];
                    secrethash = utils_1.keccak256(message.secret);
                    if (!(secrethash in state.sent) ||
                        action.meta.address !== state.sent[secrethash].transfer.recipient)
                        return [2 /*return*/];
                    // transferSecret is noop if we already know the secret (e.g. we're the initiator)
                    return [4 /*yield*/, actions_2.transferSecret({ secret: message.secret }, { secrethash: secrethash })];
                case 1:
                    // transferSecret is noop if we already know the secret (e.g. we're the initiator)
                    _b.sent();
                    return [4 /*yield*/, actions_2.transferUnlock({ message: message }, { secrethash: secrethash })];
                case 2:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    }));
};
/**
 * Handles receiving a signed Processed for some sent Unlock
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
exports.transferUnlockProcessedReceivedEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.messageReceived)), operators_1.withLatestFrom(state$), operators_1.mergeMap(function (_a) {
        var message, secrethash, _i, _b, _c, key, sent;
        var action = _a[0], state = _a[1];
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    message = action.payload.message;
                    if (!message || !types_1.Signed(types_1.Processed).is(message))
                        return [2 /*return*/];
                    for (_i = 0, _b = Object.entries(state.sent); _i < _b.length; _i++) {
                        _c = _b[_i], key = _c[0], sent = _c[1];
                        if (sent.unlock &&
                            sent.unlock.message_identifier.eq(message.message_identifier) &&
                            sent.transfer.recipient === action.meta.address) {
                            secrethash = key;
                            break;
                        }
                    }
                    if (!secrethash)
                        return [2 /*return*/];
                    return [4 /*yield*/, actions_2.transferUnlockProcessed({ message: message }, { secrethash: secrethash })];
                case 1:
                    _d.sent();
                    return [2 /*return*/];
            }
        });
    }));
};
/**
 * transferUnlockProcessed means transfer succeeded
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
exports.transferSuccessEpic = function (action$, state$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_2.transferUnlockProcessed)), operators_1.withLatestFrom(state$), operators_1.map(function (_a) {
        var action = _a[0], state = _a[1];
        return actions_2.transferred({
            balanceProof: utils_3.getBalanceProofFromEnvelopeMessage(state.sent[action.meta.secrethash].unlock),
        }, action.meta);
    }));
};
//# sourceMappingURL=epics.js.map