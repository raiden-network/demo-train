import { Hash } from '../utils/types';
import { LockedTransfer, Processed, SecretRequest, SecretReveal, Unlock } from '../messages/types';
declare type TransferId = {
    secrethash: Hash;
};
export declare const transfer: import("typesafe-actions").PayloadMetaAC<"transfer", {
    tokenNetwork: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    target: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    amount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
    fee?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>> | undefined;
    paymentId?: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<8>> | undefined;
    secret?: import("io-ts").Branded<string, import("../utils/types").HexStringB<number>> | undefined;
}, TransferId>;
export declare const transferSigned: import("typesafe-actions").PayloadMetaAC<"transferSigned", {
    message: LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferProcessed: import("typesafe-actions").PayloadMetaAC<"transferProcessed", {
    message: Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferSecret: import("typesafe-actions").PayloadMetaAC<"transferSecret", {
    secret: import("io-ts").Branded<string, import("../utils/types").HexStringB<number>>;
    registerBlock?: number | undefined;
}, TransferId>;
export declare const transferSecretRequest: import("typesafe-actions").PayloadMetaAC<"transferSecretRequest", {
    message: SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferUnlock: import("typesafe-actions").PayloadMetaAC<"transferUnlock", {
    message: SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferUnlocked: import("typesafe-actions").PayloadMetaAC<"transferUnlocked", {
    message: Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferUnlockProcessed: import("typesafe-actions").PayloadMetaAC<"transferUnlockProcessed", {
    message: Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, TransferId>;
export declare const transferred: import("typesafe-actions").PayloadMetaAC<"transferred", {
    balanceProof: {
        chainId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        tokenNetworkAddress: import("io-ts").Branded<import("io-ts").Branded<string, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channelId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        nonce: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<8>>;
        transferredAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        lockedAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        locksroot: Hash;
        messageHash: Hash;
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        sender: import("io-ts").Branded<import("io-ts").Branded<string, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    };
}, TransferId>;
export declare const transferFailed: (payload: Error, meta: TransferId) => {
    type: "transferFailed";
} & {
    payload: Error;
    error: boolean;
    meta: TransferId;
};
export {};
