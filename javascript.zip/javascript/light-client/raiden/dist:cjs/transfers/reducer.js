"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
var fp_1 = require("lodash/fp");
var constants_1 = require("ethers/constants");
var utils_1 = require("../messages/utils");
var state_1 = require("../store/state");
var actions_1 = require("./actions");
var utils_2 = require("./utils");
/**
 * Handles all transfers actions and requests
 *
 * @param state  Current RaidenState
 * @param action  RaidenAction to handle
 * @returns New RaidenState (or current, if action didn't change anything)
 */
function transfersReducer(state, action) {
    var _a, _b, _c, _d, _e;
    if (state === void 0) { state = state_1.initialState; }
    if (typesafe_actions_1.isActionOf(actions_1.transferSecret, action)) {
        if (action.meta.secrethash in state.secrets &&
            state.secrets[action.meta.secrethash].registerBlock)
            return state; // avoid storing without registerBlock if we already got with
        return __assign({}, state, { secrets: __assign({}, state.secrets, (_a = {}, _a[action.meta.secrethash] = action.payload, _a)) });
    }
    else if (typesafe_actions_1.isActionOf(actions_1.transferSigned, action)) {
        var transfer = action.payload.message, lock = transfer.lock, secrethash = lock.secrethash;
        // transferSigned must be the first action, to init SentTransfer state
        if (secrethash in state.sent)
            return state;
        var channelPath = ['channels', transfer.token_network_address, transfer.recipient];
        var channel = fp_1.get(channelPath, state);
        if (!channel)
            return state;
        var locks = (channel.own.locks || []).concat([lock]), // append lock
        locksroot = utils_2.getLocksroot(locks);
        if (transfer.locksroot !== locksroot ||
            !transfer.nonce.eq((channel.own.balanceProof ? channel.own.balanceProof.nonce : constants_1.Zero).add(1)) || // nonce must be next
            !transfer.transferred_amount.eq(channel.own.balanceProof ? channel.own.balanceProof.transferredAmount : constants_1.Zero) ||
            !transfer.locked_amount.eq((channel.own.balanceProof ? channel.own.balanceProof.lockedAmount : constants_1.Zero).add(lock.amount)))
            return state;
        channel = __assign({}, channel, { own: __assign({}, channel.own, { locks: locks, 
                // set current/latest channel.own.balanceProof to LockedTransfer's
                balanceProof: utils_1.getBalanceProofFromEnvelopeMessage(transfer), history: __assign({}, channel.own.history, (_b = {}, _b[Date.now().toString()] = transfer, _b)) }) });
        var sentTransfer = { transfer: transfer };
        state = fp_1.set(channelPath, channel, state);
        state = fp_1.set(['sent', secrethash], sentTransfer, state);
        return state;
    }
    else if (typesafe_actions_1.isActionOf(actions_1.transferProcessed, action)) {
        if (!(action.meta.secrethash in state.sent))
            return state;
        return __assign({}, state, { sent: __assign({}, state.sent, (_c = {}, _c[action.meta.secrethash] = __assign({}, state.sent[action.meta.secrethash], { transferProcessed: action.payload.message }), _c)) });
    }
    else if (typesafe_actions_1.isActionOf(actions_1.transferUnlock, action)) {
        if (!(action.meta.secrethash in state.sent))
            return state;
        return __assign({}, state, { sent: __assign({}, state.sent, (_d = {}, _d[action.meta.secrethash] = __assign({}, state.sent[action.meta.secrethash], { secretReveal: action.payload.message }), _d)) });
    }
    else if (typesafe_actions_1.isActionOf(actions_1.transferUnlocked, action)) {
        var unlock = action.payload.message, secrethash_1 = action.meta.secrethash;
        if (!(secrethash_1 in state.sent) || state.sent[secrethash_1].unlock)
            return state;
        var transfer = state.sent[secrethash_1].transfer, lock = transfer.lock;
        var channelPath = ['channels', transfer.token_network_address, transfer.recipient];
        var channel = fp_1.get(channelPath, state);
        if (!channel || !channel.own.locks || !channel.own.balanceProof)
            return state;
        var locks = channel.own.locks.filter(function (l) { return l.secrethash !== secrethash_1; }), locksroot = utils_2.getLocksroot(locks);
        if (unlock.locksroot !== locksroot ||
            !channel.own.balanceProof.nonce.add(1).eq(unlock.nonce) || // nonce must be next
            !unlock.transferred_amount.eq(channel.own.balanceProof.transferredAmount.add(lock.amount)) ||
            !unlock.locked_amount.eq(channel.own.balanceProof.lockedAmount.sub(lock.amount)))
            return state;
        channel = __assign({}, channel, { own: __assign({}, channel.own, { locks: locks, 
                // set current/latest channel.own.balanceProof to LockedTransfer's
                balanceProof: utils_1.getBalanceProofFromEnvelopeMessage(unlock), history: __assign({}, channel.own.history, (_e = {}, _e[Date.now().toString()] = unlock, _e)) }) });
        var sentTransfer = __assign({}, state.sent[secrethash_1], { unlock: unlock });
        state = fp_1.set(channelPath, channel, state);
        state = fp_1.set(['sent', secrethash_1], sentTransfer, state);
        return state;
    }
    else if (typesafe_actions_1.isActionOf(actions_1.transferred, action)) {
        if (!(action.meta.secrethash in state.sent))
            return state;
        state = fp_1.unset(['sent', action.meta.secrethash], state);
        state = fp_1.unset(['secrets', action.meta.secrethash], state);
        return state;
    }
    else
        return state;
}
exports.transfersReducer = transfersReducer;
//# sourceMappingURL=reducer.js.map