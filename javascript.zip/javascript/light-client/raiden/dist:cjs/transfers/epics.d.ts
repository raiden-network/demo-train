import { Observable } from 'rxjs';
import { RaidenEpicDeps } from '../types';
import { RaidenState } from '../store';
import { Hash } from '../utils/types';
import { LockedTransfer, Processed, SecretRequest, SecretReveal, Unlock } from '../messages/types';
/**
 * Serialize creation and signing of BalanceProof-changing messages or actions
 * Actions which change any data in any channel balance proof must only ever be created reading
 * state inside the serialization flow provided by the concatMap, and also be composed and produced
 * inside it (inner, subscribed observable)
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param deps  RaidenEpicDeps
 * @returns  Observable of output actions for this epic
 */
export declare const transferGenerateAndSignEnvelopeMessageEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, deps: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"messageSend", {
    message: string | (import("../messages/types").Delivered & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("../messages/types").RefundTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("../messages/types").LockExpired & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    });
}, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}> | import("typesafe-actions").PayloadMetaAction<"transferSecret", {
    secret: import("io-ts").Branded<string, import("../utils/types").HexStringB<number>>;
    registerBlock?: number | undefined;
}, {
    secrethash: Hash;
}> | import("typesafe-actions").PayloadMetaAction<"transferSigned", {
    message: LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}> | ({
    type: "transferFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        secrethash: Hash;
    };
}) | import("typesafe-actions").PayloadMetaAction<"transferUnlocked", {
    message: Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}>>;
/**
 * Handles receiving a signed Processed for some sent LockedTransfer
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
export declare const transferProcessedReceivedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferProcessed", {
    message: Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}>>;
/**
 * Handles receiving a signed SecretRequest for some sent LockedTransfer
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
export declare const transferSecretRequestedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferSecretRequest", {
    message: SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}>>;
/**
 * Handles a transferSecretRequest action to send the respective secret
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @param signer  RaidenEpicDeps signer
 * @returns  Observable of output actions for this epic
 */
export declare const transferRevealSecretEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>, { signer }: RaidenEpicDeps) => Observable<import("typesafe-actions").PayloadMetaAction<"messageSend", {
    message: string | (import("../messages/types").Delivered & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (SecretRequest & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (LockedTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("../messages/types").RefundTransfer & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (Unlock & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    }) | (import("../messages/types").LockExpired & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    });
}, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>>;
/**
 * Handles receiving a valid SecretReveal from recipient (neighbor/partner)
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
export declare const transferSecretRevealedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferSecret", {
    secret: import("io-ts").Branded<string, import("../utils/types").HexStringB<number>>;
    registerBlock?: number | undefined;
}, {
    secrethash: Hash;
}> | import("typesafe-actions").PayloadMetaAction<"transferUnlock", {
    message: SecretReveal & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}>>;
/**
 * Handles receiving a signed Processed for some sent Unlock
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
export declare const transferUnlockProcessedReceivedEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferUnlockProcessed", {
    message: Processed & {
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
    };
}, {
    secrethash: Hash;
}>>;
/**
 * transferUnlockProcessed means transfer succeeded
 *
 * @param action$  Observable of RaidenActions
 * @param state$  Observable of RaidenStates
 * @returns  Observable of output actions for this epic
 */
export declare const transferSuccessEpic: (action$: Observable<import("typesafe-actions").Action<string>>, state$: Observable<RaidenState>) => Observable<import("typesafe-actions").PayloadMetaAction<"transferred", {
    balanceProof: {
        chainId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        tokenNetworkAddress: import("io-ts").Branded<import("io-ts").Branded<string, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channelId: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        nonce: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<8>>;
        transferredAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        lockedAmount: import("io-ts").Branded<import("ethers/utils").BigNumber, import("../utils/types").UIntB<32>>;
        locksroot: Hash;
        messageHash: Hash;
        signature: import("io-ts").Branded<string, import("../utils/types").HexStringB<65>>;
        sender: import("io-ts").Branded<import("io-ts").Branded<string, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
    };
}, {
    secrethash: Hash;
}>>;
