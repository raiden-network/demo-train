import * as t from 'io-ts';
/**
 * This struct holds the relevant messages exchanged in a transfer
 * The transfer state is defined by the exchanged messages
 */
export declare const SentTransfer: t.IntersectionC<[t.TypeC<{
    transfer: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
    }>, t.IntersectionC<[t.TypeC<{
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        lock: t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>;
        target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
}>, t.PartialC<{
    transferProcessed: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.PROCESSED>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    secretReveal: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.SECRET_REVEAL>;
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    unlock: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    lockExpired: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
}>]>;
export declare type SentTransfer = t.TypeOf<typeof SentTransfer>;
/**
 * Mapping of outgoing transfers, indexed by the secrethash
 */
export declare const SentTransfers: t.RecordC<t.StringC, t.IntersectionC<[t.TypeC<{
    transfer: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCKED_TRANSFER>;
    }>, t.IntersectionC<[t.TypeC<{
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        token: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        lock: t.TypeC<{
            type: t.LiteralC<"Lock">;
            amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            expiration: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
            secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
        }>;
        target: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        initiator: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        fee: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
}>, t.PartialC<{
    transferProcessed: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.PROCESSED>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    secretReveal: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.SECRET_REVEAL>;
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    unlock: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.UNLOCK>;
        payment_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        secret: t.BrandC<t.StringC, import("../utils/types").HexStringB<number>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
    lockExpired: t.IntersectionC<[t.IntersectionC<[t.TypeC<{
        type: t.LiteralC<import("../messages/types").MessageType.LOCK_EXPIRED>;
        recipient: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        secrethash: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        chain_id: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        token_network_address: t.BrandC<t.BrandC<t.StringC, import("../utils/types").HexStringB<20>>, import("../utils/types").HexStringB<20> & import("../utils/types").AddressB>;
        channel_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        nonce: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
        transferred_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locked_amount: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<32>>;
        locksroot: t.BrandC<t.StringC, import("../utils/types").HexStringB<32>>;
    }>, t.IntersectionC<[t.TypeC<{
        message_identifier: t.BrandC<t.Type<import("ethers/utils").BigNumber, import("lossless-json").LosslessNumber, unknown>, import("../utils/types").UIntB<8>>;
    }>, t.TypeC<{
        type: import("../utils/types").EnumType<import("../messages/types").MessageType>;
    }>]>]>]>, t.TypeC<{
        signature: t.BrandC<t.StringC, import("../utils/types").HexStringB<65>>;
    }>]>;
}>]>>;
export declare type SentTransfers = t.TypeOf<typeof SentTransfers>;
