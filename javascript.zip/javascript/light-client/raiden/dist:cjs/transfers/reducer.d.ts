import { RaidenState } from '../store/state';
import { RaidenAction } from '../actions';
/**
 * Handles all transfers actions and requests
 *
 * @param state  Current RaidenState
 * @param action  RaidenAction to handle
 * @returns New RaidenState (or current, if action didn't change anything)
 */
export declare function transfersReducer(state: Readonly<RaidenState> | undefined, action: RaidenAction): RaidenState;
