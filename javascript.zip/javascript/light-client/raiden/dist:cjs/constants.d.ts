export declare const SignatureZero: Uint8Array;
export declare const MATRIX_KNOWN_SERVERS_URL: {
    [networkName: string]: string;
};
export declare enum ShutdownReason {
    STOP = "raidenStopped",
    ACCOUNT_CHANGED = "providerAccountChanged",
    NETWORK_CHANGED = "providerNetworkChanged"
}
export declare const REVEAL_TIMEOUT = 50;
