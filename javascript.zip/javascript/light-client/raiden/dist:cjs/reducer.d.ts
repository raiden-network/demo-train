import { RaidenState } from './store/state';
/**
 * Raiden root reducer
 * Apply action over each submodule root reducer in a flattened manner (iteratively).
 * Notice the submodules reducers aren't handled only a partial/deep property of the state
 * (as combineReducers), but instead receive the whole state, so they can act on any part of the
 * state. This approach is similar to `reduce-reducers` util.
 * Each submodule root reducer may then choose to split its concerns into nested or flattened
 * reducers (like this one).
 */
export declare const raidenReducer: (state: Readonly<RaidenState> | undefined, action: import("typesafe-actions").Action<string>) => Readonly<RaidenState>;
