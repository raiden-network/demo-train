"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ethers_1 = require("ethers");
var providers_1 = require("ethers/providers");
var utils_1 = require("ethers/utils");
var constants_1 = require("ethers/constants");
var redux_1 = require("redux");
var redux_observable_1 = require("redux-observable");
var typesafe_actions_1 = require("typesafe-actions");
var redux_logger_1 = require("redux-logger");
var lodash_1 = require("lodash");
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var TokenNetworkRegistry_json_1 = __importDefault(require("./abi/TokenNetworkRegistry.json"));
var TokenNetwork_json_1 = __importDefault(require("./abi/TokenNetwork.json"));
var Token_json_1 = __importDefault(require("./abi/Token.json"));
var deployment_ropsten_json_1 = __importDefault(require("./deployment/deployment_ropsten.json"));
var deployment_rinkeby_json_1 = __importDefault(require("./deployment/deployment_rinkeby.json"));
var deployment_kovan_json_1 = __importDefault(require("./deployment/deployment_kovan.json"));
var deployment_goerli_json_1 = __importDefault(require("./deployment/deployment_goerli.json"));
var constants_2 = require("./constants");
var types_1 = require("./utils/types");
var store_1 = require("./store");
var reducer_1 = require("./reducer");
var epics_1 = require("./epics");
var actions_1 = require("./actions");
var actions_2 = require("./store/actions");
var actions_3 = require("./channels/actions");
var actions_4 = require("./transport/actions");
var actions_5 = require("./transfers/actions");
var utils_2 = require("./transfers/utils");
var Raiden = /** @class */ (function () {
    function Raiden(provider, network, signer, contractsInfo, state) {
        this.tokenInfo = {};
        this.provider = provider;
        this.network = network;
        this.signer = signer;
        var address = state.address;
        this.contracts = {
            registry: new ethers_1.Contract(contractsInfo.TokenNetworkRegistry.address, TokenNetworkRegistry_json_1.default, this.signer),
            tokenNetworks: {},
            tokens: {},
        };
        var middlewares = [];
        if (process.env.NODE_ENV === 'development') {
            middlewares.push(redux_logger_1.createLogger({ level: 'debug' }));
        }
        var state$ = new rxjs_1.BehaviorSubject(state);
        this.state$ = state$;
        var action$ = new rxjs_1.Subject();
        this.action$ = action$;
        var matrix$ = new rxjs_1.AsyncSubject();
        this.channels$ = state$.pipe(operators_1.map(function (state) {
            return lodash_1.transform(
            // transform state.channels to token-partner-raidenChannel map
            state.channels, function (result, partner2channel, tokenNetwork) {
                var token = lodash_1.findKey(state.tokens, function (tn) { return tn === tokenNetwork; });
                if (!token)
                    return; // shouldn't happen, token mapping is always bi-direction
                result[token] = lodash_1.transform(
                // transform Channel to RaidenChannel, with more info
                partner2channel, function (partner2raidenChannel, channel, partner) {
                    return (partner2raidenChannel[partner] = __assign({ state: channel.state }, lodash_1.pick(channel, ['id', 'settleTimeout', 'openBlock', 'closeBlock']), { token: token, tokenNetwork: tokenNetwork, partner: partner, ownDeposit: channel.own.deposit, partnerDeposit: channel.partner.deposit, 
                        // balance is difference between is partner's and own transfered+locked amounts
                        balance: (channel.partner.balanceProof
                            ? channel.partner.balanceProof.transferredAmount.add(channel.partner.balanceProof.lockedAmount)
                            : constants_1.Zero).sub(channel.own.balanceProof
                            ? channel.own.balanceProof.transferredAmount.add(channel.own.balanceProof.lockedAmount)
                            : constants_1.Zero) }));
                });
            });
        }));
        this.events$ = action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(Object.values(actions_1.RaidenEvents))));
        // minimum blockNumber of contracts deployment as start scan block
        var epicMiddleware = redux_observable_1.createEpicMiddleware({
            dependencies: {
                stateOutput$: state$,
                actionOutput$: action$,
                matrix$: matrix$,
                provider: provider,
                network: network,
                signer: signer,
                address: address,
                contractsInfo: contractsInfo,
                registryContract: this.contracts.registry,
                getTokenNetworkContract: this.getTokenNetworkContract.bind(this),
                getTokenContract: this.getTokenContract.bind(this),
            },
        });
        this.store = redux_1.createStore(reducer_1.raidenReducer, state, redux_1.applyMiddleware.apply(void 0, middlewares.concat([epicMiddleware])));
        epicMiddleware.run(epics_1.raidenRootEpic);
        state = this.store.getState();
        // use next from latest known blockNumber as start block when polling
        this.provider.resetEventsBlock(state.blockNumber + 1);
        this.resolveName = provider.resolveName.bind(provider);
        // initialize epics, this will start monitoring previous token networks and open channels
        this.store.dispatch(actions_2.raidenInit());
    }
    /**
     * Async helper factory to make a Raiden instance from more common parameters.
     *
     * @param connection
     * - a JsonRpcProvider instance
     * - a Metamask's web3.currentProvider object or
     * - a hostname or remote json-rpc connection string
     * @param account
     * - a string address of an account loaded in provider or
     * - a string private key or
     * - a number index of an account loaded in provider (e.g. 0 for Metamask's loaded account)
     * @param storageOrState
     *   Storage/localStorage-like synchronous object where to load and store current state or
     *   initial RaidenState-like object instead. In this case, user must listen state$ changes
     *   and update them on whichever persistency option is used
     * @param contracts
     *   Contracts deployment info
     * @returns Promise to Raiden SDK client instance
     * An async factory is needed so we can do the needed async requests to construct the required
     * parameters ahead of construction time, and avoid partial initialization then
     **/
    Raiden.create = function (connection, account, storageOrState, contracts) {
        return __awaiter(this, void 0, void 0, function () {
            // type guard
            function isStorage(storageOrState) {
                return storageOrState && typeof storageOrState.getItem === 'function';
            }
            var provider, network, signer, accounts, address, loadedState, onState, onStateComplete, ns_1, loaded, _a, _b, _c, _d, _e, debouncedState_1, raiden;
            return __generator(this, function (_f) {
                switch (_f.label) {
                    case 0:
                        if (typeof connection === 'string') {
                            provider = new providers_1.JsonRpcProvider(connection);
                        }
                        else if (connection instanceof providers_1.JsonRpcProvider) {
                            provider = connection;
                        }
                        else {
                            provider = new providers_1.Web3Provider(connection);
                        }
                        return [4 /*yield*/, provider.getNetwork()];
                    case 1:
                        network = _f.sent();
                        // if no ContractsInfo, try to populate from defaults
                        if (!contracts) {
                            switch (network.name) {
                                case 'rinkeby':
                                    contracts = deployment_rinkeby_json_1.default.contracts;
                                    break;
                                case 'ropsten':
                                    contracts = deployment_ropsten_json_1.default.contracts;
                                    break;
                                case 'kovan':
                                    contracts = deployment_kovan_json_1.default.contracts;
                                    break;
                                case 'goerli':
                                    contracts = deployment_goerli_json_1.default.contracts;
                                    break;
                                default:
                                    throw new Error("No deploy info provided nor recognized network: " + JSON.stringify(network));
                            }
                        }
                        if (!(typeof account === 'number')) return [3 /*break*/, 2];
                        // index of account in provider
                        signer = provider.getSigner(account);
                        return [3 /*break*/, 5];
                    case 2:
                        if (!types_1.Address.is(account)) return [3 /*break*/, 4];
                        return [4 /*yield*/, provider.listAccounts()];
                    case 3:
                        accounts = _f.sent();
                        if (!accounts.includes(account))
                            throw new Error("Account \"" + account + "\" not found in provider, got=" + accounts);
                        signer = provider.getSigner(account);
                        return [3 /*break*/, 5];
                    case 4:
                        if (types_1.PrivateKey.is(account)) {
                            // private key
                            signer = new ethers_1.Wallet(account, provider);
                        }
                        else {
                            throw new Error('String account must be either a 0x-encoded address or private key');
                        }
                        _f.label = 5;
                    case 5: return [4 /*yield*/, signer.getAddress()];
                    case 6:
                        address = (_f.sent());
                        loadedState = __assign({}, store_1.initialState, { blockNumber: contracts.TokenNetworkRegistry.block_number || 0, address: address });
                        onState = undefined, onStateComplete = undefined;
                        if (!(storageOrState && isStorage(storageOrState))) return [3 /*break*/, 8];
                        ns_1 = "raiden_" + (network.name || network.chainId) + "_" + contracts.TokenNetworkRegistry.address + "_" + address;
                        _b = (_a = Object).assign;
                        _c = [{},
                            loadedState];
                        _e = (_d = JSON).parse;
                        return [4 /*yield*/, storageOrState.getItem(ns_1)];
                    case 7:
                        loaded = _b.apply(_a, _c.concat([_e.apply(_d, [(_f.sent()) || 'null'])]));
                        loadedState = store_1.decodeRaidenState(loaded);
                        debouncedState_1 = lodash_1.debounce(function (state) {
                            storageOrState.setItem(ns_1, store_1.encodeRaidenState(state));
                        }, 1000, { maxWait: 5000 });
                        onState = debouncedState_1;
                        onStateComplete = function () { return debouncedState_1.flush(); };
                        return [3 /*break*/, 9];
                    case 8:
                        if (storageOrState && store_1.RaidenState.is(storageOrState)) {
                            loadedState = storageOrState;
                        }
                        else if (storageOrState /* typeof storageOrState === unknown */) {
                            loadedState = store_1.decodeRaidenState(storageOrState);
                        }
                        _f.label = 9;
                    case 9:
                        if (address !== loadedState.address)
                            throw new Error("Mismatch between provided account and loaded state: \"" + address + "\" !== \"" + loadedState.address + "\"");
                        raiden = new Raiden(provider, network, signer, contracts, loadedState);
                        if (onState)
                            raiden.state$.subscribe(onState, onStateComplete, onStateComplete);
                        return [2 /*return*/, raiden];
                }
            });
        });
    };
    /**
     * Triggers all epics to be unsubscribed
     */
    Raiden.prototype.stop = function () {
        this.store.dispatch(actions_2.raidenShutdown({ reason: constants_2.ShutdownReason.STOP }));
    };
    Object.defineProperty(Raiden.prototype, "state", {
        get: function () {
            return this.store.getState();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Raiden.prototype, "address", {
        get: function () {
            return this.state.address;
        },
        enumerable: true,
        configurable: true
    });
    Raiden.prototype.getBlockNumber = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = this.provider.blockNumber;
                        if (_a) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.provider.getBlockNumber()];
                    case 1:
                        _a = (_b.sent());
                        _b.label = 2;
                    case 2: return [2 /*return*/, _a];
                }
            });
        });
    };
    /**
     * Get ETH balance for given address or self
     *
     * @param address  Optional target address. If omitted, gets own balance
     * @returns  BigNumber of ETH balance
     */
    Raiden.prototype.getBalance = function (address) {
        address = address || this.address;
        if (!types_1.Address.is(address))
            throw new Error('Invalid address');
        return this.provider.getBalance(address);
    };
    /**
     * Get token balance and token decimals for given address or self
     *
     * @param token  Token address to fetch balance. Must be one of the monitored tokens.
     * @param address  Optional target address. If omitted, gets own balance
     * @returns  BigNumber containing address's token balance
     */
    Raiden.prototype.getTokenBalance = function (token, address) {
        return __awaiter(this, void 0, void 0, function () {
            var tokenContract;
            return __generator(this, function (_a) {
                address = address || this.address;
                if (!types_1.Address.is(address) || !types_1.Address.is(token))
                    throw new Error('Invalid address');
                if (!(token in this.state.tokens))
                    throw new Error("token \"" + token + "\" not monitored");
                tokenContract = this.getTokenContract(token);
                return [2 /*return*/, tokenContract.functions.balanceOf(address)];
            });
        });
    };
    /**
     * Get token information: totalSupply, decimals, name and symbol
     * Rejects only if 'token' contract doesn't define totalSupply and decimals methods.
     * name and symbol may be undefined, as they aren't actually part of ERC20 standard, although
     * very common and defined on most token contracts.
     *
     * @param token address to fetch info from
     * @returns TokenInfo
     */
    Raiden.prototype.getTokenInfo = function (token) {
        return __awaiter(this, void 0, void 0, function () {
            var tokenContract, _a, totalSupply, decimals, name_1, symbol;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!types_1.Address.is(token))
                            throw new Error('Invalid address');
                        /* tokenInfo isn't in state as it isn't relevant for being preserved, it's merely a cache */
                        if (!(token in this.state.tokens))
                            throw new Error("token \"" + token + "\" not monitored");
                        if (!!(token in this.tokenInfo)) return [3 /*break*/, 2];
                        tokenContract = this.getTokenContract(token);
                        return [4 /*yield*/, Promise.all([
                                tokenContract.functions.totalSupply(),
                                tokenContract.functions.decimals(),
                                tokenContract.functions.name().catch(lodash_1.constant(undefined)),
                                tokenContract.functions.symbol().catch(lodash_1.constant(undefined)),
                            ])];
                    case 1:
                        _a = _b.sent(), totalSupply = _a[0], decimals = _a[1], name_1 = _a[2], symbol = _a[3];
                        this.tokenInfo[token] = { totalSupply: totalSupply, decimals: decimals, name: name_1, symbol: symbol };
                        _b.label = 2;
                    case 2: return [2 /*return*/, this.tokenInfo[token]];
                }
            });
        });
    };
    /**
     * Returns a list of all token addresses registered as token networks in registry
     *
     * @returns Promise to list of token addresses
     */
    Raiden.prototype.getTokenList = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!lodash_1.isEmpty(this.state.tokens)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.action$
                                .pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_3.tokenMonitored)), operators_1.first())
                                .toPromise()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, Object.keys(this.state.tokens)];
                }
            });
        });
    };
    /**
     * Create a TokenNetwork contract linked to this.signer for given tokenNetwork address
     * Caches the result and returns the same contract instance again for the same address on this
     *
     * @param address  TokenNetwork contract address (not token address!)
     * @returns  TokenNetwork Contract instance
     */
    Raiden.prototype.getTokenNetworkContract = function (address) {
        if (!(address in this.contracts.tokenNetworks))
            this.contracts.tokenNetworks[address] = new ethers_1.Contract(address, TokenNetwork_json_1.default, this.signer);
        return this.contracts.tokenNetworks[address];
    };
    /**
     * Create a Token contract linked to this.signer for given token address
     * Caches the result and returns the same contract instance again for the same address on this
     *
     * @param address  Token contract address
     * @returns  Token Contract instance
     */
    Raiden.prototype.getTokenContract = function (address) {
        if (!(address in this.contracts.tokens))
            this.contracts.tokens[address] = new ethers_1.Contract(address, Token_json_1.default, this.signer);
        return this.contracts.tokens[address];
    };
    /**
     * Open a channel on the tokenNetwork for given token address with partner
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @param settleTimeout  openChannel parameter, defaults to 500
     * @returns  txHash of channelOpen call, iff it succeeded
     */
    Raiden.prototype.openChannel = function (token, partner, settleTimeout) {
        if (settleTimeout === void 0) { settleTimeout = 500; }
        return __awaiter(this, void 0, void 0, function () {
            var state, tokenNetwork, promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(token) || !types_1.Address.is(partner))
                    throw new Error('Invalid address');
                state = this.state;
                tokenNetwork = state.tokens[token];
                if (!tokenNetwork)
                    throw new Error('Unknown token network');
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_3.channelOpened, actions_3.channelOpenFailed])), operators_1.filter(function (action) { return action.meta.tokenNetwork === tokenNetwork && action.meta.partner === partner; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_3.channelOpenFailed, action))
                        throw action.payload;
                    return action.payload.txHash;
                }))
                    .toPromise();
                this.store.dispatch(actions_3.channelOpen({ settleTimeout: settleTimeout }, { tokenNetwork: tokenNetwork, partner: partner }));
                return [2 /*return*/, promise];
            });
        });
    };
    /**
     * Deposit tokens on channel between us and partner on tokenNetwork for token
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @param deposit  Number of tokens to deposit on channel
     * @returns  txHash of setTotalDeposit call, iff it succeeded
     */
    Raiden.prototype.depositChannel = function (token, partner, deposit) {
        return __awaiter(this, void 0, void 0, function () {
            var state, tokenNetwork, promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(token) || !types_1.Address.is(partner))
                    throw new Error('Invalid address');
                state = this.state;
                tokenNetwork = state.tokens[token];
                if (!tokenNetwork)
                    throw new Error('Unknown token network');
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_3.channelDeposited, actions_3.channelDepositFailed])), operators_1.filter(function (action) { return action.meta.tokenNetwork === tokenNetwork && action.meta.partner === partner; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_3.channelDepositFailed, action))
                        throw action.payload;
                    return action.payload.txHash;
                }))
                    .toPromise();
                this.store.dispatch(actions_3.channelDeposit({ deposit: utils_1.bigNumberify(deposit) }, { tokenNetwork: tokenNetwork, partner: partner }));
                return [2 /*return*/, promise];
            });
        });
    };
    /**
     * Close channel between us and partner on tokenNetwork for token
     * This method will fail if called on a channel not in 'opened' or 'closing' state.
     * When calling this method on an 'opened' channel, its state becomes 'closing', and from there
     * on, no payments can be performed on the channel. If for any reason the closeChannel
     * transaction fails, channel's state stays as 'closing', and this method can be called again
     * to retry sending 'closeChannel' transaction. After it's successful, channel becomes 'closed',
     * and can be settled after 'settleTimeout' blocks (when it then becomes 'settleable').
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @returns  txHash of closeChannel call, iff it succeeded
     */
    Raiden.prototype.closeChannel = function (token, partner) {
        return __awaiter(this, void 0, void 0, function () {
            var state, tokenNetwork, promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(token) || !types_1.Address.is(partner))
                    throw new Error('Invalid address');
                state = this.state;
                tokenNetwork = state.tokens[token];
                if (!tokenNetwork)
                    throw new Error('Unknown token network');
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_3.channelClosed, actions_3.channelCloseFailed])), operators_1.filter(function (action) { return action.meta.tokenNetwork === tokenNetwork && action.meta.partner === partner; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_3.channelCloseFailed, action))
                        throw action.payload;
                    return action.payload.txHash;
                }))
                    .toPromise();
                this.store.dispatch(actions_3.channelClose(undefined, { tokenNetwork: tokenNetwork, partner: partner }));
                return [2 /*return*/, promise];
            });
        });
    };
    /**
     * Settle channel between us and partner on tokenNetwork for token
     * This method will fail if called on a channel not in 'settleable' or 'settling' state.
     * Channel becomes 'settleable' settleTimeout blocks after closed (detected automatically
     * while Raiden Light Client is running or later on restart). When calling it, channel state
     * becomes 'settling'. If for any reason transaction fails, it'll stay on this state, and this
     * method can be called again to re-send a settleChannel transaction.
     *
     * @param token  Token address on currently configured token network registry
     * @param partner  Partner address
     * @returns  txHash of settleChannel call, iff it succeeded
     */
    Raiden.prototype.settleChannel = function (token, partner) {
        return __awaiter(this, void 0, void 0, function () {
            var state, tokenNetwork, promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(token) || !types_1.Address.is(partner))
                    throw new Error('Invalid address');
                state = this.state;
                tokenNetwork = state.tokens[token];
                if (!tokenNetwork)
                    throw new Error('Unknown token network');
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_3.channelSettled, actions_3.channelSettleFailed])), operators_1.filter(function (action) { return action.meta.tokenNetwork === tokenNetwork && action.meta.partner === partner; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_3.channelSettleFailed, action))
                        throw action.payload;
                    return action.payload.txHash;
                }))
                    .toPromise();
                this.store.dispatch(actions_3.channelSettle(undefined, { tokenNetwork: tokenNetwork, partner: partner }));
                return [2 /*return*/, promise];
            });
        });
    };
    /**
     * Returns object describing address's users availability on transport
     * After calling this method, any further presence update to valid transport peers of this
     * address will trigger a corresponding MatrixPresenceUpdateAction on events$
     *
     * @param address checksummed address to be monitored
     * @returns Promise to object describing availability and last event timestamp
     */
    Raiden.prototype.getAvailability = function (address) {
        return __awaiter(this, void 0, void 0, function () {
            var promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(address))
                    throw new Error('Invalid address');
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_4.matrixPresenceUpdate, actions_4.matrixRequestMonitorPresenceFailed])), operators_1.filter(function (action) { return action.meta.address === address; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_4.matrixRequestMonitorPresenceFailed, action))
                        throw action.payload;
                    return action.payload;
                }))
                    .toPromise();
                this.store.dispatch(actions_4.matrixRequestMonitorPresence(undefined, { address: address }));
                return [2 /*return*/, promise];
            });
        });
    };
    /**
     * Send a Locked Transfer!
     * Coverage ignored until we handle the full transfer lifecycle
     * TODO: remove uncover when implemented
     *
     * @param token  Token address on currently configured token network registry
     * @param target  Target address (must be getAvailability before)
     * @param amount  Amount to try to transfer
     * @param opts.paymentId  Optionally specify a paymentId to use for this transfer
     * @param opts.secret  Optionally specify a secret to use on this transfer
     *    (in which case, it'll be registered and revealed to target)
     * @param opts.secrethash  Optionally specify a secrethash to use. If secret is provided,
     *    secrethash must be the keccak256 hash of the secret. If no secret is provided, the target
     *    must be informed of it by other means/externally.
     * @returns A promise to the total transferred amount on this channel after transfer succeeds
     */
    /* istanbul ignore next */
    Raiden.prototype.transfer = function (token, target, amount, opts) {
        return __awaiter(this, void 0, void 0, function () {
            var tokenNetwork, paymentId, secret, secrethash, _secret, _secrethash, promise;
            return __generator(this, function (_a) {
                if (!types_1.Address.is(token) || !types_1.Address.is(target))
                    throw new Error('Invalid address');
                tokenNetwork = this.state.tokens[token];
                if (!tokenNetwork)
                    throw new Error('Unknown token network');
                amount = utils_1.bigNumberify(amount);
                if (!types_1.UInt(32).is(amount))
                    throw new Error('Invalid amount');
                paymentId = !opts || !opts.paymentId ? undefined : utils_1.bigNumberify(opts.paymentId);
                if (paymentId && !types_1.UInt(8).is(paymentId))
                    throw new Error('Invalid opts.paymentId');
                if (opts) {
                    _secret = opts.secret;
                    if (_secret !== undefined && !types_1.Secret.is(_secret))
                        throw new Error('Invalid opts.secret');
                    _secrethash = opts.secrethash;
                    if (_secrethash !== undefined && !types_1.Hash.is(_secrethash))
                        throw new Error('Invalid opts.secrethash');
                    secret = _secret;
                    secrethash = _secrethash;
                }
                if (!secrethash) {
                    if (!secret)
                        secret = utils_2.makeSecret();
                    secrethash = utils_1.keccak256(secret);
                }
                else if (secret && utils_1.keccak256(secret) !== secrethash) {
                    throw new Error('Secret and secrethash must match if passing both');
                }
                promise = this.action$
                    .pipe(operators_1.filter(typesafe_actions_1.isActionOf([actions_5.transferred, actions_5.transferFailed])), operators_1.filter(function (action) { return action.meta.secrethash === secrethash; }), operators_1.first(), operators_1.map(function (action) {
                    if (typesafe_actions_1.isActionOf(actions_5.transferFailed, action))
                        throw action.payload;
                    return action.payload.balanceProof.transferredAmount;
                }))
                    .toPromise();
                this.store.dispatch(actions_5.transfer({ tokenNetwork: tokenNetwork, target: target, amount: amount, paymentId: paymentId, secret: secret }, { secrethash: secrethash }));
                return [2 /*return*/, promise];
            });
        });
    };
    return Raiden;
}());
exports.Raiden = Raiden;
exports.default = Raiden;
//# sourceMappingURL=raiden.js.map