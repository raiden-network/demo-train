import { RaidenState } from '../store/state';
/**
 * Nested/combined reducer for transport
 * Currently only handles 'transport' substate
 */
export declare const transportReducer: import("redux").Reducer<Readonly<RaidenState>, import("redux").AnyAction>;
