import { Observable } from 'rxjs';
import { Presences } from './types';
/**
 * Helper to map/get an aggregated Presences observable from action$ bus
 * Known presences as { address: <last seen MatrixPresenceUpdateAction> } mapping
 * As this helper is basically a scan/reduce, you can't simply startWith the first/initial value,
 * as it needs to also be the initial mapping for the scan itself, so instead of pipe+startWith,
 * as we usually do with state$, we need to get the initial value as parameter when it's used in
 * withLatestFrom in some inner observable
 *
 * @param action$ Observable
 * @returns Observable of aggregated Presences from subscription to now
 */
export declare const getPresences$: (action$: Observable<import("typesafe-actions").Action<string>>) => Observable<Presences>;
