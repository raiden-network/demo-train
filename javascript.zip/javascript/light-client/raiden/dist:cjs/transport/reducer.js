"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
var fp_1 = require("lodash/fp");
var redux_1 = require("../utils/redux");
var state_1 = require("../store/state");
var actions_1 = require("./actions");
/**
 * state.transport reducer
 * Handles all transport actions and requests
 *
 * @param state  Current RaidenState['transport'] slice
 * @param action  RaidenAction to handle
 * @returns New RaidenState['transport'] slice
 */
function transport(state, action) {
    if (state === void 0) { state = state_1.initialState.transport; }
    if (typesafe_actions_1.isActionOf(actions_1.matrixSetup, action)) {
        return __assign({}, state, { matrix: __assign({}, state.matrix, action.payload) });
    }
    else if (typesafe_actions_1.isActionOf(actions_1.matrixRoom, action)) {
        var path = ['matrix', 'rooms', action.meta.address];
        return fp_1.set(path, [
            action.payload.roomId
        ].concat(fp_1.getOr([], path, state).filter(function (room) { return room !== action.payload.roomId; })), state);
    }
    else if (typesafe_actions_1.isActionOf(actions_1.matrixRoomLeave, action)) {
        var path = ['matrix', 'rooms', action.meta.address];
        state = fp_1.set(path, fp_1.getOr([], path, state).filter(function (r) { return r !== action.payload.roomId; }), state);
        if (fp_1.isEmpty(fp_1.get(path, state)))
            state = fp_1.unset(path, state);
        return state;
    }
    else
        return state;
}
/**
 * Nested/combined reducer for transport
 * Currently only handles 'transport' substate
 */
exports.transportReducer = redux_1.partialCombineReducers({ transport: transport }, state_1.initialState);
//# sourceMappingURL=reducer.js.map