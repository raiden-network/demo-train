import * as t from 'io-ts';
export declare const RaidenMatrixSetup: t.TypeC<{
    userId: t.StringC;
    accessToken: t.StringC;
    deviceId: t.StringC;
    displayName: t.StringC;
}>;
export interface RaidenMatrixSetup extends t.TypeOf<typeof RaidenMatrixSetup> {
}
