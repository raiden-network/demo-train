"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var operators_1 = require("rxjs/operators");
var typesafe_actions_1 = require("typesafe-actions");
var actions_1 = require("./actions");
/**
 * Helper to map/get an aggregated Presences observable from action$ bus
 * Known presences as { address: <last seen MatrixPresenceUpdateAction> } mapping
 * As this helper is basically a scan/reduce, you can't simply startWith the first/initial value,
 * as it needs to also be the initial mapping for the scan itself, so instead of pipe+startWith,
 * as we usually do with state$, we need to get the initial value as parameter when it's used in
 * withLatestFrom in some inner observable
 *
 * @param action$ Observable
 * @returns Observable of aggregated Presences from subscription to now
 */
exports.getPresences$ = function (action$) {
    return action$.pipe(operators_1.filter(typesafe_actions_1.isActionOf(actions_1.matrixPresenceUpdate)), operators_1.scan(
    // scan all presence update actions and populate/output a per-address mapping
    function (presences, update) {
        var _a;
        return (__assign({}, presences, (_a = {}, _a[update.meta.address] = update, _a)));
    }, {}), operators_1.startWith({}));
};
//# sourceMappingURL=utils.js.map