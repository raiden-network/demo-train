"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typesafe_actions_1 = require("typesafe-actions");
/* MatrixClient instance is ready and logged in to payload.server with credentials payload.setup */
exports.matrixSetup = typesafe_actions_1.createStandardAction('matrixSetup')();
/* Request matrix to start monitoring presence updates for meta.address */
exports.matrixRequestMonitorPresence = typesafe_actions_1.createStandardAction('matrixRequestMonitorPresence')();
/**
 * Monitored user meta.address presence updated.
 * First event for this address also works as 'success' for matrixRequestMonitorPresence
 */
exports.matrixPresenceUpdate = typesafe_actions_1.createStandardAction('matrixPresenceUpdate').map(function (_a, meta) {
    var userId = _a.userId, available = _a.available, ts = _a.ts;
    return ({ payload: { userId: userId, available: available, ts: ts || Date.now() }, meta: meta });
});
/* A matrixRequestMonitorPresence request action (with meta.address) failed with payload=Error */
exports.matrixRequestMonitorPresenceFailed = typesafe_actions_1.createStandardAction('matrixRequestMonitorPresenceFailed').map(function (payload, meta) { return ({ payload: payload, error: true, meta: meta }); });
/* payload.roomId must go front on meta.address's room queue */
exports.matrixRoom = typesafe_actions_1.createStandardAction('matrixRoom')();
/* payload.roomId must be excluded from meta.address room queue, if present */
exports.matrixRoomLeave = typesafe_actions_1.createStandardAction('matrixRoomLeave')();
//# sourceMappingURL=actions.js.map