import { RaidenMatrixSetup } from './state';
export declare const matrixSetup: import("typesafe-actions").PayloadAC<"matrixSetup", {
    server: string;
    setup: RaidenMatrixSetup;
}>;
export declare const matrixRequestMonitorPresence: import("typesafe-actions").PayloadMetaAC<"matrixRequestMonitorPresence", undefined, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>;
/**
 * Monitored user meta.address presence updated.
 * First event for this address also works as 'success' for matrixRequestMonitorPresence
 */
export declare const matrixPresenceUpdate: (payload: {
    userId: string;
    available: boolean;
    ts?: number | undefined;
}, meta: {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}) => {
    type: "matrixPresenceUpdate";
} & {
    payload: {
        userId: string;
        available: boolean;
        ts: number;
    };
    meta: {
        address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
};
export declare const matrixRequestMonitorPresenceFailed: (payload: Error, meta: {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}) => {
    type: "matrixRequestMonitorPresenceFailed";
} & {
    payload: Error;
    error: boolean;
    meta: {
        address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
    };
};
export declare const matrixRoom: import("typesafe-actions").PayloadMetaAC<"matrixRoom", {
    roomId: string;
}, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>;
export declare const matrixRoomLeave: import("typesafe-actions").PayloadMetaAC<"matrixRoomLeave", {
    roomId: string;
}, {
    address: string & import("io-ts").Brand<import("../utils/types").HexStringB<20>> & import("io-ts").Brand<import("../utils/types").AddressB>;
}>;
