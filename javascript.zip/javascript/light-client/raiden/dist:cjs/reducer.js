"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var reducer_1 = require("./channels/reducer");
var reducer_2 = require("./transport/reducer");
var reducer_3 = require("./transfers/reducer");
var state_1 = require("./store/state");
var raidenReducers = {
    channelsReducer: reducer_1.channelsReducer,
    transportReducer: reducer_2.transportReducer,
    transfersReducer: reducer_3.transfersReducer,
};
/**
 * Raiden root reducer
 * Apply action over each submodule root reducer in a flattened manner (iteratively).
 * Notice the submodules reducers aren't handled only a partial/deep property of the state
 * (as combineReducers), but instead receive the whole state, so they can act on any part of the
 * state. This approach is similar to `reduce-reducers` util.
 * Each submodule root reducer may then choose to split its concerns into nested or flattened
 * reducers (like this one).
 */
exports.raidenReducer = function (state, action) {
    if (state === void 0) { state = state_1.initialState; }
    return Object.values(raidenReducers).reduce(function (s, reducer) { return reducer(s, action); }, state);
};
//# sourceMappingURL=reducer.js.map