export enum RouteNames {
  ABOUT = 'about',
  SELECT_TARGET = 'send',
  SELECT_TOKEN = 'select-token',
  SELECT_HUB = 'select-hub',
  HOME = 'home',
  CHANNELS = 'channels',
  DEPOSIT = 'deposit'
}
