# Changelog

## [Unreleased]
### Changed
- Added project skeleton

[Unreleased]: https://github.com/raiden-network/light-client
