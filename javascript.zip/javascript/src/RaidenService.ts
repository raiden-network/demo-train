import {Raiden, Address} from "raiden";
import { BigNumber } from 'ethers/utils';
// The JS library Keyv needs to be extended manually with a Typescript declaration, as done in
// https://github.com/lukechilds/keyv/pull/30
import contracts from "./deployment_rinkeby.json"


export default class RaidenService {
    private _raiden?: Raiden;

    private get raiden(): Raiden {
        if (this._raiden === undefined) {
            throw new Error('Raiden instance was not initialized');
        } else {
            return this._raiden;
        }
    }

    constructor() {
        this._raiden = undefined;

    }

    async connect() {
        try {
            console.log(contracts);
            const raiden = await Raiden.create(
                "https://rinkeby.infura.io/v3/44dc092b7766435dbbca8598767b5a5c",
                "0x8a5a292ca61fb7a6969a56a27be1a2b7d3c14644effa33400ad09af316df345f",
                // TODO Keyv should connect to a DB to permanently store data!
                // Node localstorage benutzen <-- Sagt Andre
                null
            );
            this._raiden = raiden;
        } catch (e) {
            console.log(e);
        }

    }

    async transfer(token: string, target: string, amount: BigNumber) {
        try {
          await this.raiden.getAvailability(target);
          await this.raiden.transfer(token, target, amount);
        } catch (e) {
          throw new TransferFailed(e);
        }
      }

    public getAccount(): Address {
        return this.raiden.address;
    }
}

export class TransferFailed extends Error {}
