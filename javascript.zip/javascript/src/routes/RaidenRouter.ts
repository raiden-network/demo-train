import {Router, Request, Response, NextFunction} from 'express';
import RaidenService from "../RaidenService";




export class RaidenRouter {
    router: Router;
    raidenService: RaidenService;

    /**
     * Initialize the RaidenRouter
     */
    constructor() {
        this.router = Router();
        this.raidenService = new RaidenService();
        this.init();
    }

    /**
     * Take each handler, and attach to one of the Express.Router's
     * endpoints.
     */
    init() {
        this.raidenService.connect();
        this.router.get('/address', (req: Request, res: Response, next: NextFunction) => {
            res.json({
                "address": this.raidenService.getAccount()
            });
        });

        this.router.post('/payments/:token/:receiver', (req: Request, res: Response, next: NextFunction) => {
            console.log(`Received request for Token: ${req.params.token} and Receiver ${req.params.receiver} over the amount ${req.body.amount}`)
            this.raidenService.transfer(req.params.token, req.params.receiver, req.body.amount).then(() => {
                res.sendStatus(200);
            }).catch( (e) => {
                console.log(e)
                res.status(500).send(e)
            })

        }
        );

    }

}

// Create the HeroRouter, and export its configured Express.Router
const raidenRoutes = new RaidenRouter();

export default raidenRoutes.router;